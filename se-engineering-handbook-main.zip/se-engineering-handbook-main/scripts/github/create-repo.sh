#!/bin/bash

# Example of running the script: ./create-repo.sh <repo_name> <repo_team> <template_repo>
# The <template_repo> is optional. If not provided, it will use the generic template.
# The script will locally clone the new repo, update the CODEOWNERS file, and
# then add update the repository settings.
# There is no need to pass the GitHub organisation as it is hardcoded to Direct-Line-Group.

repo_name=$1
repo_team=$2
template_repo=$3
organization="Direct-Line-Group"
repo_type="internal"

full_repo_name="$organization/$repo_name"

# Check if the parameters are set if manually running the script
if [ -z "$repo_name" ] || [ -z "$repo_team" ]; then
  echo "Usage: create-repo.sh <repo_name> <repo_team>"
  exit 1
fi

# Set the pager to cat so that the gh command does not hang
gh config set pager cat

using_repo_template=false
# Check for repository template
if [ -n "$template_repo" ]; then
  using_repo_template=true
fi

if [ $using_repo_template = true ]; then
  echo "Creating repository from template: $template_repo..."
  gh repo create $full_repo_name \
    --description "This is the repository description. Update me!" \
    --$repo_type \
    --template "Direct-Line-Group/$template_repo" \
    --clone
else
  echo "No repository template passed. Creating repository with DL generic template..."
  gh repo create $full_repo_name \
    --description "This is the repository description. Update me!" \
    --$repo_type \
    --template "Direct-Line-Group/se-dlg-generic-template" \
    --clone
fi

if [ $? -eq 0 ]; then
  echo "Repository created successfully."
else
  echo "❌ Repository failed to create. Check the name is unique."
  exit 1
fi

# Add the team as admin
echo "Adding team $repo_team as admin to repository"
gh api \
  --method PUT \
  -H "Accept: application/vnd.github+json" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  /orgs/$organization/teams/$repo_team/repos/$full_repo_name \
  -f "permission=admin"

if [ $? -eq 0 ]; then
  echo "Team added as admin successfully."
else
  echo "❌ Failed to add team as admin. Check the team exists."
  exit 1
fi

echo "Updating the repository settings..."
gh repo edit $full_repo_name \
  --enable-wiki=false \
  --enable-discussions=false \
  --enable-projects=false \
  --allow-update-branch \
  --delete-branch-on-merge \
  --enable-merge-commit \
  --enable-rebase-merge \
  --enable-squash-merge \
  --allow-forking=false

if [ $? -eq 0 ]; then
  echo "Repository settings updated successfully."
else
  echo "❌ Failed to update repository settings."
  exit 1
fi

echo "Updating repository files..."

# Go into the repository
cd $repo_name || exit

# Add to the CODEOWNERS file
printf "\n* @$organization/$repo_team" >> .github/CODEOWNERS

git add .
git commit -S -m "Initial commit"
git push origin main

if [ $? -eq 0 ]; then
  echo "Successfully committed changes to repository."
else
  echo "❌ Failed to commit changes to repository."
  exit 1
fi

cd ..

# Add main branch ruleset
gh api \
  --method POST \
  -H "Accept: application/vnd.github+json" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  /repos/$full_repo_name/rulesets \
  --input ./rulesets/main.json

# Add tag rulesets
gh api \
  --method POST \
  -H "Accept: application/vnd.github+json" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  /repos/$full_repo_name/rulesets \
  --input ./rulesets/create-tag.json

gh api \
  --method POST \
  -H "Accept: application/vnd.github+json" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  /repos/$full_repo_name/rulesets \
  --input ./rulesets/delete-tag.json

# Add vulnerability alerts
gh api \
  --method PUT \
  -H "Accept: application/vnd.github+json" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  /repos/$full_repo_name/vulnerability-alerts

# Add dependabot configuration
gh api \
  --method PUT \
  -H "Accept: application/vnd.github+json" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  /repos/$full_repo_name/automated-security-fixes

