# 📒 DL Engineering Handbook

[![Scanned by Frogbot](https://raw.github.com/jfrog/frogbot/master/images/frogbot-badge.svg)](https://docs.jfrog-applications.jfrog.io/jfrog-applications/frogbot)
[![Deploy](https://github.com/Direct-Line-Group/se-engineering-handbook/actions/workflows/deploy.yml/badge.svg)](https://github.com/Direct-Line-Group/se-engineering-handbook/actions/workflows/deploy.yml)

Welcome to the DL Engineering handbook 👋

This is your go to location for finding anything and everything about how we do
Engineering at DL.

Anyone in DL can contribute and raise a PR for changes to the handbook - just
follow our [Contributing](#contributing) section.

## Accessing the Handbook

**Get to the handbook
[here](https://direct-line-group.github.io/se-engineering-handbook)** - for the
best experience, we would recommend launching the site.

## Contributing

Submit your documentation updates on a branch - and raise a Pull Request.

For further information see the Contribute section of the Handbook itself.

This website is built using [Docusaurus](https://docusaurus.io/), a modern
static website generator.

### Pull Request Template

On each pull request a comment is added from the pull request template. The
author is prompted to provide clear information about the changes.
This can include things like the purpose of the PR, what problem it solves, or
the impact etc. The template also contains a checklist to ensure best practices
are met before merge.

An action will validate this checklist on the PR to ensure it has been completed
before allowing merge to main.

> [!TIP]
> If a check box is not applicable e.g. not a major change you must redact it
> in the PR comment using ~:
>
> ```text
> - [ ] ~Major - Breaking change to actions~
> ```
>
> Any updates to the comment will trigger a check again.

## Running the Handbook Locally

For anyone keen to run the built handbook on their local:

1. Clone the project to your local
1. Ensure you have node.js installed
1. Execute `yarn install` in your terminal
1. Execute `yarn start` in your terminal

## Documentation Styling

There is extensive documentation for
[Docusaurus](https://docusaurus.io/docs/create-doc) which is a great resource to
see what is and isn't possible in this platform.

ALl documentation is written in Markdown and there are some extensions available
in Docusaurus to provide additional capabilities - see
[these](https://docusaurus.io/docs/markdown-features) docs for further
information.
