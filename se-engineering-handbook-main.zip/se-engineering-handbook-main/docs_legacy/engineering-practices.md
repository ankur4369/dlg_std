# Engineering Practices

The DL engineering practices are based on the research by [DORA][1] that has identified and validated a set of capabilities that drive higher software delivery and organizational performance. 

The research shows that these specific practices are what **"best practice"** looks like today, and is based on significant sample size (tens of thousands) of surveyed teams and organisations. There is no debate that these practices are what is understood, and backed by data to be, what good looks like and what we will strive to do.

The practices are categorised:
* the committed practices that all engineering are expected to follow ([MUST](#must) do)
* the practices that all engineering will work towards adopting ([SHOULD](#should) do and our improvement plan)

More detail about the practices, and the science behind how they were identified can be found on the [DORA][2] research program website.

`Teams that work on the Greenfield(ish) project must adopt all the practices, from both MUST and SHOULD categories. Teams that work on the Brownfield(ish) projects have to adopt MUST practices and prepare plan of adopting practices in the SHOULD category. The adoption will be measured with Engineering HealthChecks`

## Must

| [Technical capabilities][3] | [Process capabilities][4] | [Measurement capabilities][5] | [Cultural capabilities][6] |
|---|---|---|---|
| [Version control][20] | [Working in small batches][40] | [Monitoring and observability][50] | [Transformational leadership][60] | 
| [Continuous integration][21] | [Visibility of work in the value stream][41] | [Proactive failure notification][51] | [Job satisfaction][61] |
| [Deployment automation][22] | | [Work in process limits][52] | | |
| [Continuous testing][25] | | | |
| [Shifting left on security][23] | | | |

## Should

| [Technical capabilities][3] | [Process capabilities][4] | [Measurement capabilities][5] | [Cultural capabilities][6] |
|---|---|---|---|
| [Trunk-based development][24] | [Streamlining change approval][44] | [Monitoring systems to inform business decisions][53] | [Learning culture][62] |
| [Continuous delivery][26] | [Team experimentation][43] | [Visual management capabilities][54] | [Westrum organizational culture][63] |
| [Architecture][27] | [Customer feedback][42] | | |
| [Test data management][29] | | | |
| [Database change management][30] | | | |
| [Cloud infrastructure][31] | | | |
| [Code maintainability][32] | | | |
| [Empowering teams to choose tools][28] | | | |

[1]: https://www.devops-research.com/
[2]: https://www.devops-research.com/research.html

[3]: ./practices/technical.md
[4]: ./practices/process.md
[5]: ./practices/measurement.md
[6]: ./practices/culture.md

[20]: ./practices/technical.md#version-control
[21]: ./practices/technical.md#continuous-integration
[22]: ./practices/technical.md#deployment-automation
[23]: ./practices/technical.md#shifting-left-on-security
[24]: ./practices/technical.md#trunk-based-development
[25]: ./practices/technical.md#continuous-testing
[26]: ./practices/technical.md#continuous-delivery
[27]: ./practices/technical.md#architecture
[28]: ./practices/technical.md#empowering-teams-to-choose-tools
[29]: ./practices/technical.md#test-data-management
[30]: ./practices/technical.md#database-change-management
[31]: ./practices/technical.md#cloud-infrastructure
[32]: ./practices/technical.md#code-maintainability

[40]: ./practices/process.md#working-in-small-batches
[41]: ./practices/process.md#visibility-of-work-in-the-value-stream
[42]: ./practices/process.md#customer-feedback
[43]: ./practices/process.md#team-experimentation
[44]: ./practices/process.md#streamlining-change-approval

[50]: ./practices/measurement.md#monitoring-and-observability
[51]: ./practices/measurement.md#proactive-failure-notification
[52]: ./practices/measurement.md#work-in-process-limits
[53]: ./practices/measurement.md#monitoring-systems-to-inform-business-decisions
[54]: ./practices/measurement.md#visual-management-capabilities

[60]: ./practices/culture.md#transformational-leadership
[61]: ./practices/culture.md#job-satisfaction
[62]: ./practices/culture.md#learning-culture
[63]: ./practices/culture.md#westrum-organizational-culture