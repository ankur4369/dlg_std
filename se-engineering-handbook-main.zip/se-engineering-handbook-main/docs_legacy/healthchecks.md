# Engineering HealthChecks

## What is it?

The engineering health check is a mechanism for squads to measure and visualise how the team is doing against a number of engineering principles and practices. 

## Who is this for?

There are two stakeholders for the engineering health check:

1. **The squad.** Whilst discussing engineering principles and practices the squad will be aware of the standards that the organisation are aiming towards and have an awareness of how they are functioning against those standards. The teams will be able to highlight the good points in which they are currently working as well as things that might require improvement. This is also a forum for the squads to comment on the standards to ensure that they are clear and fit for purpose, the feedback will be used to evolve the standards over time.

2. **Engineering chapter.** There are a number of squads in the organisation that are focused on delivering new capabilities into the squads, to help them achieve their work to a higher standard and more efficiently. For example EngProd mini tribe squads can assist in bet practices in Digital and Cloud Infrastructure and DevOps Practices. The enabling squads will not be able to talk to all engineers at one time, so having a summary helps them figure out what items need to be prioritised to help as many squads as possible.

## Types of Health checks

There are 2 types of Health checks, designed to focus on Engineering Practices and Capabilities:

* **DORA Health checks** - designed to measure capabilities that enable entire team to optimise for the FLOW of work. You should use this health check to measure team capabilities and help with identifying where improvements could be made that will affect capabilities **beyond** _software engineering_. Capabilities and Practices are described in details on the [Engineering Practices](./engineering-practices.md) page.
* **SDLC Health checks** - designed to measure SDLC practices, focusing on Engineering tasks. You should use this health check to measure adoption of engineering practices that focus on the _software engineering_ capabilities. Practices described in details at the [SDLC](./sdlc/index.md) page.

## How to perform Health checks?

Engineering Practices and capabilities are distilled down into a few principles in which the team can assess their maturity and applicability.

These principles will be brought into a **workshop**, that can be held by the squad in person or remotely, where squad members can discuss and access their current situation against the engineering principles. 

At the end of the session, we will have a **graphical summary** visualising the maturity of each principle or capability.

These graphical summaries can be used to **help squads improve** by preparing improvement plan and actions.

### How to gather data?

Some metrics can be gathered such as code coverage and static code analysis measurements to inform the maturity of teams against specific practices. However not every practice and principle can be easily measured. Therefore, we have decided that data should be gathered via workshops. These workshops are subjective in manner however, they will allow every squad member to voice their opinion and come to a consensus around specific principles and capabilities.

All participants should be recorded to ensure that those present are a fair reflection of the individuals in the squad.

The squad should then record all the services and applications which they are responsible for. These will be a reminder as to what they are evaluating the engineering principles against. 

For each engineering principle, we will then do the following:

* Describe the engineering principle and ensure that it is well understood
* Outline any practices that contribute towards the principle or capability and ensure that they are well understood
* Utilising the [1-2-4-All liberating structure][1] we should break out and have discussions and take notes as to contributing factors
* Every point raised should be recorded against the principle
* Everyone then votes on the maturity of the principle within the squad
* Actions are discussed how we can improve these going forward
* Feedback on the principles/practices should be noted

After all the principles have been covered the workshop can be recorded, summarised and visualised. Any actions recorded can be added to the backlog or assigned to individuals to follow up on.

### Helpful material

There are 2 Excel Spreadsheets available, that help facilitate Health check sessions:

* [Engineering Practices - DORA HealthChecks](./files/healthcheck/Engineering%20Practices%20-%20DORA%20healtchecks.xlsx)
* [Engineering Practices - SDLC HealthChecks](./files/healthcheck/Engineering%20Practices%20-%20SDLC%20Healtchecks.xlsx)

Each of the checks provides useful visualisation and help in identifying improvement actions.

![Engineering Health checks - DORA](./img/healthchecks/healthcheck-DORA.png)
![Engineering Health checks - SDLC](./img/healthchecks/healthcheck-SDLC.png)


[1]: https://www.liberatingstructures.com/1-1-2-4-all/