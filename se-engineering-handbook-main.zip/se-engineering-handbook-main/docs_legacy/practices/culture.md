# Cultural capabilities

Must do:

* [Transformational leadership](#transformational-leadership)
* [Job satisfaction](#job-satisfaction)

Should do:

* [Learning culture](#learning-culture)
* [Westrum organizational culture](#westrum-organizational-culture)

## Transformational leadership

[DevOps Research and Assessment (DORA)][1] research shows that effective leadership has a measurable, significant impact on software delivery outcomes. However, rather than driving these outcomes directly, effective transformational leaders influence software delivery performance by enabling the adoption of technical and product management capabilities and practices by practitioners, which in turn drives the outcomes leaders care about.

To study the role of leadership in DevOps transformations, DORA used a measure of transformational leadership that includes five dimensions. According to this model, validated in [Dimensions of transformational leadership: Conceptual and empirical extensions][2] *(Rafferty, A. E., & Griffin, M. A.)*, the five characteristics of a transformational leader are the following:

* **Vision:** Understands clearly where their team and the organization are going, and where they want the team to be in five years.
* **Inspirational communication:** Says positive things about the team; says things that make employees proud to be a part of DL; encourages people to see changing conditions as situations full of opportunities.
* **Intellectual stimulation:** Challenges team members to think about old problems in new ways and to rethink some of their basic assumptions about their work; has ideas that force team members to rethink some things that they have never questioned before.
* **Supportive leadership:** Considers others' personal feelings before acting; behaves in a manner which is thoughtful of others' personal needs; sees that the interests of team members are given due consideration.
* **Personal recognition:** Commends team members when they do a better than average job; acknowledges improvement in quality of team members' work; personally compliments team members when they do outstanding work.

These five characteristics of transformational leadership are highly correlated with software delivery performance. In fact, DORA observed statistically significant differences in leadership characteristics between high-, medium- and low- performing software delivery teams (see the [2017 State of DevOps Report][3] pp12-19). High-performing teams reported having leaders with the strongest behaviors across all dimensions. In contrast, low-performing teams reported the lowest levels of these leadership characteristics.

What was most striking, however, was that teams with the least transformative leaders (the bottom third) were also far less likely to be high performers at software delivery — in fact, they were half as likely to exhibit high software delivery performance. This validates common experience: Though there are many DevOps and technology transformation success stories emerging from the grassroots, it is far easier to achieve success when you have effective, transformational leadership.

![Relationship between Transformational Leaders and Organisation performance](../img/practices/transformational-leadership-validated-model.png)

The validated model shows that effective leaders impact software delivery and organizational performance indirectly, by enabling teams to adopt technical practices and lean product management practices. It is these practices that drive organizational outcomes such as higher software delivery performance and organizational performance. 

### How to implement transformational leadership

Transformational leadership can be contrasted with transactional leadership, where employees are rewarded with money or prestige for complying with leadership instructions or punished for failing to follow them.

However, transformational leaders, according to [Rafferty and Griffin][2], *"motivate followers to achieve performance beyond expectations by transforming followers' attitudes, beliefs, and values as opposed to simply gaining compliance."*

Leaders cannot achieve higher performance on their own. Success also depends on the implementation of effective technical, management, and product management practices, along with the other capabilities discussed in DORA's research and this [Engineering Practices](../engineering-practices.md) handbook. It's essential that the transformational leadership behaviors, described above, are directed towards the implementation of these capabilities.

Take vision as an example. One way to create a clear vision for a software delivery team is to set measurable relative goals for software delivery performance. [For example Richard Herbert][4], CIO for Global Banking at Markets of HSBC, set every team the goal to *"double the frequency of releases, half the number of low impact incidents, and quarter the number of high impact incidents."*

There may be significant obstacles to achieving goals like the ones set by Richard Herbert. Again, leaders can use intellectual stimulation to help teams identify and remove obstacles to achieving higher performance. Perhaps team members believe that implementing [continuous testing](technical.md#continuous-testing) will help them, but they've tried before and failed. Leaders can ask teams questions such as: *"Why did it fail last time?"*, *"What lessons did you learn?"*, *"What would you do differently this time?"*, *"What ideas would you like to try this time?"*.

Personal recognition is also important, and must be directed such that it reinforces behaviors that help teams improve. Examples include trying experiments even if they don't work, or taking time to help other teams implement new ideas. Another example of effective personal recognition is e-commerce company Etsy, which at its annual engineering conference [gives an award][5] "to the engineer who inadvertently causes the most interesting or most learning-filled incident."

    It's crucial that these behaviors are demonstrated consistently, and particularly when the team is under stress.

Finally, remember that leadership doesn't just mean executives and managers: **anybody can be a leader.** Almost all of these behaviors can be practiced by everybody in DL. Consider how you can build them into your daily interactions with other people in your organization.

### How to measure transformational leadership

Transformational leadership can be measured directly by asking team members about the extent to which they believe leaders exhibit the behaviors described.

The effects of transformational leadership are also measurable. For example, if a leader does an outstanding job of defining and communicating their vision, everybody in the organization should be able to describe that vision in a consistent way without having to look it up.

----------

## Job satisfaction

Early analysis performed by [DevOps Research and Assessment (DORA)][1] found that job satisfaction is a predictor of organizational performance. Having engaged employees doing meaningful work drives business value.

Everybody knows how job satisfaction feels. It's about doing work that's challenging and meaningful, and being empowered to exercise skills and judgment. Where there's job satisfaction, employees bring the best of themselves to work: their engagement, their creativity, and their strongest thinking. The result is more innovation in any area of the business, including technology.

There's a virtuous circle when it comes to the benefits of job satisfaction. People do better work when they feel supported by their employers, when they have the tools and resources to do their work, and when they feel their judgment is valued. Better work results in higher software delivery performance, which results in higher organizational performance.

This cycle of continuous improvement and learning is what sets successful companies apart, enabling them to innovate, get ahead of the competition, and win.

### Common pitfalls in job satisfaction

The following pitfalls are commonly related to job satisfaction:

* Not giving people the [tools][20] they need to be successful.
* Not giving people meaningful work.

Practitioners and leaders must remember that technology transformations are hard and take time, and often require an update in both technology and skill sets. Technology transformations also commonly require organizational changes like reorganizations and culture shifts, which can be difficult for people to navigate. 

If you're trying to institute change, don't forget that you must make time and resources available for improvement work. Creating change takes time, and people also need time to adjust to the changes, as you build practices such as [automation](technical.md#continuous-testing) and [continuous integration](technical.md#continuous-integration) into your [delivery process](technical.md#deployment-automation). On top of that, improving process is itself a skill that needs to be learned. Teams that routinely work on improvement get better at it over time, and are more likely to stay with the company.

### Ways to improve job satisfaction

**Give employees the tools and resources needed to do their work.**

Employees must have the tools necessary to get their work done, and [teams that can decide which tools they use][20] do better at continuous delivery. Teams that can choose their own tools make these choices based on how they work, and on the tasks they need to perform. No one knows better than practitioners what they need to be effective, so it's not surprising that practitioner tool choice helps to drive better outcomes.

Employees must also have the resources necessary to do their work. Those might be technical resources, such as access to servers or environments necessary to develop and test, or resources needed to learn and develop new skills, such as access to course materials and budget to attend trainings or technical conferences.

**Give employees meaningful work that leverages their expertise.**

The importance of meaningful work can't be overstated. In some studies, employees have rated the importance of meaningful work just as highly as the importance of salary. Meaningful work makes a difference and is often very personal.

### Ways to measure job satisfaction

Measuring job satisfaction in systems is hard. There just isn't a good way to proxy job satisfaction in system data. Much like organizational culture, job satisfaction is a perceptual measure, so to measure it, you must ask people for their opinions. If you worry that you won't get accurate answers, that's a signal that something is wrong, and it's worth looking into.

----------

## Learning culture

Culture that values learning contributes to software delivery performance with the following:

* Increased deployment frequency
* Reduced lead time for changes, time to restore service, and change failure rate
* Strong team culture

In DL we see learning as Strategic investment necessary to grow.

### How to implement a learning culture

You can help your team create a climate for learning by viewing learning as the key to improvement and as an investment. Some steps you can take to directly support learning include:

* **Create/ask about a training budget, and advocate for it internally.** Emphasize how much the organization values a climate of learning by putting resources behind formal education opportunities.
* **Ensure that your team has the resources to engage in informal learning and the space to explore ideas.** Learning often happens outside formal education. Some companies, like 3M and Google, set aside a portion of time for focused free-thinking and exploration of side projects.
* **Make it safe to fail.** If failure is punished, people won't try new things. Treat failures as opportunities to learn, and hold blameless post-mortems to work out how to improve processes and systems. Help people feel comfortable taking reasonable risks, and create a culture of innovation.
* **Create opportunities and spaces to share information.** Whether you hold weekly lightning talks or offer resources for monthly lunch-and-learns, set up a regular cadence of opportunities for employees to share their knowledge.
* **Make resources available for continued education.** For example, attending conferences is important for both exposure to new technology and case studies, as well as networking with peers.

### Ways to improve your learning culture

Continuing to build a climate for learning is directly related to how an organization encourages and invests in learning. Here are some ways to show that learning is important and necessary for growth:

* **Have regular lunchtime meetings ("brownbags") where one person presents about a project they are working on in a new tech, or something they are investigating.** Rotate the presentations among team members and reward people for presenting.
* **When people attend conferences, have them share the new ideas through presentations or trip reports.** You can even host regular meetups or mini-conferences to increase networking and exposure to new technologies and ideas.
* **Encourage people to get certifications or external trainings.** You can help with this by covering costs of external trainings and forming study groups that are a part of normal work activity.

### Ways to measure learning culture

The most effective way to measure your climate for learning is to survey your employees.

Research presented in the article [An empirical analysis of the levers of control framework][6] shows that you can measure learning culture based on the extent to which people agree or disagree with the following statements about their organization:

* Learning is the key to improvement.
* Once we quit learning we endanger our future.
* Learning is viewed as an investment, not an expense.

----------

## Westrum organizational culture

Organizational culture that is high-trust and emphasizes information flow is predictive of software delivery performance and organizational performance in technology. The idea that a good culture that optimizes information flow is predictive of good outcomes is not a new idea; it is based on research by sociologist Dr. Ron Westrum. [Westrum's research][7] included human factors in system safety, particularly in the context of accidents in technological domains such as aviation and healthcare.

In his work with these high risk, highly complex fields, Westrum noted that such a culture influences the way information flows through an organization. Westrum provides three characteristics of good information:

1. It provides answers to the questions that the receiver needs answering.
2. It is timely.
3. It is presented in such a way that the receiver can use it effectively.

In his research, he developed the following typology of organizational cultures.

| Pathological | Bureaucratic | Generative |
| ---- | ---- | ---- |
| Power oriented | Rule oriented | Performance oriented |
| Low cooperation | Modest cooperation | High cooperation |
| Messengers "shot" | Messengers neglected | Messengers trained |
| Responsibilities shirked | Narrow responsibilities | Risks are shared |
| Bridging discouraged | Bridging tolerated | Bridging encouraged |
| Failure leads to scapegoating | Failure leads to justice | Failure leads to inquiry |
| Novelty crushed | Novelty leads to problems | Novelty implemented |

Research from a large [two-year study at Google][8] found that high performing teams need a culture of trust and [psychological safety][9], meaningful work, and clarity. In the [2019 State of DevOps Report][10] further analysis shows that a culture of psychological safety is predictive of software delivery performance, organizational performance, and productivity.

### How to implement organizational culture

DORA research shows that changing the way people work changes culture.

> "The way to change culture is not to first change how people think, but instead to start by changing how people behave—what they do." 

Some practices you can implement to improve your culture:

* **High cooperation.** Create cross-functional teams that include representatives from each functional area of the software delivery process (business analysts, developers, quality engineers, ops, security, and so on). This practice lets everyone shares the responsibility for building, deploying, and maintaining a product. It's also important that there is good cooperation within the team.
* **Train the messengers.** This means we want people to bring us bad news, so we can make things better. Hold blameless postmortems. By removing blame, you remove fear; and by removing fear, you enable teams to surface problems and solve them more effectively. Also create and foster an environment where it is safe to take smart risks and fail, so that anyone can surface problems at any time—even without the ceremony of a postmortem.
* **Share risks.** Along with this, encourage shared responsibilities. Quality, availability, reliability and security are everyone's job. One way to improve the quality of your services is to ensure that developers share responsibility for maintaining their code in production. The improvement in collaboration that comes from sharing responsibility inherently reduces risk: The more eyes on the software delivery process, the more you'll avoid errors in process or planning. Automation also reduces risk, and with the right tool choice, can enable collaboration.
* **Encourage bridging.** Break down silos. In addition to creating cross-functional teams, techniques for breaking down silos include co-locating ops with the dev team; including ops in planning throughout the software delivery lifecycle; and implementing ChatOps. Another tip is to identify someone in the organization whose work you don't understand (or whose work frustrates you, like procurement) and invite them to coffee or lunch. Informal discussions help foster better communication, and you may understand why they do what they do—and you can come up with creative solutions together.
* **Let failure lead to inquiry.** Again, hold blameless postmortems. The response to failure shapes the culture of an organization. Blaming individuals for failures creates a negative culture. If instead, failures lead you to ask questions about what caused the failures and how you can keep them from happening again in the future, you've improved your technical system, your processes, and your culture.
* **Implement novelty.** Encourage experimentation. Giving employees freedom to explore new ideas can lead to great outcomes. Some companies give engineers time each week for experimentation. Others host internal hack days or mini-conferences to share ideas and collaborate. Many new features and products began this way. When you release your employees from habitual pathways and repetitive tasks, they can generate enormous value for your organization. And remember that novelty isn't limited to new products and features. Also encourage and reward improvements in process and ideas that help foster collaboration.

### How to measure organizational culture

Organizational culture is a perceptual measure, and therefore, best measured using survey methods. The Westrum survey measures, included here, are highly valid and reliable statistically.

* On my team, information is actively sought.
* Messengers are not punished when they deliver news of failures or other bad news.
* On my team, responsibilities are shared.
* On my team, cross-functional collaboration is encouraged and rewarded.
* On my team, failure causes inquiry.
* On my team, new ideas are welcomed.

Present these measures together—unlabeled and untitled—with responses ranging from Strongly Disagree (=1) to Neither Agree nor Disagree (=4) to Strongly Agree (=7). They are a latent construct, which means you can average their scores to provide a single score for your Westrum culture metric. If necessary, you can alter the items slightly to fit your context, but we recommend doing only minor changes in order to preserve the statistical properties.

----------

[1]: https://cloud.google.com/devops
[2]: https://www.sciencedirect.com/science/article/pii/S1048984304000207
[3]: https://services.google.com/fh/files/misc/state-of-devops-2017.pdf
[4]: https://www.linkedin.com/pulse/double-half-quarter-lesson-from-book-richard-david-knott/
[5]: https://www.infoq.com/articles/crafting-resilient-culture/
[6]: https://www.sciencedirect.com/science/article/pii/S0361368207000049
[7]: https://qualitysafety.bmj.com/content/13/suppl_2/ii22
[8]: https://rework.withgoogle.com/blog/five-keys-to-a-successful-google-team/
[9]: https://rework.withgoogle.com/guides/understanding-team-effectiveness/steps/foster-psychological-safety/
[10]: https://services.google.com/fh/files/misc/state-of-devops-2019.pdf

[20]: ./technical.md#empowering-teams-to-choose-tools