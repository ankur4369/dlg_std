# Process capabilities

**Must Do** practices:
* [Working in small batches](#working-in-small-batches)
* [Visibility of work in the value stream](#visibility-of-work-in-the-value-stream)

**Should Do** practices:
* [Streamlining change approval](#streamlining-change-approval)
* [Customer feedback](#customer-feedback)
* [Team experimentation](#team-experimentation)

## Working in small batches

Working in small batches is an **essential principle** in any discipline where feedback loops are important, or you want to learn quickly from your decisions. Working in small batches allows you to rapidly test hypotheses about whether a particular improvement is likely to have the effect you want, and if not, lets you course correct or revisit assumptions.

Working in small batches is part of lean product management. Together with capabilities like visibility of work in the value stream, team experimentation, and visibility into customer feedback, working in small batches predicts software delivery performance and organizational performance.

One reason work is done in large batches is because of the large fixed cost of handing off changes. In traditional phased approaches to software development, hand-offs from development to test or from test to IT operations consist of whole releases: months worth of work by teams consisting of tens or hundreds of people. With this traditional approach, collecting feedback on a change can take weeks or months.

In contrast, DevOps practices, which utilize cross-functional teams and lightweight approaches, allow for software to progress from development through test and operations into production in a matter of minutes. However, this rapid progression requires working with code in small batches.

Working in small batches has many benefits:

* It reduces the time it takes to get feedback on changes, making it easier to triage and remediate problems.
* It increases efficiency and motivation.
* It prevents your organization from succumbing to the sunk-cost fallacy.

[Continuous delivery](technical.md#continuous-delivery) builds upon working in small batches and tries to get every change in version control as early as possible. A goal of continuous delivery is to change the economics of the software delivery process, making it viable to work in small batches. This approach provides fast, comprehensive feedback to teams so that they can improve their work.

### How to work in small batches

When you plan new features, try to break them down into work units that can be completed independently and in short timeframes. We recommend that each feature or batch of work follow the agile concept of the [INVEST][1] principle:

* **Independent.** Make batches of work as independent as possible from other batches, so that teams can work on them in any order, and deploy and validate them independent of other batches of work.
* **Negotiable.** Each batch of work is iterable and can be renegotiated as feedback is received.
* **Valuable.** Discrete batches of work are usable and provide value to the stakeholders.
* **Estimable.** Enough information exists about the batches of work that you can easily estimate the scope.
* **Small.** During a sprint, you should be able to complete batches of work in small increments of time, meaning hours to a couple of days.
* **Testable.** Each batch of work can be tested, monitored, and verified as working in the way users expect.

When features are of an appropriate size, you can split the development of the feature into even smaller batches. Ideally, developers should be checking multiple **small releasable changes** into [trunk][24] at least once per day.

The key is to start development at the service or API layer, not at the UI layer. In this way, you can make additions to the API that won't initially be available to users of the app, and check those changes into trunk. You can launch these changes to production without making them visible to users. This approach, called *dark launching*, allows developers to check in code for small batches that have been completed, but for features that are not yet fully complete. You can then run [automated tests][21] against these changes to prove that they behave in the expected way. This way, teams are still working quickly and [developing off of trunk][24] and not long-lived feature branches.

You can also dark-launch changes by using a [feature toggle][2], which is a conditional statement based on configuration settings. For example, you can make UI elements visible or invisible, or you can enable or disable service logic. Feature-toggle configuration might be read either at deploy time or runtime. You can use these configuration settings to switch the behavior of new code further down the stack. You can also use similar technique known as [branch by abstraction][3] to make **larger-scale changes** to the system while continuing to develop and release off-trunk without the use of long-lived feature branches.

### Ways to reduce the size of work batches

When you slice work into small batches that can be completed in hours, you can typically [test and deploy those batches to production in less than an hour][4]. The key is to decompose the work into small features that allow for rapid development, rather than developing complex features on branches and releasing them infrequently.

To improve small batch development, check your environment and confirm that the following conditions are true:

* Work is decomposed in a way that enables teams to make more frequent production releases.
* Engineers* are experienced in breaking down work into small changes that can be completed in the space of hours, not days.

To become an expert in small batch development, strive to meet each of these conditions in all of your development teams. This practice is a necessary condition for both [continuous integration][22] and [trunk-based development][24].

### Ways to measure the size of work batches

When you understand [continuous integration][22] and [monitoring](measurement.md#monitoring-systems-to-inform-business-decisions), you can outline possible ways to measure small batch development in your systems and development environment.

* **Application features are decomposed in a way that supports frequent releases.** How often are releases possible? How does this release cadence differ across teams? Are delays in production related to features that are larger?
* **Application features are sliced in a way that lets developers complete the work in one week or less.** What proportion of features can you complete in one week or less? What features can't you complete in one week or less? Can you commit and release changes before the feature is complete?
* **MVPs are defined and set as goals for teams.** Is the work decomposed into features that allow for MVPs and rapid development, rather than complex and lengthy processes?

Your measurements depend on the following:

* Knowing your organization's processes.
* Setting goals for reducing waste.
* Looking for ways to reduce complexity in the development process.

----------

## Visibility of work in the value stream

Visibility of work represents the extent to which teams have a good understanding of the flow of work from the business all the way through to customers, and whether they have visibility into this flow, including the status of products and features. Visibility of work is part of a wider group of capabilities that represent lean product management; these capabilities include [working in small batches](#working-in-small-batches), [team experimentation](#team-experimentation), and [visibility into customer feedback](#customer-feedback). These capabilities predict both software delivery performance and organizational performance (which is measured in terms of profitability, market share, and productivity).

### How to implement work visibility

Teams that are proficient at this capability have the following characteristics:

* The team understands **how work moves** through the business from idea to customer, including products or features.
* The team has visibility into the **flow of this work**.
* The flow of work, including its current state, is **shown on visual displays** or dashboards.
* **Information about the flow** of product development work across the whole value stream is readily available.

#### Use value stream mapping to understand how work flows

Understanding how work moves through the product or feature development value stream is an essential step in improving workflow. A useful technique is [value stream mapping (VSM)][5]. You can create a value stream map by gathering stakeholders from every part of the product development value stream: the business line, design, testing, QA, operations, and support. You break the value stream into 5 to 15 process blocks. In each block, you record the activity that's performed, along with the team that performs it, as shown in the following diagram:

![Sample Value Stream Map](../img/practices/devops-process-work-visibility-in-value-stream-9-stages.svg)

Next, you analyze the state of work within the value stream, gathering the information to determine barriers to flow. In particular, for each process block, you measure the following key metrics:

* **Lead time:** the time from the point a process accepts a piece of work to the point it hands that work off to the next downstream process.
* **Process time:** the time it would take to complete a single item of work if the person performing it had all the necessary information and resources to complete it and could work uninterrupted.
* **Percent complete and accurate (%C/A):** the proportion of times that a process receives something from an upstream process that it can use without requiring rework.

You always record the state of the processes as they really are on the day the exercise is performed. Make sure that you determine the actual metrics, not what people would like the metrics to be.

Look for process blocks that produce poor quality work, which then require a lot of downstream rework (reflected in a low %C/A in the downstream process block), and for processes that have long lead times relative to the process time.

It's important to work with stakeholders to create a future-state value stream map that reflects the optimal state of the value stream at some future date (for example, in 6 months to 2 years). Stakeholders should also agree to re-run the exercise on a regular schedule (for example, every 6 months) to review the current state and to review progress.

#### Visualize the current state of work

VSM can depict how work moves through the product development value stream from idea to customer. But to get ongoing visibility into the flow of this work, you need a more dynamic view. For software development, you can use a card wall, a storyboard, or a Kanban board like the one shown in the following diagram.

![Kanban for Software Dev and Ops](../img/practices/devops-process-work-visibility-in-value-stream-kanban-board.svg)

Using visual displays such as this, and creating of [WIP limits](measurement.md#work-in-process-limits) to manage flow, are detailed in the articles on WIP limits and [visual management](measurement.md#visual-management-capabilities).

### Ways to improve work visibility

* **Provide tools for visualizing and recording workflow.** Start with making sure the team has [visual management](measurement.md#visual-management-capabilities) displays that show their work and its flow through the part of the value stream that is closest to them, including both the upstream and downstream parts of the process. Record how long it takes work to get through the process, and how often rework must be performed because the team didn't get it right the first time. This will uncover your early and best opportunities for improvement at the team level.
* **Create a value stream map.** Work with other teams to perform a value-stream mapping exercise to discover how work flows from idea to customer outcome, and report the VSM metrics (lead time, process time, %C/A) for each process block. Have the team prepare a future-state value stream map and work to implement it.
* **Share artifacts.** Make sure the artifacts from these exercises are available to everyone in the organization, and that they are updated at least annually.

### Ways to measure work visibility

To determine the effectiveness of the team's visibility to the work in the value stream, ask these questions:

* Is there a current or recent value stream map available to anyone in the organization?
* Does everybody in the DL have access to a visual display that shows what they're working on and the status of their work?
* Are statistics on metrics such as lead time and %C/A available to the team?

----------

## Team experimentation

Even in many so-called agile teams, developers can only work on requirements or stories that are given to them. And despite the developers’ specialist knowledge, or what they discover in the development process, they can’t change those requirements and stories. In truly agile teams, what’s written on the story card is a reminder of a conversation between customers and the team. Stories start from the business outcome that they are trying to achieve or the problem they are trying to solve. Teams then decide on what needs to be done, and test whether it will achieve the outcome or solve the problem.

For DL to fully benefit from modern software development techniques, you must empower your teams to experiment with real users to achieve agreed-upon business outcomes. In this paradigm, developers can quickly prototype and test ideas as they discover more about users and about the problem, and design solutions. Teams then incorporate what they learned into the design of the product or service. Using the lean product management method, these practices help teams ship features that add value to the organization, and ship those features more frequently.

Team experimentation is part of lean product management. This approach is often used in combination with capabilities like [visibility of work in the value stream](#visibility-of-work-in-the-value-stream), [working in small batches](#working-in-small-batches), and [visibility into customer feedback](#customer-feedback). These capabilities predict software delivery performance and organizational performance.

### How to implement team experimentation

There are three key components to team experimentation that drive software delivery performance:

* The ability to work on new ideas independently, without having to get permission from outside the team.
* The ability to write and change specifications during development.
* The ability to make changes to stories and specifications without having to get permission from outside the team.

Based on these abilities, the following practices can help improve your team experimentation:

* **Empower teams.** Empower teams and allow them to work on new ideas in pursuit of business goals that solve important problems.
* **Provide information and context.** Providing teams with information and context lets teams make informed decisions about the right work to do. Measuring organizational outcomes provides information critical to making the best decisions, so teams are able to achieve expected outcomes and solve problems.
* **Leave the details to those doing the work.** Allow your teams to change stories, specifications, and technologies when they decide it's appropriate. Understand and acknowledge that they are the experts, and empower them to make the technical decisions necessary to get the work done. In the highest-performing teams and organizations, teams are allowed to [make informed decisions about the tools and technologies they use](technical.md#empowering-teams-to-choose-tools).

### Common pitfalls in team experimentation

Common pitfalls of implementing team experimentation:

* **Ignoring the importance of experimentation altogether.** Don't treat your technical staff as order-takers. It's worse when teams are given specific direction on how to perform the work. Your technical staff are the experts, so empower them to make the technical decisions needed to get the work done.
* **Not providing opportunities or time for your technical staff to design and conduct experiments in quick and easy ways.** Empower your developers to quickly prototype and test ideas.

### Ways to improve team experimentation

To free your teams to find the best solutions, try some of these suggestions:

* **Hold regular hackathons.** Hackathons are opportunities for the team to experiment and to work with and share ideas. They also have the added benefit of letting your team work with new technologies and tools.
* **Encourage teams to iterate on and continually improve solutions to foster experimentation.** Many times the first solution to a problem isn't the best. Improvements to one service or feature often yield improvements in others.
* **Allow developers and operators to talk to and observe customers.** This kind of interaction provides more context and information that teams can use to solve problems and develop new ideas.

### Ways to measure team experimentation

You might be able to capture some evidence of team experimentation in your systems, for example, by tracking permission requests for changing stories or specifications. However, we recommend using surveys to measure experimentation. The core idea is that teams feel the freedom to do this work and find the best ways to solve problems.

DORA research shows that high-performance teams are driven by the following measures:

* Teams are able to work on new ideas.
* Teams are able to do work without having to ask for permission.
* Teams are able to make changes to stories and specifications during development.
* Teams are able to make changes without having to ask for permission.

----------

## Streamlining change approval

> DL has change management processes to manage the life cycle of changes to IT services, both internal and customer-facing. These processes are the primary controls to reduce the operational and security risks of change.

Change management processes often include approvals by external reviewers or **Change Approval Boards (CABs)** to promote changes through the system.

Compliance managers and security managers rely on change management processes to validate compliance requirements, which typically require evidence that all changes are appropriately authorized.

Research by DevOps Research and Assessment (DORA), presented in the [2019 State of DevOps Report (PDF)][6], finds that change approvals are best implemented through peer review during the development process, supplemented by automation to detect, prevent, and correct bad changes early in the software delivery life cycle. Techniques such as [continuous testing][21], [continuous integration][22], and [comprehensive monitoring and observability][23] provide early and automated detection, visibility, and fast feedback.

Further, DL can improve performance by doing a better job of communicating the existing process and helping teams navigate it efficiently. When team members have a clear understanding of the change approval process, this drives higher performance.

### How to implement a change approval process

Two important goals of the change approval process are decreasing the risk of making changes, and satisfying regulatory requirements. One common regulatory requirement is segregation of duties, which states that changes must be approved by someone other than the author, thus ensuring that no individual has end-to-end control over a process.

Traditionally, these goals have been met through a heavyweight process involving approval by people external to the team proposing the change: a change advisory board (CAB) or a senior manager. However, DORA's research shows that these approaches have a negative impact on software delivery performance. 

> Further, no evidence was found to support the hypothesis that a more formal, external review process was associated with lower change fail rates.

Such heavyweight approaches tend to slow down the delivery process leading to the release of larger batches less frequently, with an accompanying higher impact on the production system that is likely to be associated with higher levels of risk and thus higher change fail rates. DORA's research found this hypothesis was supported in the data.

Instead, teams should:

* Use peer review to meet the goal of segregation of duties, with reviews, comments, and approvals captured in the team's [development platform](technical.md#code-maintainability) as part of the development process.
* Employ [continuous testing][21], [continuous integration][22], and [comprehensive monitoring and observability][23] to rapidly detect, prevent, and correct bad changes.
* Treat your development platform as a product that makes it easy for developers to get fast feedback on the impact of their changes on multiple axes, including security, performance, and stability, as well as defects.

Your goal should be to *make your regular change management process fast and reliable enough* that you can use it to make emergency changes too.

In the continuous delivery paradigm the *CAB* still has a vital role, which includes:

* Facilitating notification and coordination between teams.
* Helping teams with process improvement work to increase their software delivery performance.
* Weighing in on important business decisions that require a trade-off and sign-off at higher levels of the business, such as the decision between time-to-market and business risk.

This new role for the *CAB* is strategic. By shifting detailed code review to practitioners and automated methods, the time and attention of those in leadership and management positions is freed up to focus on more strategic work. This transition, from gatekeeper to process architect and information beacon, is consistent with the practices of organizations that excel at software delivery performance.

### Common pitfalls in change approval processes


**Reliance on a centralized Change Approval Board (CAB) to catch errors and approve changes.** This approach can introduce delay and often error. CABs are good at broadcasting change, but people that far removed from the change might not understand the implications of those changes.

**Treating all changes equally.** When all changes are subject to the same approval process, change review is inefficient, and people are unable to devote time and attention to those that require true concentration because of differences in risk profile or timing.

**Failing to apply continuous improvement.** As with all processes, key performance metrics such as lead time and change fail rate should be targeted with the goal of improving the performance of the change management process, including providing teams with tools and training to help them navigate it more effectively.

**Responding to problems by adding more process.** Often DL use additional process and more heavyweight approvals when faced with stability problems in production. Analysis suggests this approach will make things worse because this drives up lead times and batch sizes, creating a vicious cycle. Instead, invest in making it quicker and safer to make changes.


### Ways to improve your change approval process

To improve your change approval processes, focus on implementing the following:

1. Moving to a peer-review based process for individual changes, enforced at code check-in time, and supported by automated tests.
2. Finding ways to discover problems such as regressions, performance problems, and security issues in an automated fashion as soon as possible after changes are committed.
3. Performing ongoing analysis to detect and flag high risk changes early on so that they can be subjected to additional scrutiny.
4. Looking at the change process end-to-end, identifying bottlenecks, and experimenting with ways to shift validations into the development platform.
5. Implementing information security controls at the platform and infrastructure layer and in the development tool chain, rather than reviewing them manually as part of the software delivery process.

Research from the [2019 State of DevOps Report (PDF)][6] shows that while moving away from traditional, formal change management processes is the ultimate goal, simply doing a better job of communicating the existing process and helping teams navigate it efficiently has a positive impact on software delivery performance. When team members have a clear understanding of the process to get changes approved for implementation, this drives high performance. This means they are confident that they can get changes through the approval process in a timely manner and know the steps it takes to go from "submitted" to "accepted" every time for all the types of changes they typically make.

### Ways to measure change approval in your systems

| Factor to test | What to measure |
| ---- | ---- |
| Can changes be promoted to production without manual change approvals? | The percentage of changes that do (or do not) require a manual change to be promoted to production.<br><br>**Tip:** You can also measure this factor based on risk profile: what percentage of low-, medium-, and high-risk changes require a manual change to be promoted to production? |
| Do production changes need to be approved by an external body before deployment or implementation? | The amount of time changes spend waiting for approval from external bodies. <br><br>**Tip:** As you shift approvals closer to the work, measure the amount of time spent waiting for approval from local approval bodies or reviewers.<br><br>You can also measure this factor by risk profile. Measure number or proportion of changes that require approval from external bodies, as well as the time spent waiting for those approvals.|
| Do you rely on peer review to manage changes? | Percentage of changes that are managed by peer-review. <br><br>You can also measure this factor by risk profile. |
| Do team members have a clear understanding of the process to get changes approved for implementation? | The extent to which team members are confident they can get changes through the approval process in a timely manner and know the steps it takes to go from "submitted" to "accepted" every time for all the types of changes they typically make. |

----------

## Customer feedback

In software projects, developers often work on products for months or years, sometimes for multiple releases without validating whether the features they're building are actually helping users solve their problems, or whether the features are being used at all.

[DevOps Research and Assessment (DORA) research shows (PDF)][7] that teams achieve higher performance when they work in organizations that utilize those capabilities and also do the following:

* Collect customer satisfaction metrics regularly.
* Seek out and attend to customer feedback on product and feature quality.
* Use this feedback to help design products and features.

### How to implement customer feedback

When a product or service, it's important to establish key metrics to gauge its success. These metrics help you understand whether you're solving a real problem, whether your solution is being adopted sufficiently quickly, and whether users continue to use it and recommend it to others. These metrics must be explicitly derived from how customers interact with the product. Using these metrics requires you to carefully gather and analyze customer feedback.

One set of metrics that's popular in consumer-facing SaaS products is **AARRR**: acquisition, activation, retention, referral, and revenue. (The order is sometimes different depending on who is presenting them.) These are sometimes known as pirate metrics because the acronym spells out a word that's stereotypically associated with how pirates talk.

The idea is to look at five key metrics and iterate your customer experience to improve on them:

* **Acquisition:** The percentage of users that come to your site who create an account.
* **Activation:** The percentage of acquired users that activate their account and use the service.
* **Retention:** The percentage of activated users that return to the service.
* **Referral:** The percentage of retained users who refer other users to the service.
* **Revenue:** The percentage of referring users who actually pay money for the service.

> If these metrics aren't suitable for your business or product, it's essential to discover some that are suitable, monitor those metrics regularly, and use them as a key driver of your product strategy.

The approach described here is not just for external-facing products. It applies equally to internal products and services that are built for other users in DL. Building internal tools requires exactly the same approach: early and frequent engagement with real users to ensure what you're building actually solves their problem. Otherwise, you might end up building and using tools that nobody uses. This is discouraging for those who work on the tools and frustrating for those who have to use tools they don't like. It also represents significant costs for the company in building a poor technology match for its users.

A team should use the following pattern in order to maximize their chances of successfully solving customer problems:

1. Gather customer feedback first, before defining any potential features.
2. Validate that you're solving a real problem.
3. Iterate on a solution that actually solves that problem (and nothing more).
4. Ensure the solution results in a viable business (for example, the cost is less than the anticipated revenue).
5. Track key metrics to gauge success (for example, AARRR).
6. Iterate through the above to improve those metrics.

Success requires you to not only deploy and release software quickly, but to address customer needs better, smarter, and faster. This can be achieved by experimenting more thoroughly than your competition. 

### Ways to improve customer feedback

The field of user experience design (UX) provides a framework for understanding improvement. Many organizations treat UX as just making a product UI look good. However, UX is about whether you're solving a real problem for users; more broadly, UX is about every experience a user has when they interact with your organization. It cannot be overemphasized how critical good UX is to building successful products and services.

It's essential to build customer feedback gathering into the delivery process. Every significant feature you build should start by considering the problem to be solved. This should include performing user research to determine possible solutions and select a candidate. User research should be analyzed before a single line of code is written.

For early-lifecycle products, teams should adopt the ideas put forward in [the lean startup][8] movement to validate the underlying business model of the product before any code is written. You should validate that you're solving a real problem, and then iterate on a solution that solves the problem while providing a viable business model.

You should follow a similar pattern for existing products that are implementing a new solution to a known business problem. When the solution design has been validated, you should create a prototype so that you can perform further research and testing. Only when testing validates that the feature achieves your goal should the full production feature be completed.

Many teams skip all of this work and fail. However, even strictly following these steps does not guarantee success. The point of this effort is to do as much as possible to minimize the risk of failure.

### Ways to measure customer feedback

Sophisticated data gathering isn't required to establish whether customer feedback is gathered, visible, and acted upon. The following questions can help you determine how well you're taking advantage of customer feedback for your product design:

* Do you have metrics that measure customer satisfaction? Are these updated and broadcast to teams regularly? Do you act on them?
* Do you validate all features before building them and perform user research with prototypes as part of delivery?
* Do you make changes to features based on this user research?
* Do you actively and regularly gather feedback from users and act on it?

----------

[1]: https://en.wikipedia.org/wiki/INVEST_(mnemonic)
[2]: https://martinfowler.com/bliki/FeatureToggle.html
[3]: https://continuousdelivery.com/2011/05/make-large-scale-changes-incrementally-with-branch-by-abstraction/
[4]: http://services.google.com/fh/files/misc/state-of-devops-2016.pdf
[5]: https://asq.org/quality-resources/lean/value-stream-mapping
[6]: https://cloud.google.com/devops/state-of-devops
[7]: https://services.google.com/fh/files/misc/state-of-devops-2016.pdf#page=35
[8]: https://wikipedia.org/wiki/Lean_startup

[21]: ./technical.md#continuous-testing
[22]: ./technical.md#continuous-integration
[23]: ./measurement.md#monitoring-and-observability
[24]: ./technical.md#trunk-based-development