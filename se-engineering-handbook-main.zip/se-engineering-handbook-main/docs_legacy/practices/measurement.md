# Measurement capabilities

**Must Do** practices:

* [Monitoring and observability](#monitoring-and-observability)
* [Proactive failure notification](#proactive-failure-notification)
* [Work in process limits](#work-in-process-limits)

**Should Do** practices:

* [Monitoring systems to inform business decisions](#monitoring-systems-to-inform-business-decisions)
* [Visual management capabilities](#visual-management-capabilities)

## Monitoring and observability

Good monitoring is a staple of high-performing teams. [DevOps Research and Assessment (DORA)][1] research shows that a comprehensive monitoring and observability solution, along with a number of 
other technical practices, positively contributes to [continuous delivery][21].


> **Monitoring** is tooling or a technical solution that allows teams to watch and understand the state of their systems. Monitoring is based on gathering predefined sets of metrics or logs.

> **Observability** is tooling or a technical solution that allows teams to actively debug their system. Observability is based on exploring properties and patterns not defined in advance.

To do a good job with monitoring and observability, your teams should have the following:

* Reporting on the overall health of systems (Are my systems functioning? Do my systems have sufficient resources available?).
* Reporting on system state as experienced by customers (Do my customers know if my system is down and have a bad experience?).
* Monitoring for key business and systems metrics.
* Tooling to help you understand and debug your systems in production.
* Tooling to find information about things you did not previously know (that is, you can identify unknown unknowns).
* Access to tools and data that help trace, understand, and diagnose infrastructure problems in your production environment, including interactions between services.

### How to implement monitoring and observability

Monitoring and observability solutions are designed to do the following:

* Provide leading indicators of an outage or service degradation.
* Detect outages, service degradations, bugs, and unauthorized activity.
* Help debug outages, service degradations, bugs, and unauthorized activity.
* Identify long-term trends for capacity planning and business purposes.
* Expose unexpected side effects of changes or added functionality.

As with all DevOps capabilities, installing a tool is not enough to achieve the objectives, but tools can help or hinder the effort. Monitoring systems should not be confined to a single individual or team within an organization. Empowering all developers to be proficient with monitoring helps develop a culture of data-driven decision-making and improves overall system debuggability, reducing outages.

There are a few keys to effective implementation of monitoring and observability. First, your monitoring should tell you what is broken and help you understand why, before too much damage is done. The key metric in the event of an outage or service degradation is time-to-restore (TTR). A key contributor to TTR is the ability to rapidly understand what broke and the quickest path to restoring service (which may not involve immediately remediating the underlying problems).

There are two high-level ways of looking at a system: blackbox monitoring, where the system's internal state and mechanisms are not made known, and white box monitoring, where they are.

For more information, see "Monitoring Distributed Systems" in the [Site Reliability Engineering][2] book.

#### Blackbox monitoring

In a blackbox (or synthetic) monitoring system, input is sent to the system under examination in the same way a customer might. This might take the form of HTTP calls to a public API, or RPC calls to an exposed endpoint, or it might be calling for an entire web page to be rendered as a part of the monitoring process.

Blackbox monitoring is a sampling-based method. The same system that is responsible for user requests is monitored by the blackbox system. A blackbox system can also provide coverage of the target system's surface area. This could mean probing each external API method. You might also consider a representative mixture of requests to better mimic actual customer behavior. For example, you might perform 100 reads and only 1 write of a given API.

You can govern this process with a scheduling system, to ensure that these inputs are made at a sufficient rate in order to gain confidence in their sampling. Your system should also contain a validation engine, which can be as simple as checking response codes, or matching output with regular expressions, up to rendering a dynamic site in a headless browser and traversing its DOM tree, looking for specific elements. After a decision is made (pass, fail) on a given probe, you must store the result and metadata for reporting and alerting purposes. Examining a snapshot of a failure and its context can be invaluable for diagnosing an issue.

#### White box monitoring

Monitoring and observability rely on signals sent from the workload under scrutiny into the monitoring system. This can generally take the form of the three most common components: *metrics*, *logs*, and *traces*. Some monitoring systems also track and report events, which can represent user interactions with an entire system, or state changes within the system itself.

**Metrics** are simply measurements taken inside a system, representing the state of that system in a measurable way. These are almost always numeric and tend to take the form of counters, distributions, and gauges. There are some cases where string metrics make sense, but generally numeric metrics are used due to the need to perform mathematical calculations on them to form statistics and draw visualizations.

**Logs** can be thought of as append-only files that represent the state of a single thread of work at a single point in time. These logs can be a single string like "User pushed button X" or a structured log entry which includes metadata such as the time the event happened, what server was processing it, and other environmental elements. Sometimes a system which cannot write structured logs will produce a semi-structured string like `[timestamp] [server] message [code]` which can be parsed after the fact, as needed. Log entries tend to be written using a client library like log4j, structlog, bunyan, log4net, or Nlog. Log processing can be a very reliable method of producing statistics that can be considered trustworthy, as they can be reprocessed based on immutable stored logs, even if the log processing system itself is buggy. Additionally, logs can be processed in real time to produce log-based metrics.

**Traces** are composed of spans, which are used to follow an event or user action through a distributed system. A span can show the path of a request through one server, while another span might run in parallel, both having the same parent span. These together form a trace, which is often visualized in a waterfall graph similar to those used in profiling tools. This lets developers understand time taken in a system, across many servers, queues, and network hops. A common framework for this is [OpenTelemetry][3], which was formed from both [OpenCensus][4] and [OpenTracing][5].

Metrics, logs, and traces can be reported to the monitoring system by the server under measurement, or by an adjacent agent that can witness or infer things about the system.

#### Instrumentation

To make use of a monitoring system, your system must be *instrumented*. That is, code must be added to a system in order to expose its inner state. For example, if a simple program contains a pool of connections to another service, you might want to keep track of the size of that pool and the number of unused connections at any given time. In order to do so, a developer must write some code in the connection pool logic to keep track of when connections are formed or destroyed, when they are handed out, and when they are returned. This might take the form of log entries or events for each of these, or you might increment and decrement a gauge for the size of the queue, or you might increment a counter each time a connection is created, or each time a pool is expanded.

#### Correlation

Metrics can be collected from the application, as well as from its underlying systems, such as the JVM, guest OS, hypervisor, node OS, and the hardware itself. Note that as you go further down in a stack, you might start conflating metrics that are shared across workloads. For example, if a single machine serves several applications, watching the disk usage might not correspond directly to the system under observation. Correlating issues across applications on a shared system, however, can help you pin down a contributing factor (such as a slow disk). Drilling down from a single application to its underlying system metrics, then pulling up to show all similarly affected applications can be very powerful.

> Measuring a distributed system means having observability in many places and being able to view them all together. This might mean both a frontend and its database, or it might mean a mobile application running on a customer's device, a cloud load balancer, and a set of microservices. Being able to connect data from all of these sources in one place is a fundamental requirement in modern observability tools.

#### Computation

After you collect data from various sources for your system, you generate statistics and aggregate data across various realms. This might be cohorts of users, regions of your compute footprint, or geographic locations of your customers. Being able to develop these statistics on-the-fly based on raw events is very advantageous but can be costly both in terms of storage and real-time compute capacity required.

When you choose your tooling and plan your instrumentation, you must consider *cardinality* and *dimensionality*. These two aspects of metric collection can greatly affect your ability to scale your ability to observe a system.

**Cardinality** is the measure of distinct values in a system. For example, a field like `cpu-utilization` tends to need a range between 0 and 100. However, if you keep track of a user's unique identifier, they're all distinct, thus if you have 1M users, you have a cardinality of 1M. This makes a huge difference.

**Dimensionality** is the ability to record more than just a single value along with a timestamp, as you might have in a simple time-series database that backs a monitoring system. Simply recording the value of a counter, for example requests-sent, might initially record just the value of the number of requests sent up to this point in time like `{time=x, value=y}`. However, as with structured logs, you might want to also record some environmental data, resulting in something like: `{time=x, value=y, server=foo, cluster=123, environment=prod, service=bar}`. Combining high cardinality and high dimensionality can result in dramatically increased compute and storage requirements, to the point where monitoring might not work as expected! This needs to be understood by developers who write dynamically generated data and metadata into monitoring systems.

#### Learning and improving

Part of operating a system is learning from outages and mistakes. The process of writing retrospectives or postmortems with corrective actions is well documented. One outcome of this process is the development of improved monitoring. It is critical to a fast-moving organization to allow their monitoring systems to be updated quickly and efficiently by anyone within the organization. Monitoring configuration is critical, so changes should be tracked by means of [review and approval](process.md#streamlining-change-approval), just as with code development and delivery. Keeping your monitoring configuration in a [version control system](technical.md#version-control) is a good first step in allowing broad access to the system, while maintaining control on this critical part of your system. Developing automation around deploying monitoring configuration through an automation pipeline can also improve your ability to ensure these configurations are valid and applied consistently. After you treat your monitoring configuration as code, these improvements can all be accomplished by means of a [deployment automation](technical.md#deployment-automation) process, ideally the same system used by the rest of your team.

### Common pitfalls of implementing monitoring and observability

```
When developing a system for monitoring and observability, you should be aware that there generally isn't a simple plug-and-play solution. Any decent monitoring system will require a deep understanding of each component that you want to measure, as well as direct manipulation of the code to instrument those systems. 
```
> Avoid having a single monitoring person or dedicated team who is solely responsible for the system.

This will not only help you prevent a single point of failure, but also increase your ability to understand and improve your system as an entire organization. Monitoring and observability needs to be built into the baseline knowledge of all your developers. A common pitfall here is for the operation team, NOC, or other similar team to be the only ones allowed to make changes to a monitoring system. This should be avoided and replaced with a system that follows CD patterns.

A common **anti-pattern** in writing alerts in monitoring systems is to attempt to enumerate all possible error conditions and write an alert for each of them. We call this *cause-based alerting*, and you **should avoid it as much as possible**. Instead, you should focus on *symptom-based alerting*, which only alerts you when a user-facing symptom is visible or is predicted to arise soon. You should still be able to observe non-user-facing systems, but they shouldn't be directly alerting on-call engineers if there are no user-facing symptoms. Note that the term user-facing can also include users internal to DL.

When generating alerts, you should consider how they are delivered. Your alerts should have multiple pathways to on-call engineers, including but not limited to: SMS delivery, dedicated mobile apps, automated phone calls, or email. A common pitfall is to email alerts to an entire team via an email distribution list. This can quickly result in ignored alerts due to [diffusion of responsibility][6]. Another common failure is simply a poor [signal-to-noise ratio][7]. If too many alerts are not actionable, or result in no improvement, the team will easily miss those alerts that are meaningful and possibly very important, a problem known as [alarm fatigue][8]. Any method to silence or suppress some set of alerts should be tracked very carefully to ensure it is not too broad or applied too often.

### How to measure monitoring and observability

When implementing a monitoring and observability system in DL, you can track some internal metrics to see how well you're doing. Here are some that you might wish to track with a monthly survey, or possibly by automatically analyzing your postmortems or alerting logs.

* **Changes made to monitoring configuration.** How many pull requests or changes per week are made to the repository containing the monitoring configuration? How often are these changes pushed to the monitoring system? (Daily? Batched? Immediately on PR?)
* **"Out of hours" alerts.** What percentage of alerts are handled at night? While some global businesses have a follow-the-sun support model which makes this a non-issue, it can be an indication that not enough attention has been paid to leading indicators of failures. Regular night-time alerts can lead to alert fatigue and burned-out teams.
* **Team alerting balance.** If you have teams in different locations responsible for a service, are alerts fairly distributed and addressed by all teams? If not, why?
* **False positives.** How many alerts resulted in no action, or were marked as "Working as Intended"? Alerts which aren't actionable and which haven't helped you predict failures should be deleted.
* **False negatives.** How many system failures happened with no alerting, or alerting later than expected? How often do your postmortems include adding new (symptom-based) alerts?
* **Alert creation.** How many alerts are created per week (total, or grouped by severity, team, etc.)?
* **Alert acknowledgement.** What percentage of alerts are acknowledged within the agreed deadline (such as 5 minutes, 30 minutes)? Sometimes this is coupled with or can be tracked by a metric like alert fall-through when a secondary on-call person is notified for an alert.
* **Alert silencing and silence duration.** How many alerts are in a silenced or suppressed state per week? How many are added to this pool, how many removed? If your alert silencing has an expiration system, how many silences are extended to last longer than initially expected? What is the mean and maximum silence period? (A fun one is "how many silences are effectively 'infinite'?")
* **Unactionable alerts.** What percentage of alerts were considered "unactionable"? That is, the engineer alerted was not able to immediately take some action, either out of an inability to understand the alert implication, or due to a known issue. Unactionable alerts are a well known source of toil.
* **Usability: alerts, runbooks, dashboards.** How many graphs are on your dashboards? How many lines per graph? Can teams understand the graphs? Is there explanatory text to help out new engineers? Do people have to scroll and browse a lot to find the information they need? Can engineers navigate from alert to playbook to dashboards effectively? Are the alerts named in such a way to point engineers in the right direction? These might be measured by surveys of the team, over time.
* **MTTD, MTTR, impact.** The bottom line is time to detect, time to resolve, and impact. Consider measuring the "area under the curve" of the time that the outage was affecting customers times the number of customers affected. This can be estimated or done more precisely with tooling.

By tracking some or all of these metrics, you'll start to gain a better understanding of how well your monitoring and observability systems are working. Breaking these measurements down by product, by operational team, or other methods will give you insight not only into the health of your products but also your processes and your people.

---------

## Proactive failure notification

Proactive failure notification is the practice of generating notifications when monitored values approach known failure thresholds, and not waiting for the system to alert you it has already failed — or worse, to find out from customers that your application or service is down. Using this approach, you can identify and potentially resolve issues before they become serious or start to impact your users.

The [2014 DevOps Research and Assessment (DORA) (PDF)][9] research showed that proactive monitoring is a significant predictor of software delivery performance. According to DORA research, teams that use proactive notification can diagnose and solve problems quickly. When failures are instead primarily reported by a source external to the operations team, such as by the network operations center (NOC) — or worse, by customers — rather than internal monitoring, performance suffers.

### How to implement proactive failure notification

**Use alerting rules.** You should generate failure notifications using specific alerting rules. Alerting rules define the conditions under which an alert is generated and the notification channel for that alert.

**Use thresholds.** Alerting rules should use thresholds for the metrics you monitor that indicate real trouble. Monitoring thresholds trigger alerting rules, which generate notifications when metric levels cross threshold values.

**Choose thresholds carefully.** Choose thresholds to only generate alerts when the threshold actually predicts an issue. That is, don't arbitrarily select a value. Generally, you should identify which value levels begin to cause user-facing impact, and then trigger an alert notification at some percentage before that value is crossed.

    For example, you might choose to trigger an alert notification when average response time for pages is within 20% of a threshold at which you know users start becoming frustrated and calling support.

**Hold incident post-mortems.** When you hold post-mortems following incidents, determine which indicators could have predicted the incident and monitor them in the future.

**Plan a notification strategy.** If a notification requires no action or the same action every time, you should automate the response. You should also consider the volume of notifications for events. A deluge of notifications during an event might be distracting rather than useful. When people are exposed to a large number of alarms, they can become desensitized to them (a problem known as ["alert fatigue"][8]) leading to longer response times or missed alarms. Regularly review notifications and delete those that cannot be acted upon.

### Ways to improve failure notification

Configure alerts to notify your key teams when something goes wrong in your systems early, long before it moves to the operations team or to a customer. Tactics include:

* Configuring alerts in logging and monitoring systems to appropriate levels.
* Configuring alerts to make sure they notify people and teams who can fix the problem.
* Proactively monitoring system health based on threshold warnings before system failures happen.
* Proactively monitoring system health based on rate of change warnings.
* Ensuring that only relevant alerts are occurring, and that the team isn't receiving too many alerts. Take a hard look at which alerts are irrelevant. Disable irrelevant alerts and turn relevant monitoring alerts back on. Disabling all alerts is bad practice.

### Ways to measure failure notifications

Instrumenting proactive monitoring is straightforward. The components to capture are:

1. The extent to which failure alerts from logging and monitoring systems are captured and used.
2. The extent to which system health is proactively monitored using threshold warnings.
3. The extent to which system health is proactively monitored using rate of change warnings.

To make sure you are capturing different aspects of your system, you should monitor metrics in at least two different ways. 

> For example, you might set a metric threshold that triggers alerts if a metric rises or falls below a value over a given time window, and a rate of change, which triggers alerts when a metric value change rate is higher or lower than expected.

---------

## Work in process limits

When faced with too much work and too few people to do it, **rookie managers** assign people to work on multiple tasks in the hope of increasing throughput. Unfortunately, the result is that tasks take longer to get done, and the team burns out in the process.

Instead, you should do the following:

* Prioritize work
* Limit how much people work on
* Focus on completing a small number of high-priority tasks

The manufacturing sector has a long history of limiting the amount of work in process (WIP). Factories don't hold large amounts of inventory. Instead, when a customer orders a product, parts are made in-house, on-demand or are pulled from suppliers upstream as needed, and the company then assembles the product just in time. When you implement this process correctly (following a [number of principles and practices][10]), you end up with faster lead times, higher quality, lower costs, and less waste.

### How to implement work in process limits

**Use a storyboard.** In technology, our inventory is invisible. There's no shop floor with piles of work or assembly line where we can see the progression of work. A simple way to see inventory is to write all the work the team is doing on index cards and stick them on a board. In agile methods, this is called creating a storyboard.

![Kanban with WIP](../img/practices/wip-1.png)

A common practice with storyboards is to ink a dot onto a card for each day the card has been worked on. The team can easily see which work is blocked or taking longer than it should.

**Specify limits.** For each column on the board, specify the WIP limit, or how many cards can be in that column at one time. After the WIP limit is reached, no more cards can be added to the column, and the team must wait for a card to move to the next column before pulling the highest priority one from the previous column.

    Only by imposing WIP limits and following this pull-based process do you actually create a Kanban board.

**Determine WIP limits by team capacity.** For example, if you have four pairs of developers, don't allow more than four cards in the "in development" column.

**Stick to the limits.** WIP limits can result in teams sitting idle, waiting for other tasks to be completed. Don't increase WIP limits at this point. Instead, work to improve your processes to address the factors that are contributing to these delays. For example, if you're waiting for an environment to test your work, you might offer to help the team that prepares environments improve or streamline their process.

### Common pitfalls with work in process limits

Teams implementing WIP limits often encounter the following pitfalls:

* **Not counting invisible work.** It's important to visualize the whole value stream from idea to customer, not just the portion of the work that the team is responsible for. Without doing this, it's impossible to see the actual bottlenecks, and you'll end up addressing problems that aren't actually significant constraints to the flow of work. (This is also known as local optimums.)
* **Setting WIP limits that are much too big.** Make sure your WIP limits aren't too big. If your team is splitting their time between multiple tasks or projects, that's a good sign your WIP limits are too high.
* **Relaxing WIP limits.** Don't relax your WIP limits when people are idle. Instead, those people should be helping in other parts of the value stream, addressing the problems that are leading to constraints elsewhere.
* **Quitting while you're ahead.** If your WIP limits are easy to achieve, reduce them. The point of WIP limits is to expose problems in the system, so they can be addressed. Another thing to look for is when there are too many columns on your visual display. Instead, look for ways to simplify the delivery process and reduce hand-offs. Process improvement work is key to increasing flow.

DevOps Research & Assessment research shows that WIP limits help drive improvements in software delivery performance, particularly when they are combined with [the use of visual displays](#visual-management-capabilities) and [feedback loops from monitoring](#monitoring-systems-to-inform-business-decisions).

### Ways to improve work in process limits

* **Make your work visible.** As you do this, try to surface all of your work, making all of it visible, to several teams and stakeholders. (See [visual displays](#visual-management-capabilities) for details).
* **Set WIP limits that match your team's capacity for work.**
    * Account for activities like production support, meeting time and technical debt.
    * Don't allow more WIP in any given part of the process than you have people to work on tasks.
    * Don't require people to split their time between multiple tasks.
    * When a particular piece of work is completed, move the card representing that work to the next column, and pull the highest priority piece of work waiting in the queue.
* **Set up a weekly meeting for stakeholders to prioritize all work in order.** Let stakeholders know that if they don't attend, their work won't get done.
* **Work to increase flow.** Measure the lead time of work through the system. Record the date that work started on a card and the date work ended. From this information, you can create a running frequency histogram, which shows the number of days work takes to go through the system. This data will allow you to calculate the mean lead time, as well as variability, with the goal of having low variability: high variability means you are not scoping projects well or have significant constraints outside your team. High variability also means your estimates and predictions about future work will not be as reliable.
* **Improve work processes.** Reduce hand-offs, simplify and automate tasks, and think about how to collaborate better to get work done. After you've removed some obstacles and things feel comfortable, reduce your WIP limits to reveal the next set of obstacles. The ideal is single-piece flow, which means that work flows from idea to customer with minimal wait time or rework. This ideal may not be achievable, but it acts as a "true north" to guide the way in a process of continuous improvement.

### Ways to measure work in process limits

WIP limits are something you impose rather than measure, but it's important to keep finding ways to improve. During your regular retrospectives, ask the following questions:

* Do we know the mean lead time and variability for our entire value stream (from idea to customer)?
* Are we finding ways to increase flow and thus reduce lead time for work?
* Are our WIP limits surfacing obstacles that prevent us increasing flow?
* Are we doing things about those obstacles?

---------

## Monitoring systems to inform business decisions

Monitoring is the process of collecting, analyzing, and using information to track applications and infrastructure in order to guide business decisions. Monitoring is a key capability because it gives you insight into your systems and your work. Properly implemented, monitoring also gives you rapid feedback so that you can quickly find and fix problems early in the software development lifecycle.

Monitoring also helps you communicate information about your systems to people in other areas of the software development and delivery pipeline, and to other parts of the business. Knowledge acquired downstream in operations might get integrated into upstream teams, such as development and product management. For example, the knowledge gained from operating a highly scalable application that uses a NoSQL database as a data store can be valuable information for developers as they build a similar application.

This knowledge transfer allows teams to quickly identify learnings, whether they stem from a production issue, a deployment error, or your customer usage patterns. You can then share these learnings across your organization to help people and systems improve.

### How to implement monitoring

The following elements are key to effective monitoring:

* Collecting data from key areas throughout the value chain, including application performance and infrastructure.
* Using the collected data to make business decisions.

#### Collecting data

To collect data more effectively, you should implement monitoring solutions, either as homegrown services or managed services, that give visibility into development work, testing, QA, and IT operations. Make sure that you choose metrics that are appropriate for function and for your business.

#### Using data to make business decisions

When you transform and visualize the collected data, you make it accessible to different audiences and help them make decisions. For example, you might want to share operations data upstream. You can also integrate this data as appropriate into reports and briefings, and use it in meetings to make informed business decisions. In this case, appropriate means relevant, timely, accurate, and easy to understand.

In these meetings, be sure to also provide context, to help those who might not be familiar with the data understand how it pertains to the discussion and how it can inform the decisions to be made. For example, you might want to know how to answer the following questions:

* Are these values relatively high or low?
* Are they expected?
* Do you anticipate changes?
* How is this data different from historical reports?
* Has your technology or infrastructure impacted the numbers in interesting or non-obvious ways?

### Common pitfalls in monitoring

The following pitfalls are common when monitoring systems:

* **Monitoring reactively.** For example, only getting alerted when the system goes down, but not using monitoring data to help alert when the system approaches critical thresholds.
* **Monitoring too small a scope.** For example, monitoring one or two areas rather than the full software development and delivery pipeline. This pitfall highlights metrics, focusing only on the areas that are measured, which might not be the optimal areas to monitor.
* **Focusing on local optimizations.** For example, focusing on reducing the response time for one service's storage needs without evaluating whether the broader infrastructure could also benefit from the same improvement.
* **Monitoring everything.** By collecting data and reporting on everything your system, you run the risk of over-alerting or drowning in data. Taking a thoughtful approach to monitoring can help draw attention to key areas.

### Ways to improve monitoring

Focus on:

1. **Collecting data from key areas throughout the value chain.**<br><br>
By analyzing the data that you collect and doing a gap analysis, you can help ensure that you collect the right data for your organization.

2. **Using the collected data to make business decisions.** <br><br>
The data that you collect should drive value across the organization, and the metrics that you select must be meaningful to your organization. Meaningful data can be used by many teams, from DevOps to Finance.<br><br>
It's also important to find the right medium to display the monitoring information. Different uses for the information demand different presentation choices. Real-time dashboards might be most useful to the DevOps team, while regularly generated business reports might be useful for metrics measured over a longer period.<br><br>
The most important thing is to ensure the data is available, shared, and used to guide decisions. If the best you can do to kick things off is a shared spreadsheet, use that. Then graduate to fancy dashboards later. Don't let perfect be the enemy of good enough.

### Ways to measure monitoring

Effective monitoring helps drive performance improvements in software development and delivery. However, measuring the effectiveness of monitoring can be difficult to instrument in systems. Although you might be able to automatically measure how much data is being collected from your systems and the types of that data, it's more difficult to know if or where that data is being used.

To help you gauge the effectiveness of monitoring in DL, consider the extent to which people agree or disagree with the following statements:

* Data from application performance monitoring tools is used to make business decisions.
* Data from infrastructure monitoring tools is used to make business decisions.

---------

## Visual management capabilities

Teams should adopt [lean development practices][11] to display key information about their processes in team areas where everybody can see it. Visual management boards can create a shared understanding of where the team is in terms of its operational effectiveness. They can also help identify and remove obstacles in the path to higher performance. 

In the DL hybrid working environment it is even more important that the visuals are accessible to everyone from any location without physically being present in the room.

### How to implement visual management

There are many kinds of visual displays and dashboards that are common in the context of software delivery:

* **Card walls, storyboards or Kanban boards**, either physical or virtual, with index cards that represent in-progress work items.
* **Dashboards or other visual indicators**, such as continuous integration systems with monitors or traffic lights to show whether the build is passing or failing. Effective visual displays are created, updated, and perhaps discarded by teams in response to issues that the team is currently interested in addressing.
* **Burn-up or burn-down charts** (for example, cumulative flow diagrams) showing the cumulative status of all work being done. These allow the team to project how long it will take to complete the current backlog.
* **Deployment pipeline monitors** showing what the latest deployable build is, and whether stages in the pipeline are failing, such as acceptance tests or performance tests.
* **Monitors showing production telemetry**, such as the number of requests being received, latency statistics, cumulative 404 and 500 errors, and which pages are most popular.

When combined with the use of [WIP limits](#work-in-process-limits) and using feedback from production to make business decisions, visual management displays can contribute to higher levels of delivery performance.

### Ways to improve visual management

The goal of visual management tools is to provide fast, easy-to-understand feedback, so you can build quality into the product. This feedback helps the team identify defects in the product and understand whether some part of the system is not performing effectively, which helps them address the problem. In order to be effective, such systems must do the following:

* **Reflect information that the team cares about and will act on.** Having build monitors does no good if teams don't care whether the display shows an issue (for example, showing that the build status is red, meaning broken), and won't actually act on this information by swarming to fix the issue.
* **Be easy to understand.** It should be possible to tell at a glance from across the room whether something needs attention. If there is a problem, teams should know how to perform further diagnosis or fix the problem.
* **Give the team information that is relevant to their work.** While it's important to collect as much data as possible about the team's work, the display should present only data that is relevant to the team's goals. In the face of information overload, particularly information that cannot be acted upon, people ignore visual management displays; the displays just become noise. The additional data can be accessed and used by the team when they are swarming to fix the problem.
* **Be updated as part of daily work.** If the team lets the data go stale or become inaccurate, they will ignore the visual displays, and the displays will no longer be a useful beacon when important issues arise. If displays are currently displaying stale or inaccurate data, investigate the cause: is the data not related to the team's goals? What data would make the display an important and compelling information source for the team?

### Ways to measure visual management

Discover the existing state of the work system. Find a way to display the key information about the existing state, as well as the state you want. Make sure that this information is displayed only to the required precision.

Review the visual displays as part of regular retrospectives. Ask these questions:

* Are the displays giving you the information you need?
* Is the information up to date?
* Are people acting on this information?
* Is the information (and the actions people take in response to it) contributing to measurable improvement towards a goal that the team cares about?
* Does everybody know what the goals are?
* Can you look at your visual management displays and see the key process metrics you care about?

If the answer to any of these questions is no, investigate further:

* Can you change the information or how it's displayed?
* Can you get rid of the display altogether?
* Can you create a new display? What would a prototype look like? What are the most important pieces of information to include, and how precise do they need to be to help you solve your problems and achieve your goals?

---------

[1]: https://cloud.google.com/devops
[2]: https://landing.google.com/sre/sre-book/chapters/monitoring-distributed-systems/
[3]: https://opentelemetry.io/
[4]: https://opencensus.io/
[5]: https://opentracing.io/
[6]: https://wikipedia.org/wiki/Diffusion_of_responsibility
[7]: https://wikipedia.org/wiki/Signal-to-noise_ratio
[8]: https://wikipedia.org/wiki/Alarm_fatigue
[9]: https://services.google.com/fh/files/misc/state-of-devops-2014.pdf
[10]: https://leanmanufacturingtools.org/just-in-time-jit-production/
[11]: https://wikipedia.org/wiki/Lean_software_development

[21]: ./technical.md#continuous-delivery