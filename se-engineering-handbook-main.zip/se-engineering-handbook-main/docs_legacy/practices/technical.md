# Technical capabilities

**Must Do** practices:
* [Version control](#version-control)
* [Continuous Integration (CI)](#continuous-integration)
* [Deployment automation](#deployment-automation)
* [Continuous testing](#continuous-testing)
* [Shift left on security](#shifting-left-on-security)

**Should Do** practices:
* [Trunk-based development](#trunk-based-development)
* [Continuous delivery](#continuous-delivery)
* [Architecture](#architecture)
* [Test data management](#test-data-management)
* [Database change management](#database-change-management)
* [Cloud infrastructure](#cloud-infrastructure)
* [Code maintainability](#code-maintainability)
* [Empowering teams to choose tools](#empowering-teams-to-choose-tools)

## Version control

In order to improve software delivery, teams need to use version control for source code, test and deployment scripts, infrastructure and application configuration information, and the many libraries and packages they depend upon. In the version control system, teams must be able to query the current (and historical) state of their environments. Version control also offers direct benefits such as disaster recovery and auditability.

A version control system records changes to files stored in the system. These files can be source code, assets, or other documents that might be part of a software development project. Teams make changes in groups called commits or revisions. Each revision, along with metadata related to the revision (such as who made the change and when), is stored in the system. This allows teams to commit, compare, merge, and restore to previous revisions. It also minimizes risks by establishing a way to revert objects in production to previous versions.

Teams must be able to restore production services repeatedly and predictably (and, ideally, quickly) even when catastrophic events occur, so they must check in the following assets to their shared version control repository:

* All application code and dependencies (for example, libraries and static content)
* Any script used to create database schemas, application reference data, and so on
* All environment creation tools and artifacts described in the previous step (for example, AMI image building scripts or Ansible recipes)
* Any file used to create and compose containers (for example, Docker files and buildpacks)
* All supporting automated tests and any manual test scripts
* Any script that supports code packaging, deployment, database migration, and environment provisioning
* Supporting project artifacts (for example, requirements documentation, deployment procedures, and release notes)
* Container orchestration (for example, Kubernetes configuration, AWS EKS, AWS ECS)
* All cloud configuration files (for example, AWS Cloudformation templates, Microsoft Azure Stack DSC files and Terraform files)
* Any other script or configuration information required to create infrastructure that supports multiple services (for example, enterprise service buses, database management systems, DNS zone files, configuration rules for firewalls, and other networking devices)

### Ways to measure version control

To measure how effectively your teams are using version control in their systems, try these recommendations:

* **Application code.** Do you use version control for application code? What percentage of application code do you store in version control? How easily and quickly can a team recover application code from the version control system?

* **System configurations.** Do you use version control for system configurations? What percentage of system configurations do you store in version control? How easily and quickly can teams reconfigure systems from version control?

* **Application configuration.** Do you use version control for application configurations? What percentage of application configurations do you store in version control? How easily and quickly can teams reconfigure applications from code in the version control system?

* **Scripts for automating build and configuration.** Do you keep scripts for automating build and configuration in version control? What percentage do you store in version control? How quickly and easily can you reprovision systems by using scripts from version control?

----------

## Continuous integration

Software systems are complex, and an apparently simple, self-contained change to a single file can have unintended side effects on the overall system. When a large number of developers work on related systems, coordinating code updates is a hard problem, and changes from different developers can be incompatible.

[CI follows the principle][1] that if something takes a lot of time and energy, you should do it more often, forcing you to make it less painful. By creating rapid feedback loops and ensuring that developers work in small batches, CI enables teams to produce high quality software, to reduce the cost of ongoing software development and maintenance, and to increase the productivity of the teams.

### How to implement CI

Developers should integrate all their work into the main version of the code base (known as trunk, main, or mainline) on a regular basis. [DevOps Research and Assessment (DORA) research][2] shows that teams perform better when developers **merge their work into trunk at least daily**. A set of automated tests is run both before and after the merge in order to validate that the changes don't introduce regression bugs. If these automated tests fail, the team stops what they are doing to fix the problem immediately.

The key elements in successfully implementing continuous integration are:

* Each commit should trigger a build of the software.
* Each commit should trigger a series of automated tests that provide feedback in a few minutes.

To implement these elements, you need the following:

* **An automated build process.** The first step in CI is having an automated script that creates packages that can be deployed to any environment. The packages created by the CI build should be authoritative and used by all downstream processes. These builds should be numbered and repeatable. You should run your build process successfully at least once a day.
* **A suite of automated tests.** If you don't have any, start by writing a handful of unit and acceptance tests (PDF) that cover the high-value functionality of your system. Make sure that the tests are reliable. That way, when they fail, you know there's a real problem, and when they pass, you're confident there are no serious problems with the system. Then ensure that all new functionality is covered by tests. Those tests should run quickly, to give developers feedback as soon as possible. Your tests should run successfully at least once a day. Ultimately, if you have performance and acceptance tests, the developers should get feedback from them daily.
* **A CI system that runs the build and automated tests on every check-in.** The system should also make the status visible to the team. You can have some fun with this—for example, you can use klaxons or traffic lights to indicate when the build is broken. Don't use email notifications; many people ignore email notifications or create a filter that hides notifications. Notifications in a chat system is a better and more popular way of achieving this.

Continuous integration, as defined by [Kent Beck and the Extreme Programming community][1] where the term originated, also includes two further practices, which are also predictive of higher software delivery performance:

* The practice of [trunk-based development](#trunk-based-development) in which developers work off trunk/mainline in small batches. They merge their work into a shared trunk/mainline at least daily, rather than working on long-lived feature branches.
* An agreement that when the build breaks, fixing it should take priority over any other work.

### Ways to measure CI

| Factor to test | What to measure |
|---|---|
| Code commits trigger a build of the software | The percentage of code commits that result in a software build without manual intervention. |
| Code commits trigger a series of automated tests | The percentage of code commits that result in a suite of automated tests being run without manual intervention. |
| Automated builds and tests are executed successfully every day | The percentage of automated builds and the percentage of automated tests that are executed successfully every day. |
| Current builds are available to testers for exploratory testing	| The availability of builds to testers, or its inverse, namely the unavailability of builds to testers. |
| Developers get feedback from the acceptance and performance tests every day | The availability of feedback to developers from acceptance and performance tests— that is, the percentage of tests that provide feedback that is available to developers within a day. |
| Broken builds are fixed immediately | The time it takes between the build breaking and having it fixed, either with a check-in that fixes the problem, or by reverting the breaking change. |

----------

## Deployment automation

Deployment automation is what enables teams to deploy software to testing and production environments with the push of a button. **Automation is essential to reduce the risk** of production deployments. It's also essential for providing fast feedback on the quality of your software by allowing teams to do comprehensive testing as soon as possible after changes.

An automated deployment process has the following inputs:

* Packages created by the continuous integration (CI) process (these packages should be deployable to any environment, including production).
* Scripts to configure the environment, deploy the packages, and perform a deployment test (sometimes known as a smoke test).
* Environment-specific configuration information.


  The scripts and configuration information have to be in version control. Your deployment process should download the packages from an artifact repository.

The scripts usually perform the following tasks:

1. Prepare the target environment, perhaps by installing and configuring any necessary software, or by starting up a virtual host from a pre-prepared image in a cloud provider such as AWS.
2. Deploy the packages.
3. Perform any deployment-related tasks such as running database migration scripts.
4. Perform any required configuration.
5. Perform a deployment test to make sure that any necessary external services are reachable, and that the system is functioning.

### How to implement deployment automation

When you design your automated deployment process, we recommend that you follow these best practices:

* **Use the same deployment process for every environment, including production.** This rule helps ensure that you test the deployment process many times before you use it to deploy to production.
* **Allow anyone with the necessary credentials to deploy any version of the artifact to any environment on demand in a fully automated fashion.** If you have to create a ticket and wait for someone to prepare an environment, you don't have a fully automated deployment process.
* **Use the same packages for every environment.** This rule means that you should keep environment-specific configuration separate from packages. That way, you know that the packages you are deploying to production are the same ones that you tested.
* **Make it possible to recreate the state of any environment from information stored in version control.** This rule helps ensure that deployments are repeatable, and that in the event of a disaster recovery scenario, you can restore the state of production in a deterministic way.

A team should select a tool that you can use autonomously to make deployments, that records which builds are currently in each environment, and that records the output of the deployment process for audit purposes.

### Ways to improve deployment automation

The first step is to document the existing deployment process in a common tool that developers and operations have access to, such as [Confluence](https://directline.atlassian.net/wiki/spaces). Then work to incrementally simplify and automate the deployment process. This approach typically includes the following tasks:

* Packaging code in ways suitable for deployment.
* Creating pre-configured virtual machine images or containers.
* Automating the deployment and configuration of middleware.
* Copying packages or files into the production environment.
* Restarting servers, applications, or services.
* Generating configuration files from templates.
* Running automated deployment tests to make sure the system is working and correctly configured.
* Running testing procedures.
* Scripting and automating database migrations.

Work to remove manual steps, implement idempotence and order independence wherever possible, and leverage the capabilities of your infrastructure platform wherever possible. Remember: deployment automation should be as simple as possible.

### Ways to measure deployment automation

Measuring deployment automation is straightforward.

* **Count the number of manual steps in your deployment process.** Work to reduce those steps systematically. The number of manual steps increases the deployment time as well as the opportunity for error.
* **Measure the level (or percentage) of automation in your deployment pipeline.** Work to increase that level continually.
* **Determine the time spent on delays in the deployment pipeline.** As you work to reduce these delays, understand where and why code stalls in your deployment pipeline.

-----------

## Shifting left on security


  **Security is everyone's responsibility.**

By better integrating information security (InfoSec) objectives into daily work, teams can achieve higher levels of software delivery performance and build more secure systems. This idea is also known as shifting left, because concerns, including security concerns, are addressed earlier in the software development lifecycle.

In software development, there are at least these four activities: design, develop, test, and release. In a traditional software development cycle, testing (including security testing), happens after development is complete. This typically means that a team discovers significant problems, including architectural flaws, that are expensive to fix.

Continuous delivery borrows from lean thinking the concept of building quality into the product throughout the process. As W. Edwards Deming says in his Fourteen Points for the Transformation of Management, "Cease dependence on inspection to achieve quality. Eliminate the need for inspection on a mass basis by building quality into the product in the first place." In this model, rather than taking a purely phased approach, developers work with security and testing experts to design and deliver work in small batches throughout the product lifecycle.

### How to implement improved security quality

Shifting the security review process "left" or earlier in the software development lifecycle requires several changes from traditional information security methods, but is not a significant deviation from traditional software development methods on closer inspection.

* **Get InfoSec involved in software design.** The InfoSec team should get involved in the design phase for all projects. When a project design begins, a security review can be added as a gating factor for releasing the design to the development stage. This review process might represent a fundamental change in the development process. This change might require developer training. 
* **Introduce security-approved tools.** Providing developers with pre-approved libraries and tools that include input from the InfoSec team can help standardize developer code. Using standard code makes it easier for the InfoSec team to review the code. Standard code allows automated testing to check that developer are using pre-approved libraries. This can also help scale the input and influence from InfoSec, because that team is typically understaffed compared to developers and testers.
* **Develop automated testing.** Building security tests into the automated testing process means that code can be continuously tested at scale without requiring a manual review. Automated testing can identify common security vulnerabilities, and it can be applied uniformly as a part of a continuous integration pipeline or build process. Automated testing does require you to design and develop automated security tests, both initially and as an ongoing effort as new security tests are identified. 

### Ways to improve security quality

You can improve software delivery performance and security quality by doing the following:

* **Conduct security reviews.** Conduct a security review for all major features while ensuring that the security review process doesn't slow down development.
* **Build pre-approved code.** Have the InfoSec team build pre-approved, easy-to-consume libraries, packages, toolchains, and processes for developers and IT operations to use in their work.
* **Integrate security review into every phase.** Integrate InfoSec into the daily work of the entire software delivery lifecycle. This includes having the InfoSec team provide input during the design of the application, attending software demos, and providing feedback during demos.
* **Test for security.** Test security requirements as a part of the automated testing process including areas where pre-approved code should be used.
* **Invite InfoSec to demos.** If you include the InfoSec team in your application demos, they can spot security-related weaknesses early, which gives the team ample time to fix.

### Ways to measure security quality

| Factor to test | What to measure | Goal |
| --- | --- | --- |
| Whether features undergo a security review | The percentage of features that undergo security review early in the design process. | This percentage should go up over time. |
| Whether security review slows down the development cycle | How much time the review add to the development process. | The time that security reviews take should go down until it reaches an agreed-to minimum. |
| How well security is integrated into the delivery lifecycle | The degree of InfoSec involvement in each step of the software delivery lifecycle. For example, you can measure the number of security reviews captured at each of the stages of the software development lifecycle (design, develop, test, and release). | This value should go up until it reaches a value that suggests that InfoSec is fully integrated into the lifecycle. |
| Whether automated testing covers security requirements | The involvement of the InfoSec team in writing automated tests. As InfoSec gains greater input into the testing process, the number or percentage of security requirements that are included in the automated testing process. | This percentage should go up over time. |
| The use of pre-approved libraries, packages, toolchains, and processes | Initially, whether InfoSec is engaged in tools development. As work progresses, the number of InfoSec-approved libraries, packages, and toolchains that are available, or the number of these resources that are used by the development and operations teams. | Engagement should increase over time until the organization agrees that InfoSec oversight of tools is at the correct level. Similarly, the percentage or number of pre-approved tools in use should increase until the team uses all the tools that InfoSec has created or approved. |

-----------

## Trunk-based development

There are two main patterns for developer teams to work together using version control. One is to use **feature branches**, where either a developer or a group of developers creates a branch usually from trunk (also known as main or mainline) and then work in isolation on that branch until the feature they are building is complete. When the team considers the feature ready to go, they merge the feature branch back to trunk.

The second pattern is known as **trunk-based development**, where each developer divides their own work into small batches and merges that work into trunk at least once (and potentially several times) a day. The key difference between these approaches is scope. Feature branches typically involve multiple developers and take days or even weeks of work. In contrast, branches in trunk-based development typically last no more than a few hours, with many developers merging their individual changes into trunk frequently.

The following diagram shows a typical trunk-based development timeline:

![Trunk based development diagram](../img/practices/devops-tech-trunk-based-development-typical-trunk-timeline.svg)

In trunk-based development, developers push code directly into trunk. Changes made in the release branches—snapshots of the code when it's ready to be released—are usually merged back to trunk (depicted by the downward arrows) as soon as possible. In this approach, there are cases where bug fixes must be cherry-picked and merged into releases (depicted by the upward arrow), but these cases are not as frequent as the development of new features in trunk. In cases where releases happen multiple times a day, release branches are not required at all, because changes can be pushed directly into trunk and deployed from there. One key benefit of the trunk-based approach is that it reduces the complexity of merging events and keeps code current by having fewer development lines and by doing small and frequent merges.

In contrast, the following diagram shows a typical non-trunk-based development style:

![Feature branches based development](../img/practices/devops-tech-trunk-based-development-typical-non-trunk-timeline.svg)

In this approach, developers make changes to long-lived branches. These changes require bigger and more complex merge events when compared to trunk-based development. This approach also requires additional stabilizing efforts and "code lock" or "code freeze" periods to make sure the software stays in a working state, because large merges frequently introduce bugs or regressions. As a result, you must test the post-merge code thoroughly and often have to make bug fixes.

### How to implement trunk-based development

Trunk-based development is a required practice for continuous integration. [Continuous integration (CI)](#continuous-integration) is the combination of practicing trunk-based development and maintaining a suite of fast automated tests that run after each commit to trunk to make sure the system is always working.

Analysis of DevOps Research and Assessment (DORA) data from [2016][3] and [2017][4] shows that teams achieve higher levels of software delivery and operational performance (delivery speed, stability, and availability) if they follow these practices:

* Have three or fewer active branches in the application's code repository.
* Merge branches to trunk at least once a day.
* Don't have code freezes and don't have integration phases.

### Moving towards trunk-based development

Some practices to implement to move towards trunk-based development:

* **Develop in small batches.** One of the most important enablers of trunk-based development is teams learning how to develop in small batches. This requires training and organizational support for the development team.
* **Perform synchronous code review.** As discussed previously, moving to synchronous code review, or at least ensuring that developers prioritize code review, helps to ensure that changes don't have to wait hours, or even days, to get merged into trunk.
* **Implement comprehensive automated testing.** Make sure that you have a comprehensive and meaningful suite of automated unit tests. and that these are run before every commit. For example, in GitHub, you can protect branches to only allow pull request merges when all tests have passed. Following [User guide][5] explains how to integrate AWS CodeBuild with GitHub Checks.
* **Have a fast build.** The build and test process should execute in a few minutes. If this seems hard to achieve, it probably indicates opportunities for improvement in the architecture of the system.
* **Create a core group of advocates and mentors.** Trunk-based development is a substantial change for many developers, and you should expect some resistance. Many developers simply can't imagine working in this way. A good practice is to find developers who have worked in this way, and have them coach other developers. It's also important to shift some teams over to work in a trunk-based style. One way to do this is to get a critical mass of developers who are experienced with trunk-based development together so that at least one team is following trunk-based development practices. You can then shift other teams over to this style when you feel confident that the team following this practice is performing as expected.

### Ways to measure trunk-based development

| Factor to test | What to measure |	Goal |
| --- | --- | --- |
| Active branches on the application's code repository. | Measure how many active branches you have on your application repositories' version control systems and make this number visible to all teams. Then track the incremental progress towards the goal state. | Three or fewer active branches. |
| Code freeze periods. | Measure how many code freezes your team has and how long they last. These measurements can also categorize how much time is spent on merging conflicts, on code freezes, on stabilization, and so on. | No code freezes when no one can submit code. |
| Frequency of merging branches and forks to trunk. | Measure either a binary (yes/no) value for each branch that's merged, or measure a percentage of branches and forks that are merged every day. | Merging at least once per day. |
| Check time taken to approve code changes. | If you perform code review asynchronously, measure the average time it takes to approve change requests, and pay particular attention to requests that take substantially longer than the average. | Find ways to make code review a synchronous activity that's performed as part of development. |

-----------

## Continuous testing

The key to building quality into software is getting fast feedback on the impact of changes throughout the software delivery lifecycle. Traditionally, teams relied on manual testing and code inspection to verify systems' correctness. These inspections and tests typically occurred in a separate phase after "dev complete." This approach has the following drawbacks:

* Manual regression testing is time-consuming to execute and expensive to perform, which makes it a bottleneck in the process. Software can't be released frequently and developers can't get quick feedback.
* Manual tests and inspections are not reliable, because people are poor at repetitive tasks like manual regression tests, and it is hard to predict the impact of changes on a complex software system through inspection.
* Once software is "dev complete", developers have to wait a long time to get feedback on their changes. This usually results in substantial work to triage defects and fix them. Performance, security, and reliability problems often require design changes that are even more expensive to address when discovered at this stage.
* Long feedback cycles also make it harder for developers to learn how to build quality code, and under schedule pressure development teams can sometimes treat quality as "somebody else's problem".
* When developers aren't responsible for testing their own code it's hard for them to learn how to write testable code.
* For systems that evolve over time, keeping test documentation up to date requires considerable effort.

Instead, teams should:

* Perform all types of testing continuously throughout the software delivery lifecycle.
* Create and curate fast, reliable suites of automated tests which are run as part of your [continuous delivery pipelines][6].

### How to implement continuous testing

To build quality into the software, you must continually run both automated and manual tests throughout the delivery process to validate the functionality and architecture of the system under development. This discipline has both an organizational and a technical component. Organizationally, DORA's research finds that teams do better when they:

* Allow testers to work alongside developers throughout the software development and delivery process. (Note that "tester" is a role, not necessarily a full-time job, although this is a common pattern discussed below.)
* Perform manual test activities such as exploratory testing, usability testing, and acceptance testing throughout the delivery process.

A key technical activity is building and maintaining a set of automated test suites, including:

* **Unit tests.** These typically test a single method, class, or function in isolation, providing assurance to developers that their code operates as designed. To ensure that the code is testable and tests are maintainable, write your unit tests before writing code, a technique known as test-driven development (TDD).
* **Acceptance tests.** These typically test a running app or service (usually with dependencies replaced by test doubles) to provide assurance that a higher level of functionality operates as designed and that regression errors have not been introduced. Example acceptance tests might check for the business acceptance criteria for a user story or the correctness of an API. Write these tests as part of the development process. No one should be able to declare their work "dev complete" unless automated acceptance tests are passing.

![Types of automated testing](../img/practices/types-of-automated-testing.png)

The automated tests highlighted in the preceding diagram fit in a continuous delivery deployment pipeline. In such pipelines, every change runs a build that creates software packages, executes unit tests, and possibly performs other checks, such as static analysis. After these packages pass the first stage, more comprehensive automated acceptance tests, and likely some nonfunctional tests such as performance tests and vulnerability scans, run against automatically deployed running software. Any build that passes the acceptance stage is then typically made available for manual exploration and usability testing. Finally, if no errors are found in these manual steps, the app is considered releasable.

`Running tests continuously as part of a pipeline contributes to quick feedback for developers, a short lead time from check-in to release, and a low error rate in production environments.`

![Deployment pipeline example](../img/practices/deployment-pipeline-example.png)

In the deployment pipeline pattern, every change creates a release candidate and the quick feedback loop helps to catch problems as early in the process as possible. When a package reaches the end of the pipeline and the team still doesn't feel comfortable releasing it, or if they discover defects in production, the pipeline must be improved, perhaps by **adding or updating tests**.

A specific design goal of an automated test suite is to find errors as early as possible. This is why faster-running unit tests run before slower-running acceptance tests, and both are run before any manual testing.

You should find errors with the fastest category of test. When you find an error in an acceptance test or during exploratory testing, add a unit test to make sure this error is caught faster, earlier, and cheaper next time.

![Ideal testing pyramid](../img/practices/ideal-testing-pyramid.png)

### Ways to improve continuous testing

If the project you are on doesn't have enough test automation, get started by building a skeleton deployment pipeline. For example, create a single unit test, a single acceptance test, and an automated deployment script that stands up an exploratory testing environment, and thread them together. Then incrementally increase test coverage and extend your deployment pipeline as your product or service evolves.

If you're already working on a brownfield system, write a small number of acceptance tests for the high-value functionality. Then, make sure you require developers to write unit and acceptance tests for any new functionality, and any functionality you are changing. Consider using TDD to improve the quality and maintainability of both main and test code, and finally, ensure that when your acceptance tests break, you write unit tests to discover the defect faster in the future.

If you have a test suite that is expensive to maintain and unreliable, don't be afraid to prune it down. A test suite of ten tests that is reliable, fast, and trustworthy is much better than a test suite of hundreds of tests that is hard to maintain and that nobody trusts.

Read how Testing Community of Practice at Google [helped with the adoption][7] of Unit testing. 

### Ways to measure continuous testing

| Factor to test | What to measure |Goal |
| --- | --- | --- |
| Writers of acceptance and unit tests. | Percentage of tests written by developers, testers, and any other group in your company. | Primary authors and maintainers of acceptance tests are developers or SDETs. |
| Number of bugs found in acceptance testing, exploratory testing, and in production. | Change in proportion of bugs found over time. | More bugs are found in "cheaper" test phases, teams add automated tests for the bugs you find during exploratory testing and production, and add unit tests to catch bugs discovered in acceptance tests. |
| Time spent fixing acceptance test failures. | Change in time spent fixing test failures over time. (It should reduce.) | Developers can easily fix acceptance test failures. |
| Automated tests are meaningful. | Track the quantity of automated test failures that represent a real defect and the quantity which were poorly coded. | Test failures always indicate a real defect in the product. |
| Automated tests run on delivery pipeline. | Check (yes/no) whether all test suites run in every pipeline trigger. | Automated tests are run as part of the main pipeline and workflow.|

-----------

## Continuous delivery

Continuous delivery is the ability to release changes of all kinds on demand quickly, safely, and sustainably. Teams that practice continuous delivery well are able to release software and make changes to production in a low-risk way at any time—including during normal business hours—without impacting users.

In DL principles and practices of continuous delivery can apply to any software context, including the following:

* Updating services in a complex distributed system.
* Upgrading mainframe software.
* Making infrastructure configuration changes.
* Making database schema changes.
* Updating firmware automatically.
* Releasing new versions of a mobile app.

Practicing continuous delivery means that:

* Software is deployable through its lifecycle.
* Priority is given to keep software in the deployable state instead of working on new Features.
* Everyone in the team can see feedback on quality and deployability of the systems you are working on.
* If feedback means that the software is not deployable, highest priority is given to fixing those issues.
* System can be deployed to the end user at any time and on demand.

`Continuous delivery is commonly mistaken with continuous deployment, but they are separate practices. Continuous deployment is when teams try to deploy every code change to production as soon as possible.`

Although continuous delivery is possible for all kinds of software, it is hard work, nevertheless it provides significant benefits. DevOps Research and Assessment (DORA) research shows that doing well at continuous delivery provides the following benefits:

* Improves software delivery performance, measured in terms of the four key metrics, as well as higher levels of availability.
* Leads to higher levels of quality, measured by the percentage of time teams spend on rework or unplanned work.
* Predicts lower levels of burnout (physical, mental, or emotional exhaustion caused by overwork or stress), higher levels of job satisfaction, and better organizational culture.
* Reduces deployment pain, a measure of the extent to which deployments are disruptive rather than easy and pain-free, as well as the fear and anxiety that engineers and technical staff feel when they push code into production.
* Impacts culture, leading to greater levels of psychological safety and a more mission-driven organizational culture.

![Technical practices for Continuous Delivery](../img/practices/continuous-delivery-technical-practices.png)

### Implementing continuous delivery

The following technical capabilities drive the ability to achieve continuous delivery. 

* [Test automation](#continuous-testing): The use of comprehensive automated test suites primarily created and maintained by developers. Effective test suites are reliable—that is, tests find real failures and only pass releasable code.
* [Deployment automation](#deployment-automation): The degree to which deployments are fully automated and do not require manual intervention.
* [Trunk-based development](#trunk-based-development): Characterized by fewer than three active branches in a code repository; branches and forks having very short lifetimes (e.g., less than a day) before being merged into mainline; and application teams rarely or never having code lock periods when no one can check in code or do pull requests due to merging conflicts, code freezes, or stabilization phases.
* [Shift left on security](#shifting-left-on-security): Integrating security into the design and testing phases of the software development process. This process includes conducting security reviews of applications, including the information security team in the design and demonstration process for applications, using pre-approved security libraries and packages, and testing security features as a part of the automated test suite.
* [A loosely coupled architecture](#architecture): Architecture that lets teams test and deploy their applications on demand, without requiring orchestration with other services. Having a loosely coupled architecture allows your teams to work independently without relying on other teams for support and services, which in turn enables them to work quickly and deliver value to the organization.
* [Empowering teams to choose tools](#empowering-teams-to-choose-tools): Teams that can choose which tools to use do better at continuous delivery. No one knows better than practitioners what they need to be effective.
* [Continuous integration (CI)](#continuous-integration): A development practice where code is regularly checked in, and each check-in triggers a set of quick tests to discover regressions, which developers fix immediately. The CI process creates canonical builds and packages that are ultimately deployed and released.
* [Continuous testing](#continuous-testing): Testing throughout the software delivery lifecycle rather than as a separate phase after dev complete. With continuous testing, developers and testers work side by side. High performers practice test-driven development, get feedback from tests in less than ten minutes, and continuously review and improve their test suites (for example, to better find defects and keep complexity under control).
* [Version control](#version-control): The use of a version control system, such as Git or Subversion, for all production artifacts, including application code, application configurations, system configurations, and scripts for automating build and configuration of environments.
* [Test data management](#test-data-management): Effective practices include having adequate data to run your test suite, the ability to acquire necessary data on demand, and the data not limiting the number of tests you can run. We caution that your teams should minimize, whenever possible, the amount of test data needed to run automated tests.
* [Comprehensive monitoring and observability](./measurement.md#monitoring-and-observability): Allows teams to understand the health of their systems. Effective solutions enable teams to monitor predefined metrics, including system state as experienced by users, as well as allowing engineers to interactively debug systems and explore properties and patterns as they emerge.
* [Proactive notifications](./measurement.md#proactive-failure-notification): Monitoring system health so that teams can preemptively detect and mitigate problems.
* [Database change management](#database-change-management): Database changes don't slow teams down if they follow a few key practices, including storing database changes as scripts in version control (and managing these changes the same way as production application changes), making database changes visible to everyone in the software delivery lifecycle (including engineers), and communicating with all parties when changes to the application require database changes.
* [Code maintainability](#code-maintainability): Systems and tools that make it easy for developers to change code maintained by others, to find examples in the codebase, to reuse other people's code, and to add, upgrade, and migrate to new versions of dependencies without breaking their code.

> Continuous Delivery can't be implemented by following the same processes just more frequently!

### Measuring continuous delivery

`Ultimately, the goal of continuous delivery is to ensure that releases are performed in a low-risk way during normal business hours.`

Following metrics could be used to assess how well is team doing at Continuous Delivery:

* Short lead times for both regular and emergency changes, with a goal of using your regular process for emergency changes.
* Low change fail rates.
* Short time to restore service in the event of outages or service degradations.
* Release frequencies that ensure that high-priority features and bug fixes are released in a timely manner.

-----------

## Architecture

Research from the DevOps Research and Assessment (DORA) team shows that architecture is an important predictor for achieving continuous delivery. 

Teams that adopt [continuous delivery](#continuous-delivery) practices, adopting the following architectural practices drives successful outcomes:

* Teams can make large-scale changes to the design of their systems without the permission of somebody outside the team or depending on other teams.
* Teams are able to complete work without needing fine-grained communication and coordination with people outside the team.
* Teams deploy and release their product or service on demand, independently of the services it depends on or other services that depends on it.
* Teams do most of their testing on demand, without requiring an integrated test environment.
* Teams can deploy during normal business hours with negligible downtime.

Architecture of the system designed to enable teams to test, deploy, and change systems without dependencies on other teams, enables teams to require little communication to get work done. In other words, both the architecture and the teams are loosely coupled.

> With a tightly coupled architecture, small changes can result in large-scale, cascading failures. As a result, anyone working in one part of the system must constantly coordinate with anyone else working in another part of the system, including navigating complex and bureaucratic change management processes.

### How to implement architectures for continuous delivery

`"There is no one perfect architecture for all products and all scales. Any architecture meets a particular set of goals or range of requirements and constraints, such as time to market, ease of developing functionality, scaling, etc. The functionality of any product or service will almost certainly evolve over time—it should not be surprising that our architectural needs will change as well. What works at scale 1x rarely works at scale 10x or 100x."`

Architecture Archetypes

| Archetype | Pros	| Cons |
| --- | --- | --- |
| **Monolithic v1**<br>(all functionality in one application)| * Simple at first<br>* Low interprocess latencies<br>* Single codebase, one deployment unit<br>* Resource-efficient at small scales | * Coordination overhead increases as team grows<br>* Poor enforcement of modularity<br>* Poor scaling<br>* All-or-nothing deploy (downtime failures)<br>* Long build times|
| **Monolithic v2**<br>(set of monolithic tiers: frontend presentation, application server, database layer)| * Simple at first<br>* Join queries are easy<br>* Single schema deployment<br>* Resource-efficient at small scales | * Tendency for increased coupling over time<br>* Poor scaling and redundancy (all or nothing, vertical only)<br>* Difficult to tune properly<br>* All-or-nothing schema management|
| **Microservice**<br>(modular, independent, graph relationship or tiers, isolated persistence) | * Each unit is simple<br>* Independent scaling and performance<br>* Independent testing and deployment<br>* Can optimally tune performance (caching, replication, etc.)| * Many cooperating units<br>* Many small repos<br>* Requires more sophisticated tooling and dependency management<br> * Network latencies|


Team independence is important, as is the independence of their products and services. Services need to be testable on demand. Adopting techniques around [mocking and stubbing][8] of external services helps reduce the impact of external dependencies and lets teams quickly create test environments. Also, implementing contract testing of external services helps ensure that dependencies on their service or other services are still met. To truly achieve continuous delivery, an individual team's product or service must be independently acceptance tested and deployed from the services it depends on.

To enable deploy-anytime capabilities, implement blue/green or rolling deployment models, with high degrees of automation. With these models, at least two or more versions of the product or service are running simultaneously. These deployment models allow teams to validate changes and deploy to production with little or no downtime. An important consideration is how data upgrades are performed, meaning data and schema must be done in a backward-compatible manner.

In order to aid the independent deployment of components, create backward-compatible versioned APIs. Ensuring backward compatibility for APIs adds complexity to systems, but the flexibility you gain in terms of ease of deployment pays for the added complexity many times over.

Service-oriented and microservice architectures enable these capabilities because they use [bounded contexts][9] and APIs as a way to decouple large domains into smaller, more loosely coupled units and the use of test doubles and virtualization as a way to test services or components in isolation.

### Ways to improve your architecture

A key feature of service-oriented and microservice architectures is that they're composed of loosely coupled services with bounded contexts. One popular set of patterns for modern web architecture based on these principles is the [twelve-factor app][10].

One valuable pattern in this context is the strangler fig application. In this pattern, you iteratively replace a monolithic architecture with a more componentized one by ensuring that new work is done following the principles of a service-oriented architecture. You accept that the new architecture might well delegate to the system it is replacing. Over time, as more and more functionality is performed in the new architecture, the old system is "strangled."

![Strangled pattern in practice](../img/practices/devops-tech-strangler-fig-pattern.svg)

Product and service architectures continually evolve. There are many ways to decide what should be a new module or service, and the process is iterative. When deciding whether to make a piece of functionality into a service, consider if it has the following traits:

* Implements a single business function or capability.
* Performs its function with minimal interaction with other services.
* Is built, scaled, and deployed independently of other services.
* Interacts with other services by using lightweight communication methods, for example, a message bus or HTTP endpoints.
* Can be implemented with different tools, programming languages, data stores, and so on.

### Ways to measure architectural improvement

As your services and products become less tightly coupled, your **deployment frequency should increase**. When measuring improvement, consider using deployment rate rather than just count, because deployment count naturally increases as services are added. You should see a **reduction in time to detect and recover from problems** and in the time for changes to reach production.

Aside from taking these deployment and service measures, teams that operate more independently demonstrate improvements in [job satisfaction](culture.md#job-satisfaction) and [team experimentation](process.md#team-experimentation), and tend to select different technologies and tools based on their needs.

-----------

## Test data management

[Automated testing](#continuous-testing) is a key component of modern software delivery practices. The ability to execute a comprehensive set of unit, integration, and system tests is essential to verify that your app or service behaves as expected, and can be safely deployed to production. To ensure that your tests are validating realistic scenarios, it's critical to supply the tests with realistic data.

Test data is important because it's required by all kinds of tests throughout your test suite, including manual and automated tests. Good test data lets you validate common or high value user journeys, test for edge cases, reproduce defects, and simulate errors.

However, it's hard to use and manage test data effectively. **Over-reliance on data defined outside of test scope can make your tests brittle and increase maintenance costs.** Dependencies on external data sources can introduce delays and impact test performance. Copying production data introduces risk because it might contain sensitive information. To address these challenges, you need to manage your test data carefully and strategically.

### How to implement test data management

Analysis done by DevOps Research and Assessment (DORA) shows that successful teams approach test data management with the following core principles:

* Adequate test data is available to run full automated test suites.
* Test data for automated test suites can be acquired on demand.
* Test data does not limit or constrain the automated tests that teams can run.

To improve test data management processes, strive to meet each of these conditions.

### Common pitfalls in test data management

Managing test data can be hard. The following pitfalls are common in test data management:

* Over-reliance on data in testing. In particular, unit tests should not depend on data or state external to the test.
* Using a full copy of the production database, rather than identifying relevant or important portions.
* Not masking or hashing sensitive data.
* Relying on data that is out of date or no longer relevant.

### Ways to improve test data management

1. **Favor unit tests.** Unit tests should be independent of each other and any other part of the system except the code being tested. Unit tests should not depend on external data. As defined by the test automation pyramid, unit tests should make up the majority of your tests. Well-written unit tests that run against a well-designed codebase are much easier to triage and cheaper to maintain than higher-level tests. Increasing the coverage of your unit tests can help minimize your reliance on higher-level tests that consume external data.

![Testing pyramid](../img/practices/ideal-testing-pyramid.png)

2. **Minimize reliance on test data.** Test data requires careful and ongoing maintenance. As your APIs and interfaces evolve, you must update or re-create related test data. This process represents a cost that can negatively impact team velocity. Hence, it's good practice to minimize the amount of test data needed to run automated tests.
3. **Isolate your test data.** Run your tests in well-defined environments with controlled inputs and expected outputs that can be compared to actual outputs. Make sure that data consumed by a particular test is explicitly associated with that test, and isn't modified by other tests or processes. Wherever possible, your tests should create the necessary state themselves as part of setup, using the application's APIs. Isolating your test data is also a prerequisite for tests to run in parallel.
4. **Minimize reliance on test data stored in databases.** Maintaining test data stored in databases can be particularly challenging for the following reasons:
    1. **Poor test isolation.** Databases store data durably; any changes to the data will persist across tests unless explicitly reset. Less reliable test inputs make test isolation more difficult, and can prevent parallelization.
    2. **Performance impact.** Speed of execution is a key requirement for automated tests. Interacting with a database is typically slower and more cumbersome than interacting with locally stored data. Favor in-memory databases where appropriate.
5. **Make test data readily available.** Running tests against a copy of a full production database introduces risk. It can be challenging and slow to get the data refreshed. As a result, the data can become out of date. Production data can also contain sensitive information. Instead, identify relevant sections of data that the tests require. Export these sections regularly and make them easily available to tests.

### How to measure test data management

Measure your progress against the core principles outlined earlier.

1. **Adequate test data is available to run full automated test suites.** You can measure this by tracking how much time developers and testers spend managing and manipulating data for use in test suites. You can also capture this by perceptual measures (that is, surveys) to ask teams if they have adequate data for their work, or if they feel this is a constraint for them.
2. **Test data for automated test suites can be acquired on demand.** You can measure this as the percentage of key data sets that are available, how often those data sets are accessed, and how often they are refreshed.
3. **Test data doesn't limit or constrain the automated tests that teams can run.** You can measure this as the number of automated tests that can be run without the need to acquire additional test data. You can also capture this with perceptual measures (that is, surveys), to ask teams if they feel that test data limits their automated testing activities.

-----------

## Database change management

Database changes are often a major source of risk and delay when performing deployments. DevOps Research and Assessment (DORA) investigated which database-related practices help during the process of implementing continuous delivery, improving both software delivery performance and availability.

DORA discovered that good communication and comprehensive configuration management that includes the database matter. Teams that do well at continuous delivery store their database changes as scripts in version control and manage these changes in the same way they manage production application changes. Furthermore, when changes to the application require database changes, these teams discuss them with the people responsible for the production database, and ensure the engineering team has visibility into the progress of pending database changes.

When teams follow these practices, database changes don't slow them down or cause problems when they perform code deployments.

### How to implement database change management

#### Establish effective communication of database changes

Research shows that teams do best when they discuss changes with the people responsible for managing the production database, and when everyone has visibility into the progress of pending database changes.

Discussing proposed changes with production database administrators (DBAs) is important for a few reasons. First, these experts can advise on how best to achieve results, and point out potential issues such as performance problems. (Many operations have very different performance characteristics in production systems when compared to developer workstations). This discussion also gives DBAs insight into what is happening upstream, which helps them better prepare for the impact of upcoming changes.

Making sure everybody has visibility into the progress of changes is also crucial so that teams, including DBAs, can understand which changes are coming up, their testing status, and which schema changes have made it to the various production and non-production shared databases. You can facilitate visibility by:

* Keeping all database schema changes in version control, together with the application code the schema belongs to;
* Using a tool that records which changes have been run against which environments, and what the results were.

These practices also ensure that there is a canonical source of truth for all changes, and makes the history of changes easy to access for auditing purposes.

#### Treat all database schema changes as migrations

A widely used pattern for versioning database changes is to capture every change as a migration script which is kept in version control, as shown in the following diagram. Each migration script has a unique sequence number, so that you know in which order to apply migrations.

![Database change management](../img/practices/database-change-management-1.png)

You then ensure that every database instance has a table that records which migrations have been run against that particular instance. In this way you version-control the database schema, so you can use a tool to apply the migration scripts to take the database to the schema version you want. Examples of tools:

* [dbup](https://github.com/dbup/dbup) (.NET)
* [Flyway](https://flywaydb.org/) (platform independent)
* [Liquibase](https://www.liquibase.org/) (platform independent)
* [Alembic](https://pypi.org/project/alembic/) (Python)

You can also use migrations to create empty database schemas for development and testing.

### Zero-downtime database changes

In DL we schedule downtime for services when making database schema changes due to the need to coordinate with application deployments, or due to database table locking during the execution of such changes. Continuous delivery aims to eliminate downtime for deployments, so here are some strategies to make database schema changes without downtime:

* **Use an online schema migration framework** such as [gh-ost](https://github.com/github/gh-ost) or [pt-online-schema-change](https://www.percona.com/doc/percona-toolkit/3.0/pt-online-schema-change.html). These tools create a "ghost" copy of each table you want to change, migrate the empty copy, and then incrementally copy data from the original table including any updates that happen during the migration. After this process is complete, they replace the original table with the ghost. Some databases, for example Cloud Spanner, can perform schema updates with zero downtime.
* **Decouple database changes and application changes** with the [parallel change pattern][12]. In this pattern, you never mutate existing database objects. Instead, you add new structures alongside old ones. For example, consider changing a column for "address" to two columns: *address_1* and *address_2*.<br><br>
Instead of deleting the old column and adding the new one, and rolling out a new version of the application at the same time, you add the new columns but keep the old ones. You can do this before the application deployment occurs. Then the new version of the application can look for the new columns, reading from them if they are present and not null, otherwise reading from the old column. The application can then write to both old and new columns, lazily migrating the data, and also allowing for application rollback without requiring a database rollback.<br><br>
In this way the application deployment is decoupled from the database change, which can typically be made without incurring downtime since it doesn't involve migrating data. We have traded off some additional complexity in the application in order to reduce deployment pain. Alternatively, database triggers can be used to keep data in new and old columns synchronized.
* **Design and implement a data partitioning and archiving strategy.** A major cause of long migrations is database tables with a large number of rows. Make sure your applications are designed to allow for partitioning and archiving of data to avoid tables growing too large. One example of this would be to create multiple instances of a table for each quarter, for example, instead of a survey_answers table, you might have *survey_answers_2020Q1*, *survey_answers_2020Q2* and so forth. Make sure application design and architecture reviews include validating the application's data partitioning / archiving strategy.
* **Use an event sourcing architecture.** In an [event sourcing architecture][13], rather than having the database storing the current state of the application, we have it store changes to its state instead, in the form of a log of events known as commands. So when your customer changes their address, rather than updating a table with the customer details, the application issues an address change command which is stored in the database. This is how database transaction logs and version control work, and is a common pattern in distributed systems. In an event sourced architecture, events can be queued allowing database migrations to happen while events queue up. Events in the queue can then be flushed to the database once the migration is complete. Some databases are able to queue queries while schema migrations run, which can be effective if migrations complete quickly enough.
* **Use a NoSQL solution.** Some NoSQL databases, such as [Amazon DynamoDB](https://aws.amazon.com/dynamodb), don't suffer from the issue of downtime created by schema changes. Document databases like DynamoDB have an implicit schema, which means that the schema is managed at the application layer rather than the database layer. However there are trade-offs associated with using NoSQL databases: they are not optimal for every application.

As well as eliminating scheduled downtime, you also want to avoid unscheduled downtime. Make sure you test every schema change against a [production-like data set](#test-data-management) (with any personal or confidential information scrubbed, of course) to make sure your application behaves the way you expect during and after migration. You could create a scrubbed version of the production database on a daily schedule to use for this purpose. If you are using a database management system with more than one node in production, make sure you're testing against an instance with at least two nodes to help catch distributed system issues.

### How to measure database change management

The goal of an effective database change management system is that database changes don't slow down deployments or cause problems. It's worth measuring the percentage of failed changes in which database changes were a contributing factor, and the extent to which work related to database changes contributes towards overall lead time from version control to release.

If database changes require scheduled downtime, this is also an important consideration. To measure the economic impact of scheduled downtime, consider both the potential lost revenue resulting from downtime and the salary costs of paying people to work out of regular hours in order to perform deployments. Deploying outside business hours can also contribute to team burnout. These impacts can be used to justify the work required to implement the solutions for zero-downtime deployments discussed in this document.

In terms of measuring the level of automation, consider the proportion of database changes that are made in a push-button way using a fully automated process. The goal should be that 100% of database changes are made in this way.

-----------

## Cloud infrastructure

Characteristics of Cloud Computing:

* **On demand self-service:** Consumers can provision computing resources as needed, without human interaction from the provider.
* **Broad network access:** Capabilities can be accessed through diverse platforms such as mobile phones, tablets, laptops, and workstations.
* **Resource pooling:** Provider resources are pooled in a multi-tenant model, with physical and virtual resources dynamically assigned on-demand. The customer may specify location at a higher level of abstraction such as country, state, or data center.
* **Rapid elasticity:** Capabilities can be elastically provisioned and released to rapidly scale outward or inward on demand, appearing to be unlimited and able to be appropriated in any quantity at any time.
* **Measured service:** Cloud systems automatically control, optimize, and report resource use based on the type of service such as storage, processing, bandwidth, and active user accounts.

> To reap the benefits of the Cloud Characteristics, traditional Datacenter approaches and practices to manage the infrastructure can NOT be applied to Cloud.

### How to implement cloud infrastructure

Adopting cloud-native processes and practices to implement above five characteristics involves substantial change by several IT functions, including developers, operations teams, information security, procurement, and finance. The changes require close collaboration between these functions in order to identify and resolve conflicting aims.

For example, many developers expect complete control over production infrastructure when using cloud platforms. Information security professionals oppose this practice, and with good reason — without [disciplined change management](process.md#streamlining-change-approval), cloud infrastructure can turn into a fragile work of art that is hard to manage, vulnerable to external threats, and does not meet regulatory requirements.

Infrastructure-as-code allows you to manage changes effectively, and to apply information security controls. For example, you can implement segregation of duties by requiring all changes to the configuration specified in version control to be approved by someone from a specified group of people. However, moving to Infrastructure-as-code requires significant engineering effort and process change, including changing policies for implementing information security controls.

### Common pitfalls of implementing cloud infrastructure

The biggest obstacles to meeting the five characteristics are:

* Insufficient alignment and collaboration between the organizational functions that must work together in order to implement them;
* Insufficient investment in technical, process, and organizational change.

### How to measure cloud infrastructure

In order to decide what to measure, start by considering what benefits you hope to gain from implementing cloud infrastructure. Then start measuring the extent to which those benefits are being realized.

For example, if your goal is to improve cost visibility, you might track how well you're doing at making sure the cost of infrastructure is correctly billed to the relevant business line, team, product, or environment.

You can also directly measure whether or not you have done a good job of implementing Cloud essential characteristics: ask your teams about the extent to which they agree with the statements of these characteristics listed at the top of this section. Teams that agree or strongly agree are doing well; teams that are neutral or disagree need help and support to remove obstacles to meeting these outcomes. Then consider how many teams that say they are using cloud can actually meet the criteria.

Some aspects of the essential characteristics can also be measured directly by instrumenting your processes. For example, if you have a process for managing infrastructure changes you could measure the time it takes end-to-end to make a change. You can also look at how prevalent cloud-native technologies are in your organization: for example, the proportion of clusters or machines managed using Kubernetes or autoscaling groups rather than manual provisioning, or the time-to-live for hosts. In data centers, long uptimes generally indicate high reliability; in the cloud-native paradigm, configuration changes are often made by starting new virtual hosts with the new configuration rather than making changes to existing hosts. This practice is known as ephemeral infrastructure, in which a long uptime is an indicator of an unpatched machine.

-----------

## Code maintainability

The [DevOps Research and Assessment (DORA)][14] research shows that the ability of teams to maintain their code effectively is one of a number of technical practices that contribute positively to success with continuous delivery.

If your team is doing a good job with code maintainability, the following are true:

* It's easy for the team to find examples in the codebase, reuse other people's code, and change code maintained by other teams if necessary.
* It's easy for the team to add new dependencies to their project, and to migrate to a new version of a dependency.
* The team's dependencies are stable and rarely break the code.

Code maintainability is a capability that requires organization-wide coordination, since it relies on being able to search, reuse, and change other teams' code. Managing dependencies effectively is often a major source of pain when working with large code bases and large organizations. Tooling that can help avoid problems with dependencies or illuminate the consequences of code changes can improve design decisions and code quality for all engineers, which in turn enables them to work faster and create more stable, reliable software.

### How to implement code maintainability

In terms of implementation, it's worth dealing with source code management and dependency management separately, although it's possible for a solution to address both concerns.

First, source code management. Enabling everybody to easily find, reuse, and propose changes to any part of the codebase provides:

* **Faster delivery:** In order to deliver software quickly, teams need to be able to see and propose changes to each other's code. Making this as easy as possible helps transfer knowledge across the organization, and helps unblock teams who need to make changes to other parts of the codebase in order to get their work done.
* **Higher levels of stability and availability:** In the event of an incident, it's essential to be able to rapidly find and propose changes to any part of the codebase.
* **Higher code quality:** Refactoring code to improve its internal quality often involves making changes to multiple parts of the codebase. If this is hard, it reduces the likelihood that people will perform refactorings, and increases the cost of doing so. Some organizations, including Google, run cross-team code maintenance projects where individuals go through the codebase fixing maintenance-level items, which relies on the ability to easily access and change code across the organization.

Being able to find examples and reuse other people's code depends on being able to easily access and search the entire organization's source code. The simplest way to implement this requirement is to use a single version control platform for the whole organization's code — even if that code is split between multiple repositories within the platform. The more separate version control platforms are in use, the harder it is to find code. In DL we use GitHub Enterprise that is by default open for everyone to view. Some code requires to be locked from viewing/changing to a specific group. However, this should be an exception not a norm.

It should also be possible to change code maintained by other teams. Typically such changes will require approval from the team that is responsible for maintaining the code in question. Mechanisms such as pull requests, where a branch is created in version control and approval results in merging of the branch, can minimize the friction of allowing other teams to propose changes, while also preventing [unauthorized changes](process.md#streamlining-change-approval), and enforcing information security controls such as segregation of duties.

Making it easy for teams to add and update dependencies, and ensuring they are stable and rarely break code, means:

* **Better security:** As dependencies age, it is more likely that vulnerabilities will be discovered in them. It is essential that dependencies are kept up-to-date, particularly after vulnerabilities are found and patched.
* **Faster delivery:** Using libraries developed by other teams or organizations means you don't have to write your own code to do that job. When you have mechanisms in place to ensure dependencies are stable and rarely break code, you can spend more time on coding and less time on maintenance.

It is essential to adopt and evolve processes and tooling that make it easy for teams to consume known-good versions of dependencies and upgrade them rapidly, including automated [continuous integration (CI)](#continuous-integration) and [testing](#continuous-testing) to discover if new versions of dependencies contain breaking changes, and to quickly and simply correlate the versions of dependencies in use with the systems that use them.

There are two commonly used models for including dependencies in your software: vendor and declarative manifests. In vendoring, either the source code or the binary of every dependency is checked into version control along with the application. Alternatively, most modern platforms have a dependency management tool that manages dependencies specified in declarative manifest files checked into version control (for example, Python's pip, Node.js's npm, R's CRAN, and Java Maven).

Whether you vend or use manifests, the most important considerations are:

* **Traceability:** Make sure you can trace back from any given package or deployment to the exact version of every dependency used to build it. Without this, it is impossible to debug problems caused by changes to dependencies.
* **Reproducibility:** Your build process should be as deterministic as possible. Trying to debug problems caused by a build process that behaves differently on different machines is extremely painful.

### How to measure code maintainability

Here are some simple ideas to get you started with measuring code maintainability:

* What percentage of your organization's codebase is searchable?
* What is the median lead time to make a change to part of the codebase to which I don't have write access?
* What percentage of our codebase is duplicate code? What percentage is unused?
* What percentage of applications aren't using the most recent stable version of all the libraries they consume?
* How many versions of each library do we have in production? What's the median? What is a good goal? How many versions are more than 1 year old?
* How often do teams upgrade their libraries? How long does it take to do this?

When considering what to measure, there are three use cases to focus on:

* Managing technical and design debt
* Change management (including emergency changes)
* Patching vulnerabilities.

As code bases grow, technical debt is a major concern. It's important to be able to refactor and re-architect code as organizations and the products they and their customers rely on evolve. For large code bases, this can be complex and painful without significant tool support. It is also important to be able to identify code that is unused, duplicated, has poor test coverage, or contains vulnerabilities. The first step is to ensure that your tooling enables you to establish and track metrics that identify areas for improvement and make it straightforward to take action safely.

The second step is [change management](process.md#streamlining-change-approval). When someone makes a change to part of the codebase, to what extent does your tooling help you detect the impact of that change? If another team is impacted, how fast can they take action to remedy the problem, particularly if the fix lies in a different area of the codebase? When an emergency change must be made, how long does it take to get the necessary code changes into the codebase, tested, and released?

Establish and track metrics, so you can track how long changes take to propagate through your processes. Then identify bottlenecks and work to improve your processes, adding tool support where appropriate. Watch out for "emergency" processes that bypass validations and approvals in order to gain speed — the goal should be to have your regular process be both reliable and fast enough to be effective in an emergency.

Patching vulnerabilities is a particularly important change management scenario. When a vulnerability is discovered in a library, how long does it take to discover and patch software that uses the vulnerable versions of the library? If you're not sure, this is worth testing on a regular basis. Given the enormous potential costs of handling breaches and data and code exfiltration, and the frequency of such attacks, it is typically worth devoting significant resources to making sure third-party software you rely on is up-to-date and can be easily upgraded in the event of vulnerabilities being discovered.

-----------

## Empowering teams to choose tools

Teams are empowered to make informed choices about the tools and technologies used to do their work. [Research (PDF) from the DevOps Research and Assessment (DORA)][11] team shows this contributes to better continuous delivery and higher software delivery performance.

> Allowing teams to choose tools doesn't mean each team is given free rein to select any tool they want.

Introducing technologies without any constraints can increase technical debt and fragility. However, when you combine tool choice with other capabilities—for example, a full view of the system, fast feedback, and the understanding that the team is responsible for the code that they write—it helps technologists make wise decisions about tools they will use and need to support.

### How to empower teams to choose tools

It's important to balance the freedom to choose tools with the cost to acquire and support them, and the added potential complexity of communicating between teams that use different tools. The following are some ways to empower teams to choose their own tools.

* **Establish a cross-team baseline.** With representatives from different teams and cross-functional areas (product managers, developers, testers, operators), establish a baseline of approved tooling. We recommend that the baseline set of tools be large and diverse enough to address the majority of the needs of your organization. Examples of tools to include in the baseline are programming languages and libraries, testing and deployment tools, monitoring infrastructure, and data backends.
* **Periodically review the tools**. Periodically or as a part of sprint retrospectives, critically evaluate the baseline toolset to examine their effectiveness. These reviews also provide opportunities to discuss and demonstrate new technologies.
* **Define a process for exceptions.** Create a clearly defined process for deviating from the base toolset. When a new technology is used that's outside the baseline for a project, document what the new tool is and why it was used. This documentation is critical when troubleshooting and maintaining the project. Additionally, the documentation included in the projects can be used later to justify adding the tool to the baseline.

> Forcing tools and technologies on practitioners can improve standardization. However, what works in some cases is not necessarily the best solution in every case. This approach also limits opportunities for experimentation and growth, where emerging technologies can be tried and tested.

### Ways to improve tool choice in teams

* **Periodically assess the tech stack.** During assessments, encourage team members to critically evaluate how well the current tools address requirements. Additionally, during these reviews, discuss issues with the existing tools and potential new tool experimentation can be discussed and planned.
* **Proactively investigate new tools for new projects.** Have members of the teams think about and experiment with new tools to determine whether those tools are worth supporting. Try implementing a key piece of the new system using both existing and proposed technologies to see whether the expected benefits materialize. When you select technologies, have a good understanding of the costs associated with the technology. These might include licensing, support, and the infrastructure required to run the tools. You might also need to hire more people to help with adopting and maintaining the technology.
* **Schedule time to experiment with new tools.** Periodically, hold sessions (such as hackathons) where teams can play around with new projects and new technologies. Not all tools will be kept as a result of these experiments. But the important point is that you're easing these new technologies into your stack or decide they aren't appropriate.
* **Hold regular presentations to discuss new tools.** Sponsor organized meetings (such as lunch meetings) where new tech is presented and discussed. They can be informal meetings where one person does a presentation about a project they are working on in a new tech, or something they are investigating. Informal meetings like these are a good way for the group to talk about new technologies and stay up to date. A good approach is to rotate the presentations, with team members taking turns presenting Or you can invite people from other teams or someone from outside the company to present. Including people from outside the organization can be particularly helpful, because if they have experience with a tool, they can discuss hidden costs and complexities that will only be apparent after longer-term use.

### Ways to measure if teams are empowered to choose tools

The best way to determine whether teams feel that they're empowered to choose tools is to ask. You don't want to measure this by counting how many tools the team uses or how often teams change tools, because the team might be sticking with the same tool, or might be changing tools, because they are being told they have to.

-----------

[1]: https://martinfowler.com/articles/originalContinuousIntegration.html
[2]: https://services.google.com/fh/files/misc/state-of-devops-2015.pdf#page=20
[3]: https://services.google.com/fh/files/misc/state-of-devops-2016.pdf#page=31
[4]: https://services.google.com/fh/files/misc/state-of-devops-2017.pdf#page=40
[5]: https://docs.aws.amazon.com/codebuild/latest/userguide/sample-github-pull-request.html
[6]: https://continuousdelivery.com/implementing/patterns/#the-deployment-pipeline
[7]: https://martinfowler.com/articles/testing-culture.html#google
[8]: https://martinfowler.com/bliki/TestDouble.html
[9]: https://martinfowler.com/bliki/BoundedContext.html
[10]: https://12factor.net/
[11]: http://services.google.com/fh/files/misc/state-of-devops-2017.pdf
[12]: https://medium.com/continuousdelivery/expand-contract-pattern-and-continuous-delivery-of-databases-4cfa00c23d2e
[13]: https://microservices.io/patterns/data/event-sourcing.html
[14]: https://cloud.google.com/devops