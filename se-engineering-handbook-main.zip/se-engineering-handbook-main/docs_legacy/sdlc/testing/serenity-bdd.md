# Serenity BDD standards, best practices and guidelines

Serenity BDD helps you write cleaner and more maintainable automated acceptance and regression tests faster. For
detailed information and usage see [Serenity BDD User Guide](https://serenity-bdd.github.io/docs/guide/user_guide_intro)
.

## Screenplay

When using Serenity BDD we should use the Screenplay design pattern whenever possible.
See [Serenity Screenplay](https://serenity-bdd.github.io/docs/screenplay/screenplay_fundamentals).

### Locatorless Web Elements

Serenity takes advantage of Selenium 4 relative locators. These should be used where possible to locate elements on a
web page as they do away with needing complex CSS or XPath selectors. See
[Serenity Page Elements](https://serenity-bdd.github.io/docs/guide/page_elements#introduction) for usage.

We would recommend that the locators should still be referenced via 'Targets' to give utmost flexibility, if a change in
locator strategy is needed, i.e.

```
    public static final Target NEXT = Button.withText("Next");
```

### Conditional tasks

_todo: serenity ref required_

**Check.whether** vs **if statements**

Guidelines for using Conditional tasks:

- Clarity (readability) of the code is the utmost thing: ‘First and foremost we are writing Java code, and its about
  writing code that other people can read easily.’
- Multiple indentations in a block should make the author stop and think - as a general rule if you can use ‘check
  whether’ and keep it to one line of code then it's good, otherwise opt for simple ‘if’ statements.
- Prefer the Serenity syntax when you are implementing something close to a user action, otherwise opt for core Java.
- If you have nested conditions then code that in core Java, but for the ‘action’ clause use Serenity syntax. e.g.  :

```
    if (fieldType == TYPE_KEY) {
     actor.attemptsTo(TypeKeyQuestion.validate()) 
    }
```

## Code Style

Code **must** adhere to the [Google Java Style Guide](https://google.github.io/styleguide/javaguide.html). If you're
using IntelliJ or Eclipse the following options are available to help conform to the style:

- [Plugins](https://github.com/google/google-java-format)
- [Configuration Files](https://github.com/google/styleguide)

### Naming Conventions

Working with REST APIs, using the JUnit test functions in Serenity we should name the entry test function with
underscores as Serenity will then represent this in the report as an English sentence. Remaining functions use java
conventions as per normal.

```
    @Test
    public void retrieve_an_element_from_the_json_structure(){
    }

```

Will be shown as _**retrieve an element from the json structure**_ in the report

## Code Craft

See [Code Craft](./code-craft.md) for software principles and areas of focus when producing or reviewing code.

## BDD

To make the BDD in our serenity projects conform to best practices see [BDD best practices](bdd.md).

## Archetype Projects

The following repositories show how to write code using Serenity BDD with the Screenplay design pattern aligning with
best practices. These repos also have guards in place before code is delivered such as number of reviewers, sonar checks
etc.

| Repo | Focus | 
| ----------- |  ----------- | 
| [b4c-test-pc](https://github.com/Direct-Line-Group/b4c-test-pc) | UI |
| [b4c-test-mule](https://github.com/Direct-Line-Group/b4c-test-mule) |API |
| [b4c-test-bc](https://github.com/Direct-Line-Group/b4c-test-bc) |UI |
| [b4c-test-sf](https://github.com/Direct-Line-Group/b4c-test-sf) |UI |
| [b4c-test-time-travel](https://github.com/Direct-Line-Group/b4c-test-time-travel) |UI |
| [digiacc-myaccount-automation-testing](https://github.com/Direct-Line-Group/digiacc-myaccount-automation-testing) |UI/API |
| [claims-digital-claim-service-api-test](https://github.com/Direct-Line-Group/claims-digital-claim-service-api-test) |API |
| [claims-digital-hub-ui-test](https://github.com/Direct-Line-Group/claims-digital-hub-ui-test) |UI |
| [pet-portal-test-automation](https://github.com/Direct-Line-Group/pet-portal-test-automation) |UI |
| [pet-digital-test-automation](https://github.com/Direct-Line-Group/pet-digital-test-automation) |UI |







