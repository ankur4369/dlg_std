# End-To-End Testing

TBD

## Serenity BDD
Serenity BDD provides strong support for different types of automated acceptance testing, including:
- Rich built-in support for web testing with Selenium.
- Highly readable, maintainable and scalable automated testing with the Screenplay pattern.
- REST API testing with RestAssured.

Please see: [Standards, best practices and guidelines for using Serenity BDD.](serenity-bdd.md)





