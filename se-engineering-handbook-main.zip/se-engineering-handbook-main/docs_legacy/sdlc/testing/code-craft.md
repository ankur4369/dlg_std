# Code Craft

Software standards give our projects consistency and uniformity, but to make 'good' code, is to hone the craft of
software, the following links is learning to various software principles and areas of focus when architecting, producing
or reviewing code.

| Principle |  
| ----------- | 
| [SOLID](https://www.baeldung.com/solid-principles)
| [DRY](https://java-design-patterns.com/principles/#keep-things-dry)
| [KISS](https://java-design-patterns.com/principles/#kiss)
| [OOP practices](https://stackify.com/oops-concepts-in-java/)
| [Functional programming practices](https://www.baeldung.com/java-functional-programming)
| [Declarative BDD](https://cucumber.io/docs/bdd/better-gherkin/)
| [Package structure](https://www.techyourchance.com/popular-package-structures/)
| [Java best practices](https://www.oracle.com/java/technologies/effectivejava.html)
| [Test at the right level](https://www.softwaretestinghelp.com/the-difference-between-unit-integration-and-functional-testing/)
| [Performant code](https://www.infoworld.com/article/3215112/java-101-datastructures-and-algorithms-in-java-part-1.html?page=2)
| [Clean code](https://www.baeldung.com/java-clean-code)
| [General review practices](https://google.github.io/eng-practices/review/)
| [Avoiding flaky tests](https://applitools.com/blog/uncover-flaky-tests/)







