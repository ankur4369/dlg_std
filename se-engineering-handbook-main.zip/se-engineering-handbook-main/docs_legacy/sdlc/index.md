# Software Development LifeCycle (SDLC)

* What is SDLC?
* How do we do it in DL?
* Main SLDC Principles

## Testing
tbd

[End-To-End Testing](./testing/end-to-end.md)