# Software Engineering Roles at Direct Line

about the role....
#### Requirements
#### Nice-to-haves
#### Responsibilities

***

#### Professional Experience

#### Primary programming language

#### Software Engineer Performance Indicators

Software Engineer performance indicators.

* and link
* and link

Engineering Manager performance indicators. Performance indicators for a Manager role also apply to the team, meaning the manager and their direct reports.

* and link
* and link

***

## Levels

### Apprentice Software Engineer

#### Job Grade

The Apprentice Software Engineer role is a Band 2 role.

### Software Engineer

#### Job Grade

The Software Engineer role is a Band 3 role.

### Senior Software Engineer

#### Job Grade

The Senior Software Engineer role is a Band 4 role.

### Principal Software Engineer

#### Job Grade

The Principal Software Engineer role is a Band 5 role.



## Engineering Manager Roles

## Levels

### Engineering Manager Roles

#### Job Grade

The Engineering Manager role is a Band 4 role.

#### Responsibilities


### Senior Engineering Manager

#### Job Grade

The Senior Engineering Managers role is a Band 5 role.




## Career Ladder



## Hiring Process


