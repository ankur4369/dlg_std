# Behaviours for Engineering

How we show up as [Engineers](#as-an-engineer-i-will) or [Engineering Managers/Chapter Leads](#as-an-engineering-managerchapter-lead-i-will)

## As an Engineer I will

1. **Be curious**
	* Assess my engineering skills and maintain a plan for my development
	* Ensure I know what is expected of me (and of technology as a whole) in terms of standards, practices and ownership
	* Actively seek and adopt best practice from the engineering community inside and outside DL
2. **Be aligned on outcomes**
	* Own and support our software, being accountable for improving it, fixing issues, and learning from our mistakes
	* Adopt and champion the DL engineering practices
3. **Build trust**
	* Always do my best work
	* Not produce harmful code
	* Not allow technical debt to accumulate (including code that is defective in behaviour or structure)
	* Leave the code better than I found it
	* Produce estimates that are honest in magnitude and precision. Not make promises without reasonable certainty
	* Respect my fellow engineers
	* Give and receive constructive feedback on our work frequently and gracefully
4. **Encourage simplicity**
	* Practice and encourage simple design and clean, high quality code
	* Continually refactor our code, architecture and processes
5. **Empowered teams**
	* Make frequent, small changes so that I do not impede the progress of others
	* Code collaboratively, actively participating in code review, pairing and swarming as a team
	* Take collective ownership, ensuring I can cover for others, and they can cover for me
6. **Test, learn and adapt**
	* Write comprehensive automated tests to provide continuous feedback and confidence
	* Never stop learning and developing my craft
	* Continuously improve our software, our engineering practices, and our live services


## As an Engineering Manager/Chapter Lead I will

1. **Be curious**
	* Help my team understand what is expected and what good looks like for engineering - set the engineering bar
	* Get to know my team’s engineering skills and development areas
	* Encourage my team to continually explore learning from the DL and external engineering communities
2. **Be aligned on outcomes**
	* Take accountability and ownership for the technology platforms and applications owned by my team
	* Help my team understand and adopt the DL engineering practices
	* Ensure my team prioritise and take ownership of run and support and establish good operations practices
	* Ensure technology and security standards, governance, risk and controls are understood and effectively operated by my team
	* Be prepared to roll up my sleeves and help the team get things done
	* Steer with data, use engineering metrics to help my team manage performance
3. **Build trust**
	* Champion and defend the team’s commitment to engineering practices, standards, learning and continuous improvement
	* Create the space and time for the team to do their best work
	* Create a culture of collaboration and feedback within and across teams
	* Provide development, practices and skills feedback and coaching to the team
4. **Encourage simplicity**
	* Encourage my team to continually practice simple design and clean coding
	* Encourage my team to take ownership for the health and maintenance of the architecture
5. **Empowered teams**
	* Encourage and challenge the team to take ownership individually and collectively
	* Ensure adequate and fair sharing of support and out of hours duties
	* Champion and defend the team’s engineering decisions with others
6. **Test, learn and adapt**
	* Challenge my team to continually improve
	* Create the space and the time for learning and improvement; defending as needed
	* Create a safe environment for the team to experiment and test without fearing failure


