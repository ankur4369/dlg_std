import {themes as prismThemes} from 'prism-react-renderer';
import type {Config} from '@docusaurus/types';
import type * as Preset from '@docusaurus/preset-classic';

const config: Config = {
  title: 'DL Engineering Handbook',
  tagline: 'Not just what to do, but how to do it!',
  favicon: 'img/favicon.ico',

  // Set the production url of your site here
  url: 'https://your-docusaurus-site.example.com',
  // Set the /<baseUrl>/ pathname under which your site is served
  // For GitHub pages deployment, it is often '/<projectName>/'
  baseUrl: '/',

  // GitHub pages deployment config.
  // If you aren't using GitHub pages, you don't need these.
  organizationName: 'Direct-Line-Group', // Usually your GitHub org/user name.
  projectName: 'se-engineering-handbook', // Usually your repo name.

  onBrokenLinks: 'throw',
  onBrokenMarkdownLinks: 'warn',

  // Even if you don't use internationalization, you can use this field to set
  // useful metadata like html lang. For example, if your site is Chinese, you
  // may want to replace "en" with "zh-Hans".
  i18n: {
    defaultLocale: 'en',
    locales: ['en'],
  },

  presets: [
    [
      'classic',
      {
        docs: {
          sidebarPath: './sidebars.ts',
          // Please change this to your repo.
          // Remove this to remove the "edit this page" links.
          editUrl:
            'https://github.com/Direct-Line-Group/se-engineering-handbook/tree/main/',
        },
        theme: {
          customCss: './src/css/custom.css',
        },
      } satisfies Preset.Options,
    ],
  ],

  markdown: {
    mermaid: true,
  },
  themes: ['@docusaurus/theme-mermaid'],


  themeConfig: {
    // Replace with your project's social card
    image: 'img/docusaurus-social-card.jpg',
    navbar: {
      title: 'Engineering Handbook',
      logo: {
        alt: 'Direct Line Group Logo',
        src: 'img/dlg-logo.png',
      },
      items: [
        {
          type: 'docSidebar',
          sidebarId: 'homeSidebar',
          position: 'left',
          label: 'Handbook Home',
        },
        {
          type: 'doc',
          docId: 'sdlc/sdlc',
          position: 'left',
          label: 'Development Lifecycle',
        },
        {
          type: 'doc',
          docId: 'standards/Coding/coding',
          position: 'left',
          label: 'Coding Standards',
        },
        {
          href: 'https://github.com/Direct-Line-Group',
          label: 'DL GitHub',
          position: 'right',
        },
      ],
    },
    footer: {
      style: 'dark',
      links: [
        {
          title: 'Quick Finds',
          items: [
            {
              label: 'SDLC',
              to: '/docs/sdlc/sdlc',
            },
            {
              label: 'How to Contribute?',
              to: 'docs/category/contribute-to-the-handbook',
            },
          ],
        },
        {
          title: 'Useful Links',
          items: [
            {
              label: 'IT Security Standards',
              href: 'https://directlinegroup.sharepoint.com/sites/CyberSecurityAcademy/SitePages/Information-Security-Mandatory-Requirements-(ISMRs)-%26-Technical-Security-Standards-(TSSs).aspx',
            },
            {
              label: 'DL Sharepoint',
              href: 'https://directlinegroup.sharepoint.com/',
            },
          ],
        },
        {
          title: 'Communities',
          items: [
            {
              label: 'Software Engineering',
              href: 'https://teams.microsoft.com/l/team/19%3AT6gAUiVVWShlG8M891i9yoi1uZgEQWc7pFobT6wFD8M1%40thread.tacv2/conversations?groupId=a26614a7-695c-46a2-b9b0-2397f04e6db2&tenantId=c0ff82c4-9cdf-4a22-931d-9a43eaee85ef',
            },
            {
              label: 'Guidewire',
              href: 'https://teams.microsoft.com/l/channel/19%3Af45cc4fc6447499987992c44de67a2f8%40thread.tacv2/General?groupId=12711bd0-99cb-46e0-895f-7a644e12871a',
            },
            {
              label: 'SDET',
              href: 'https://teams.microsoft.com/l/team/19%3aj7VUoQYq2JWbJZ0_dQgUyunCQXesEJ9-kWnx-KvkREc1%40thread.tacv2/conversations?groupId=531e9ca7-4efb-46a9-909e-3b279a96153e&tenantId=c0ff82c4-9cdf-4a22-931d-9a43eaee85ef',
            },
            {
              label: 'Frontend',
              href: 'https://teams.microsoft.com/l/team/19%3afe657fa5d8684e04a925181d1d9bff2f%40thread.tacv2/conversations?groupId=901bb1ff-6eab-47db-b1c1-cfa0e9c04807&tenantId=c0ff82c4-9cdf-4a22-931d-9a43eaee85ef',
            },
            {
              label: 'Reliability',
              href: 'https://teams.microsoft.com/l/channel/19%3a676c5de35fb94b378ffdce97f387fed3%40thread.tacv2/Reliability%2520Engineering%2520Community?groupId=9d5230c2-4753-4e47-a003-6a0eb67c089e&tenantId=c0ff82c4-9cdf-4a22-931d-9a43eaee85ef',
            },
          ],
        },
      ],
      copyright: `Copyright © ${new Date().getFullYear()} Direct Line Group. Built with Docusaurus.`,
    },
    prism: {
      theme: prismThemes.github,
      darkTheme: prismThemes.dracula,
    },
  } satisfies Preset.ThemeConfig,
};

export default config;
