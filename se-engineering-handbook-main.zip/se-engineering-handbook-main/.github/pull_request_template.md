# Description

*Briefly* - describe what documentation has changed?

## Type of change

What type of documentation change is this?

- [ ] Major - Breaking change where external links/entrypoints may change -
  large structure rewrites etc.
- [ ] Minor - Adding to/updating a Standard/Guide/Section (**normally this will
  be your change!**)
- [ ] Patch - Doc Chore i.e. Typo Fix, Link Fix, Docusaurus Config, Hosting
  Maintenance etc.

## Checklist

Please review the following:

- [ ] No secrets, PII, or sensitive information is present
- [ ] No operational information is present - only standards, approaches or
  platform/technical wide guidance

## Guidance

If one of the checks fails attached to this PR - this usually means the Markdown
linting has an issue.

Open the check that has failed and it will guide you on what to fix.

> [!TIP]
> Actions validate this checklist. If a check box is not applicable it must be
> redacted `- [ ] ~Major - Breaking change where external links/entrypoints`
> `may change - large structure rewrites etc.~`.
> See the root README for further details.

Also...

> [!TIP]
> There is a line size limit of 80 characters in the Markdown (.md) files -
> there are plugins to help structure this in your editor - for VS Code for
> example [Prettier](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)
> can help format this for you automatically [Alt+Q].
