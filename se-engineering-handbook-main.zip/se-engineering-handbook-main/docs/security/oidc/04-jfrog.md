# JFrog

## GitHub

Using OIDC within GitHub Action workflows allow us to authenticate with JFrog
without needing to store [Basic Authentication](https://jfrog.com/help/r/jfrog-platform-administration-documentation/basic-authentication)
details or [Access Tokens](https://jfrog.com/help/r/jfrog-platform-administration-documentation/access-tokens)
credentials in long-lived GitHub secrets.

To understand how GitHub's OIDC provider integrates with JFrog see
[Getting started with OIDC](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect).

### Setup

The GitHub documentation provides a detailed [guide](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/configuring-openid-connect-in-jfrog)
on configuring for JFrog, as does the JFrog [documentation](https://jfrog.com/help/r/jfrog-platform-administration-documentation/configure-jfrog-platform-oidc-integration-with-github-actions).

#### OIDC Integration

OIDC Integration has been enabled at the tool level by our administrators with
the GitHub Organisation. You can view this integration by selecting your
project, switching to the `Administration` tab, then selecting `General Management`
-> `Manage Integrations`.

![integrations](./assets/integrations.png)

![integration](./assets/integration.png)

To enable individual GitHub repositories access to JFrog projects, the project
requires one or more [Identity Mappings](https://jfrog.com/help/r/jfrog-platform-administration-documentation/identity-mappings)
which JFrog uses to match an incoming OIDC claim to a specific authorisation scope.

![mappings](./assets/mappings.png)

To add a new mapping select the `Add Identity Mapping` button:

![mapping-add](./assets/mapping-add.png)

Enter a description, set the Claims JSON with the repository as a minimum (further
details for a claim can be found [here](https://jfrog.com/help/r/jfrog-platform-administration-documentation/json-claims)),
assign the role you wish to assume in JFrog and set a token expiration time.

![mapping-new](./assets/mapping-new.png)

Now create a test GitHub workflow in the repository:

```YAML
name: Setup JFrog CLI OIDC Example

on: workflow_dispatch

permissions:
  # This is required for requesting the OIDC token
  id-token: write
  # This is required for actions/checkout
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:

      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup JFrog CLI
        uses: jfrog/setup-jfrog-cli@v4
        env:
          # Our JFrog instance URL
          JF_URL: ${{ vars.JFROG_SERVER_URL }}
          # The project you wish to access during the action run
          JF_PROJECT: project
        with:
          # The provider name from the tool level integration
          oidc-provider-name: ${{ vars.JFROG_OIDC_PROVIDER_NAME }}
          # The audience from the tool level integration
          oidc-audience: ${{ vars.JFROG_OIDC_AUDIENCE }}

      - name: Run JFrog CLI
        run: |
          # Ping the server
          jf rt ping
          # Get the repositories from the project
          jf rt curl -XGET /api/repositories
          # Output the version
          jf --version
```

:::note
The environment variables shown above are defined at the GitHub organization
level, making them available to all repositories.

Also, ensure the role the identity mapping assumes has the required permissions
required by the action.
:::

Trigger the workflow run and the action will access our JFrog instance, list
all the repositories of the project, and output the version of the CLI.

Example:

![out1](./assets/output1.png)

![out2](./assets/output3.png)

![out3](./assets/output3.png)
