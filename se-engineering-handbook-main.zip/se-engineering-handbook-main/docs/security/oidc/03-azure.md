# Azure

## GitHub

Using OIDC within GitHub Action workflows allow us to authenticate with Azure
without needing to store a [Service Principle](https://learn.microsoft.com/en-us/azure/developer/github/connect-from-azure-secret)
`clientId` and `clientSecret` credentials in long-lived GitHub secrets.

To understand how GitHub's OIDC provider integrates with cloud providers see
[Getting started with OIDC](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect#getting-started-with-oidc).

### Setup

The GitHub documentation provides a detailed [guide](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/configuring-openid-connect-in-azure)
on configuring for Azure.

### Secure Pipelines

The identity your GitHub pipeline assumes from the Azure application should have
the correct level of trust and policies so that it limits which GitHub actions
are able to assume the role.

This is achieved through the use of the token. For more details on how to
harden these policies see the GitHub guide [Understanding the OIDC token](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect#understanding-the-oidc-token).

Below are examples of good and bad of `Subject identifier` field policy
conditions:

#### Example 1 - Good

This allows a workflow for the dev environment from the
Direct-Line-Group/example-repo organisation and repository to assume a principle
in the Azure account.

```text
Organization: Direct-Line-Group
Repository: example-repo
Entity type: Environment
GitHub environment name: dev
```

#### Example 2 - Good

This allows a workflow for the main branch from the
Direct-Line-Group/example-repo organisation and repository to assume a principle
in the Azure account.

```text
Organization: Direct-Line-Group
Repository: example-repo
Entity type: Branch
GitHub environment name: main
```

#### Example 3 - Bad

This policy allows ***any*** repository from the Direct-Line-Group organisation
to assume a principle in the Azure account.

```text
Organization: Direct-Line-Group
Repository: *
Entity type: *
```

#### Example 4 - Bad

This policy allows the repository from the Direct-Line-Group organisation
to assume a principle in the Azure account for ***any*** entity type.

```text
Organization: Direct-Line-Group
Repository: example-repo
Entity type: *
```

This policy allows any branch, pull request merge branch, or
environment from the Direct-Line-Group/example-repo organisation and repository
to assume a a principle in the Azure account.

More details can be found [here](https://learn.microsoft.com/en-us/entra/workload-id/workload-identity-federation-create-trust?pivots=identity-wif-apps-methods-azp#configure-a-federated-identity-credential-on-an-app)
.

## Terraform Cloud (TFC)

Using OIDC within TFC allow us to authenticate with Azure
without needing to store a [Service Principle](https://learn.microsoft.com/en-us/azure/developer/github/connect-from-azure-secret)
`clientId` and `clientSecret` credentials in long-lived Terraform sensitive variables.

### Setup

The TFC documentation provides a detailed [guide](https://developer.hashicorp.com/terraform/cloud-docs/workspaces/dynamic-provider-credentials/azure-configuration)
on configuring for Azure and further details on the different methods
[Azure Provider: Authenticating using a Service Principal with Open ID Connect](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/guides/service_principal_oidc)

### Secure Pipelines

The identity your TFC pipeline assumes should have the correct level of trust
and [policies](https://learn.microsoft.com/en-us/azure/security/fundamentals/identity-management-best-practices)
so that it limits which TFC workspace are able to assume the role.

This is achieved through the use trust configuration of the [issuer](https://learn.microsoft.com/en-us/azure/security/fundamentals/identity-management-best-practices)
.

For more details on how to harden these policies see the GitHub guide
[Understanding the OIDC token](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect#understanding-the-oidc-token).

Below is an example of a trust:

```text
Federated credential scenario: Other issuer
Issuer: https://app.terraform.io
Subject identifier: organization:Direct-Line-Group:project:*:workspace:example-workspace:run_phase:*
Name: tfc-credential
Audience: api://AzureADTokenExchange
```

:::note
In DL we don't use `Projects` in TFC. Each workspace is in the default project.
Hence the `*` between this section `project:*:workspace`.
:::

### Workspace Configuration

The TFC workspace will need environment variables set in order for it to
authenticate with AWS. These are:

```text
TFC_AZURE_PROVIDER_AUTH=true
TFC_AZURE_RUN_CLIENT_ID=93b45f3a-47b3-45b8-b35f-1bd07e931546
```

:::note
`TFC_AZURE_RUN_CLIENT_ID` is the client ID for the Service Principal /
Application used when authenticating to Azure.
:::

For further information see [Configure HCP Terraform](https://developer.hashicorp.com/terraform/cloud-docs/workspaces/dynamic-provider-credentials/azure-configuration#configure-hcp-terraform)
.
