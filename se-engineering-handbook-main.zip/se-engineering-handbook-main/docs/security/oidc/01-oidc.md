# OpenID Connect

OpenID Connect (OIDC) is an authentication protocol built on top of [OAuth 2.0](https://datatracker.ietf.org/doc/html/rfc6749).
It allows users to authenticate (prove their identity) using an identity provider
(GitHub, Microsoft, or another trusted service), while also enabling secure
access to applications and resources.

OIDC extends OAuth 2.0 by adding an **ID token**, which contains user
authentication information, in addition to the standard OAuth access token used
for authorization (accessing resources).

Key components of OIDC include:

1. **ID Token**: A JSON Web Token (JWT) that contains identity information about
   the user, such as their username, email, and authentication method.
1. **Authorization Code Flow**: A secure way to authenticate users and obtain
   tokens (both ID and access tokens) for use in accessing protected resources.
1. **Discovery & Federation**: OIDC allows easy integration with different
   identity providers by using metadata endpoints to dynamically configure
   authentication parameters.
1. **Single Sign-On (SSO)**: OIDC is commonly used to enable SSO, allowing
   users to sign in once and access multiple applications without re-authenticating.

OIDC is widely used for applications where user authentication is required but
not necessarily user authorization, and it’s commonly used for scenarios like
logging in to websites, mobile apps, and even cloud platforms.

:::note
OIDC is the preferred method for authenticating with Cloud providers in DL.
Every effort must be undertaken to not rely on long-lived credentials. See the
further sections in this guide on how this can be achieved.
:::
