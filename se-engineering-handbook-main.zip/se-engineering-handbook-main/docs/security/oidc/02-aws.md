# Amazon Web Services (AWS)

## GitHub

Using OIDC within GitHub Action workflows allow us to authenticate with AWS
without needing to store AWS IAM [Access Key](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_access-keys.html)
credentials in long-lived GitHub secrets.

To understand how GitHub's OIDC provider integrates with cloud providers see
[Getting started with OIDC](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect#getting-started-with-oidc).

### Setup

The GitHub documentation provides a detailed [guide](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services)
on configuring for AWS.

We also have examples of setting this up via a Terraform module:

- [GitHub](#github-oidc-using-terraform)
- [Terraform Cloud](#tfc-oidc-using-terraform)

### GitHub OIDC Using Terraform

A Terraform module exists which can simplify the setup of OIDC from GitHub
to AWS.

Below is a simple example of setting up OIDC with GitHub:

```HCL
module "iam_assumable_role_with_oidc" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-assumable-role-with-oidc"
  version = "5.48.0"

  create_role = true

  role_name = "github-example-role"

  tags = {
    project              = "example-project"
    infrastructure_level = "account"
    provisioned_by       = "terraform"
  }

  provider_url = "token.actions.githubusercontent.com"

  provider_trust_policy_conditions = [
    {
      test     = "StringEquals"
      variable = "token.actions.githubusercontent.com:aud"
      values   = ["https://github.com/Direct-Line-Group"]
    },
    {
      test     = "StringLike"
      variable = "token.actions.githubusercontent.com:sub"
      values   = ["repo:Direct-Line-Group/example-repository:*"]
    }
  ]

  role_policy_arns = [
    "arn:aws:iam::aws:policy/example-policy",
  ]
}
```

:::info
The OIDC providers in AWS accounts are managed centrally by the AWSCP team in
a GitHub repository [engprod-oidc-providers](https://github.com/Direct-Line-Group/engprod-oidc-providers).

Please open a pull request to add the GitHub provider to your account.
:::

### Secure Pipelines

The IAM role your GitHub pipeline assumes should have the correct level of trust
and [policies](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html)
so that it limits which GitHub actions are able to assume the role.

This is achieved through the use condition key `token.actions.githubusercontent.com:sub`.
For more details on how to harden these policies see the GitHub guide
[Understanding the OIDC token](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect#understanding-the-oidc-token).

Below are examples of good and bad of `sub` policy conditions:

#### Example 1 - Good

This policy allows a workflow for the dev environment from the
Direct-Line-Group/example-repo organisation and repository to assume a role in
the AWS account.

```json
{
  "Version": "2012-10-17",
  "Statement": [
      {
          "Effect": "Allow",
          "Principal": {
              "Federated": "arn:aws:iam::999999999:oidc-provider/token.actions.githubusercontent.com"
          },
          "Action": "sts:AssumeRoleWithWebIdentity",
          "Condition": {
              "StringLike": {
                  "token.actions.githubusercontent.com:sub": "repo:Direct-Line-Group/example-repo:environment:dev"
              },
              "StringEquals": {
                  "token.actions.githubusercontent.com:aud": "https://github.com/Direct-Line-Group"
              }
          }
      }
  ]
}
```

#### Example 2 - Good

This policy allows a workflow for the main branch from the
Direct-Line-Group/example-repo organisation and repository to assume a role in
the AWS account.

```json
{
  "Version": "2012-10-17",
  "Statement": [
      {
          "Effect": "Allow",
          "Principal": {
              "Federated": "arn:aws:iam::999999999:oidc-provider/token.actions.githubusercontent.com"
          },
          "Action": "sts:AssumeRoleWithWebIdentity",
          "Condition": {
              "StringLike": {
                  "token.actions.githubusercontent.com:sub": "repo:Direct-Line-Group/example-repo:ref:refs/heads/main"
              },
              "StringEquals": {
                  "token.actions.githubusercontent.com:aud": "https://github.com/Direct-Line-Group"
              }
          }
      }
  ]
}
```

#### Example 3 - Bad

This policy allows ***any*** repository from the Direct-Line-Group organisation
to assume a role in the AWS account.

```json
{
  "Version": "2012-10-17",
  "Statement": [
      {
          "Effect": "Allow",
          "Principal": {
              "Federated": "arn:aws:iam::999999999:oidc-provider/token.actions.githubusercontent.com"
          },
          "Action": "sts:AssumeRoleWithWebIdentity",
          "Condition": {
              "StringLike": {
                  "token.actions.githubusercontent.com:sub": "repo:Direct-Line-Group/*"
              },
              "StringEquals": {
                  "token.actions.githubusercontent.com:aud": "https://github.com/Direct-Line-Group"
              }
          }
      }
  ]
}
```

#### Example 4 - Bad

This policy allows any branch, pull request merge branch, or
environment from the Direct-Line-Group/example-repo organisation and repository
to assume a role in the AWS account.

```json
{
  "Version": "2012-10-17",
  "Statement": [
      {
          "Effect": "Allow",
          "Principal": {
              "Federated": "arn:aws:iam::999999999:oidc-provider/token.actions.githubusercontent.com"
          },
          "Action": "sts:AssumeRoleWithWebIdentity",
          "Condition": {
              "StringLike": {
                  "token.actions.githubusercontent.com:sub": "repo:Direct-Line-Group/example-repo:*"
              },
              "StringEquals": {
                  "token.actions.githubusercontent.com:aud": "https://github.com/Direct-Line-Group"
              }
          }
      }
  ]
}
```

## Terraform Cloud (TFC)

Using OIDC within Terraform Cloud allow us to authenticate to AWS without
needing to store AWS IAM [Access Key](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_access-keys.html)
credentials in long-lived Terraform sensitive variables.

### Setup

The TFC documentation provides a detailed [guide](https://developer.hashicorp.com/terraform/cloud-docs/workspaces/dynamic-provider-credentials/aws-configuration)
on configuring for AWS.

:::info
The OIDC providers in AWS accounts are managed centrally by the AWSCP team in
a GitHub repository [engprod-oidc-providers](https://github.com/Direct-Line-Group/engprod-oidc-providers).

Please open a pull request to add the TFC provider to your account.
:::

### Secure Pipelines

The IAM role your TFC pipeline assumes should have the correct level of trust
and [policies](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html)
so that it limits which TFC workspace are able to assume the role.

This is achieved through the use condition key `token.actions.githubusercontent.com:sub`.
For more details on how to harden these policies see the GitHub guide
[Understanding the OIDC token](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect#understanding-the-oidc-token).

Below is an example of a trust:

```json
{
  "Version": "2012-10-17",
  "Statement": [
      {
          "Sid": "EnableAssume",
          "Effect": "Allow",
          "Principal": {
              "Federated": "arn:aws:iam::999999999:oidc-provider/app.terraform.io"
          },
          "Action": "sts:AssumeRoleWithWebIdentity",
          "Condition": {
              "StringEquals": {
                  "app.terraform.io:aud": "aws.workload.identity"
              },
              "StringLike": {
                  "app.terraform.io:sub": "organization:Direct-Line-Group:project:*:workspace:example-workspace:run_phase:*"
              }
          }
      }
  ]
}
```

:::note
In DL we don't use `Projects` in TFC. Each workspace is in the default project.
Hence the `*` between this section `project:*:workspace`.
:::

### Workspace Configuration

The TFC workspace will need environment variables set in order for it to
authenticate with AWS. These are:

```text
TFC_AWS_PROVIDER_AUTH=true
TFC_AWS_RUN_ROLE_ARN=arn:aws:iam::99999999:role/example-role
```

:::note
`TFC_AWS_RUN_ROLE_ARN` will be the ARN of the role created in AWS for TFC to
assume.
:::

For further information see [Configure HCP Terraform](https://developer.hashicorp.com/terraform/cloud-docs/workspaces/dynamic-provider-credentials/aws-configuration#configure-hcp-terraform)
.

### TFC OIDC Using Terraform

A Terraform module exists which can simplify the setup of OIDC from TFC to AWS.

Below is a simple example of setting up OIDC with TFC:

```HCL
module "iam_assumable_role_with_oidc" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-assumable-role-with-oidc"
  version = "5.48.0"

  create_role = true

  role_name = "tfc-example-role"

  tags = {
    project              = "example-project"
    infrastructure_level = "account"
    provisioned_by       = "terraform"
  }

  provider_url = "app.terraform.io"

  provider_trust_policy_conditions = [
    {
      test     = "StringEquals"
      variable = "app.terraform.io:aud"
      values   = ["aws.workload.identity"]
    },
    {
      test     = "StringLike"
      variable = "app.terraform.io:sub"
      values   = ["organization:Direct-Line-Group:project:*:workspace:example-workspace:run_phase:*"]
    }
  ]

  role_policy_arns = [
    "arn:aws:iam::aws:policy/example-policy",
  ]
}
```
