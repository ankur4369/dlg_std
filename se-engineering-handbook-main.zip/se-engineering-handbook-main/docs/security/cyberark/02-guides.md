# Guides

## New CyberArk Safe Creation

CyberArk safe creation is requested via IT Direct using this [form](https://dlg.service-now.com/sp?id=sc_cat_item&table=sc_cat_item&sys_id=1e6265aedb19985074fff3731d961981)
.

![form1](./assets/new-safe1.png)

- `Request Type`: Choose Option of Create New Safe.
- `Owners`: Choose at least 2 Owners for this safe.
- `Does this safe relates to an Application or Service`: If your application has
  an CMDB entry please choose yes or else choose no (refer to next screenshot).
- `Application or Service Name`: Choose Application/CMDB Service Name.
- `Environment`: Choose if the environment is prod or Non-prod.
- `Select Colleague who will need access to this safe`: Choose team members who
  needs access to this safe.

If you don't have have an existing CMDB Service Name:

In this scenario, there would be 4 safes created by default.

- `<SafeName_Provided>_N_A` (For AWS)
- `<SafeName_Provided>_N_A_SP` (For AWS with Show Password Option)
- `<SafeName_Provided>_N_G` (For Azure/On-Prem/Legal)
- `<SafeName_Provided>_N_G_SP` (For Azure/On-Prem/Legal with Show Password option)

(SP = Show Password. Users can show copy password as well as Connect,
For Ex: Service accounts that are not automatically managed by CyberArk for
password rotation).

Please make sure to use the relevant safe depending on AWS/Azure/On-Prem/Legal.

![form2](./assets/new-safe2.png)

## Requesting Service and Privileged Account Administration

CyberArk Service Account creation for the newly created safe is requested via
IT Direct using this [form](https://dlg.service-now.com/sp?id=sc_cat_item&table=sc_cat_item&sys_id=1e6265aedb19985074fff3731d961981)
.

![form3](./assets/ad1.png)

- `Is this request for an AD domain Account? Choose`: Yes or No depending on how
  you want to manage the service account.
- `Select the AD domain`: Choose appropriate AD. GWD (Managed by IAM Team),
  AWSRD (Managed by [~ MotorPlatformSupport](mailto:MotorPlatformSupport@directlinegroup.co.uk))
- `User Type`: Choose as per requirement either Service Account or Privileged
  CyberArk Account.
- `Request Type`: Choose Create as we are creating a new service account.
- `Application Name`: Choose Application/CMDB Service Name.
- `Environment`: Choose if the environment is prod or Non-prod.
- `Description`: Please provide a short description about the service account
  and it’s uses.
- `Specific Password Requirement`: Please mention forbidden character if any.
- `Do you know what system access is required`: Choose Yes if you are aware about
  the requirement.
- `CyberArk Safe Account to be on boarded to`: Choose the CyberArk Safe.
- `Does usage of this account require secondary approval`: Please choose as per
  the requirement. For ex: If it’s a critical business logic such as Radar then
  having secondary approval is preferable.

## Create new AWSRD AD groups and CyberArk service accounts to be added

Raise a request to have AD groups created in AWSRD Active Directory with
[~ MotorPlatformSupport](mailto:MotorPlatformSupport@directlinegroup.co.uk) or
on their [Jira Board](https://directline.atlassian.net/jira/software/c/projects/DEV/boards/6442?label=MPS)
.

Example:

- `Summary`: Billing: Please create/update AWSRD AD Groups and add members
- `Acceptance Criteria`: All relevant AWSRD AD groups created/updated
- `Description`: Hi Team, Please can you create the following AD groups in
  AWSRD and add the respective service accounts as members. These are for
  `your_project`: Add a table that maps AWSRD Group Names to AWSRD Accounts

Once complete submit the ticket. Or you can clone a previous ticket [here](https://directline.atlassian.net/browse/DEV-2420).

### AD Group Naming

AD Groups should utilise the following naming scheme:

AWSRD-`<service name>`-`<environment>`-`<name/role of the group>`

As an example: `AWSRD-BCSS-Prod-Admins`

## Request an RFC be raised by the Cloud Team in the shared services account

:::note
This is only required for Amazon Managed Services (AMS) Accounts.
:::

Submit a request to the AWSCP team using their [form](https://dlg.service-now.com/sp?id=sc_cat_item&sys_id=cecd3742db2b0c5074fff3731d9619fd)
in IT Direct.

![awscp](./assets/request.png)

Example:

- `Request Type`: Change to existing Service
- `Summary`: Project Name - Raise RFC with AMS via Shared Services account to
  trust AD groups
- `Description`: Hi Team. Please can you raise an RFC with AMS via the shared
  services account for the following AD groups to be trusted to allow additional
  CyberArk groups to have remote access.
  - Account Name: AAAAAAAAAAA
  - Account ID: XXXXXXXXX
  - AWSRD Groups:
    - sSRV-DL-HAS-AMS-HomeVCP-NonProd-Dev
    - sSRV-DL-HAS-AMS-HomeVCP-NonProd-Test

:::note
The example AD Groups listed above are from existing groups for AMS Accounts
hence the different naming convention to the guide.
:::
