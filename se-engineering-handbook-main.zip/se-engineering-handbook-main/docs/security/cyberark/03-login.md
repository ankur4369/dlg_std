# Server Login

## Connecting to CyberArk

Login in to CyberArk using [https://dlg.cyberark.cloud](https://dlg.cyberark.cloud)

:::note
Other steps may be required if you are from a vendor.
:::

Enter your username and validate login with MFA.

![awscp](./assets/login.png)

A screen similar to this will appear:

![awscp](./assets/ui.png)

If no accounts are showing, due to a previous search, clear the search by
clicking on the search box in the top right and hitting enter (basically
doing a blank search).

All available accounts associated with your CyberArk safe will be listed.

Select either a Windows or Linux account depending on what you are trying to
do (usually denoted by LNX or WIN in the Platform ID column, or LNX in the
username)

Select an account and then press Connect.

- Type in reason for connecting to the server
- Type in server’s IP address in “Remote Machine” field

![awscp](./assets/connect.png)

## Getting Elevated Access (Grant Stack Admin)

To get the elevated / root access, an rfc needs to be raised from managed
\\services (AWS Console) to Grant Admin access.

If this is a repeat, you can usually search for a similar rfc and copy it.

Once the RFC has completed successfully use the following the commands to
switch as root user shown in the picture.

Once you have logged in to CyberArk and elevated access.

```sh
ssh gwd\\racfid@localhost
sudo su  -
```

![awscp](./assets/connected.png)

### Check Volume details

To check the volume details please run the following commands.

```sh
dh -h
```

![awscp](./assets/volume.png)

```sh
nvme list
```

![awscp](./assets/nvme.png)

## RADAR

Before being able to fully connect to Radar Windows Servers, you need to get a
second level approval from Pricing & Rating team using the below option.

![awscp](./assets/radar.png)

Once raised 1 user(s) must confirm the request from the Pricing & Underwriting
team. If you encounter any issues with confirmation of the request please reach
out to [P&U Chapter](mailto:#P&U-Chapter@directlinegroup.co.uk)
