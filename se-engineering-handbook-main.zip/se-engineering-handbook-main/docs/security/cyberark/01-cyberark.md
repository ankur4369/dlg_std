# CyberArk

## What is it?

CyberArk is DLGs standard credentials management system and it effectively
removes the ability of standard user accounts to remotely log in to servers
without any controls and thus be open to exploitation.

## What is it used for?

- Handling all remote connectivity to servers in our AWS/Azure accounts.
- Storing of service account passwords and also secrets/credentials used by
  other systems.

## Accounts & Safes

CyberArk accounts, once created and on boarded, are given access to specific
pools of servers or applications and then users are given access to these
accounts via logical groups called safes that reside in CyberArk.

Users are allowed access to these accounts via the CyberArk interface and this
is done via AD group membership, without the need to expose any server account
passwords.

## How is it used?

As a user needing remote access to a server in AWS, I login to CyberArk SaaS
from a browser to [https://dlg.cyberark.cloud](https://dlg.cyberark.cloud)

After selecting a CyberArk account to use and server IP to connect to,
CyberArk SaaS connects to the remote CyberArk hosts/PSM servers in
DL Security Tooling account.

CyberArk Remote Hosts then initiate RDP/SSH connection to EC2 in aws account.

Remote EC2 validates credentials used in the remote connection with AWSRD/GWD AD.

## CyberArk Design Example

```mermaid
architecture-beta
    group cyberark(fluent:building-cloud-24-filled)[CyberArk SaaS]
    service person(fluent:person-12-regular)[CyberArk User] in cyberark

    group aws_accounts
    group non_prod(logos:aws-cloudformation)[Non Prod] in aws_accounts
    service non_prod_server(logos:aws-ec2) in non_prod
    group prod(logos:aws-cloudformation)[Prod] in aws_accounts
    service prod_server(logos:aws-ec2) in prod

    group security_tooling(logos:aws-cloudformation)[Security Tooling]
    service cyberark_server(fluent:server-16-regular)[CyberArk Remote Host] in security_tooling

    group support_prod(logos:aws-cloudformation)[DL AWS Support Prod]
    service ad_server(fluent:server-16-regular)[AWSRD] in support_prod

    junction junction1
    person{group}:R --> L:cyberark_server{group}
    cyberark_server{group}:R -- L:junction1
    junction1:R -- L:prod_server{group}
    junction1:T -- L:non_prod_server{group}

    junction1:B -- L:ad_server{group}

```

## Requesting Access

Access to CyberArk is managed in Service Now through a
[Manage my Business System Access](https://dlg.service-now.com/sp?id=sc_cat_item_guide&table=sc_cat_item&sys_id=691939fedb8610909caebd5c689619a8)
request.

After entering your RACFID, Division and the Business System is `Cyberark SaaS`.

The following page will ask you to select a role. `CYASAAS: Standard User` is
sufficient for most engineers.

`Please select the permission(s) you require` will be specific to your role in
DL. Please consult your team members for this field.

## Server Login

A basic guide on how to login to the CyberArk and access a server can be found [here](03-login.md).

For a full guide of CyberArk please see the article in ServiceNow [here](https://dlg.service-now.com/sp?id=kb_article_view&table=kb_knowledge&sys_kb_id=010a5f8c1bc54618932ba821ec4bcbdc&searchTerm=Cyberark)
.

## Requesting New Safes

A guide on how to create safes can be found [here](02-guides.md).
