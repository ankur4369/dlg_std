# Why?

Coding standards ensure the solutions we develop have consistency in approach
and implementation throughout DL - particularly where we are using the same
technology stack.

This allows any developer to quickly understand the code base and focus on the
business benefits the code is producing, thanks to a consistent and predefined
approach around naming conventions, code structure, and formatting.
