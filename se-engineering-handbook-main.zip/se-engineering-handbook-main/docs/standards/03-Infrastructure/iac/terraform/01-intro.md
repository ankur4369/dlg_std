# Introduction

Terraform is one of the most used tools in the IaC space that enables us to
safely and predictably apply changes to our infrastructure.

Terraform uses its own configuration language [HCL](https://www.terraform.io/language)
to declare infrastructure objects and their associations. The goal of this
language is to be declarative and describe the system’s state that we want
to reach.

## Resources

Resources represent infrastructure objects and are one of the basic blocks of
the Terraform language.

## Data Sources

Data sources feed our Terraform configurations with external data or data
defined by separate Terraform projects. For example, a list of IP addresses a
cloud provider exposes. Data sources serve as a bridge between the current
infrastructure and the desired configuration, allowing for more dynamic and
context-aware provisioning.

## Modules

Modules help us group several resources and are the primary way to package
resources in Terraform for reusability purposes. A Terraform module is a
collection of standard configuration files in a dedicated directory.
Terraform modules encapsulate groups of resources dedicated to one task,
reducing the amount of code you have to develop for similar infrastructure
components.

## State

Terraform keeps the information about the state of our infrastructure to store
track mappings to our live infrastructure and metadata, create plans and apply
new changes.

## Providers

To interact with resources on cloud providers, Terraform uses some plugins
named providers.
