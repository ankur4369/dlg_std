# Terraform Cloud State Migration to S3

To migrate your state from Terraform Cloud (TFC) to the [S3 backend method](./04-terraformstatemanagement.md)
please see the steps below.

## 1. Export the state from TFC

To begin migrating your state from TFC, a local copy of your latest state is
required. In your working directory that’s currently configured to use TFC
run the following:

```bash
terraform state pull > local_state.tfstate
```

This command retrieves the current state from TFC and writes it to a local file
named `local_state.tfstate`.

:::warning
The state file may contain sensitive information, including provider credentials,
resource configurations, and other confidential data. Handle this file securely.

- Do not commit the state file to version control systems like Git
- Store it in a secure location with restricted access
- Ensure that only authorised personnel can access the file
- Delete the local copy once the migration is complete and it’s no longer needed

:::

## 2. Update Terraform Configuration

To disconnect your working directory from TFC and prepare it for the new backend:

1. Remove the `.terraform` directory
1. Provision the resources for the S3 backend using the [guide](04-terraformstatemanagement.md)
1. Update the configuration for the backend

```terraform
terraform {
  backend "s3" {
    bucket       = "example-bucket-tf-state-account-number"
    key          = "application/environment/remote-backend/terraform.state"
    region       = "eu-west-1"
    use_lockfile = true
  }
}
```

Your Terraform configuration now points to the new S3 backend, effectively
preparing your environment for the state migration.

## 4. Terraform Initialisation with new Backend

Initialise Terraform with the new backend using `terraform init`. This command
initialises your working directory and configures Terraform to use the new S3
backend you specified.

As your new backend doesn’t contain any state yet, Terraform has no record of
the resources you’ve previously deployed. Running `terraform plan` or
`terraform apply` at this stage would make Terraform treat this as a fresh
deployment, proposing to create new instances of all your resources.

## 5. Push the State to the New Backend

Now that your working directory is initialised with the new S3 backend, you need
to upload the previously saved state file to the new backend. This will ensure
that Terraform recognises the current state of your infrastructure. Run:

```bash
terraform state push local_state.tfstate
```

This command writes the `local_state.tfstate` file you saved earlier to the new
backend specified in your configuration.

## 5. Verify the Migration

After pushing your state to the new backend, it’s crucial to verify that the
migration was successful and that Terraform recognises your existing
infrastructure.

Before running a plan, list the resources currently recorded in your state to
ensure they have been successfully migrated:

`terraform state list`

This command will display all the resources that Terraform is managing, as
recorded in the state file stored in your new S3 backend.

You should see a list of all your existing resources that were previously
managed in Terraform Cloud. E.g

```bash
aws_instance.web_server
aws_s3_bucket.static_assets
aws_security_group.web_sg
aws_vpc.main
module.database.aws_db_instance.db
module.network.aws_subnet.public_subnet[0]
module.network.aws_subnet.public_subnet[1]
```

If the list is empty or incomplete, it may indicate that the state was not
properly pushed to the new backend. Revisit the previous steps to ensure the
state file was correctly uploaded.

Next, execute the following command to compare your configuration with the
migrated state:

```bash
terraform plan
```

This command will compare the state stored in your S3 backend with the
resources defined in your Terraform configuration files. Terraform should
recognise that your resources are already in the desired state and should not
propose any changes.

```bash
No changes. Your infrastructure matches the configuration.

Terraform has compared your real infrastructure against your configuration and
found no differences, so no changes are needed.
```

If Terraform proposes to create or destroy resources, this may indicate that
the state migration was not successful or there is a discrepancy between your
configuration and the state.

## 5. Securely Delete the Local State File

Since the state file may contain sensitive information, it’s important to
securely delete the local copy after the migration is complete.

When you have copied the state file from Terraform Cloud to S3 it doesn’t
mean the state has been removed from Terraform Cloud. The state still exists
here and may continue to incur costs. Once you’re confident that the migration
is working as expected, remember to clean up your Terraform Cloud workspaces
and state files to avoid unnecessary charges.
