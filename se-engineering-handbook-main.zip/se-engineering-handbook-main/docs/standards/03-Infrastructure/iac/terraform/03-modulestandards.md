# Module Standards

Terraform Modules are reusable components, the main way to package and reuse
resource configurations with Terraform.

:::tip
We have a GitHub template repository [terraform-aws-module-template](https://github.com/Direct-Line-Group/terraform-aws-module-template)
to get you started with the recommended structure and workflows. When creating
a new Terraform module repository you can either use the template repository
`Use this template` button, or select it from the `Repository template` drop down
when using the `New` button on the organisation main [page](https://github.com/Direct-Line-Group)
.

Following the creation of the repository ensure you update the `README` section
and comply to the remaining sections of this page.
:::

## Patterns

It’s important to consider whether your requirements demand a new [module](https://developer.hashicorp.com/terraform/language/modules/develop#when-to-write-a-module).

A good module should raise the level of abstraction to describe a new higher
level concept encapsulating a reusable configuration of the collection of
resources it provisions.

E.g:

```mermaid
architecture-beta
    service clients(fluent:people-12-regular)[Clients]
    group module(logos:terraform-icon)[Module]
    group vpc(logos:aws-vpc)[VPC] in module
    service apigw(logos:aws-api-gateway)[HTTP API] in module
    service vpclink(logos:aws-vpc)[VPC Link] in vpc
    service lb(logos:aws-elb)[Application Load Balancer] in vpc
    service ecs(logos:aws-ecs)[Fargate Service] in vpc
    clients:R <--> L:apigw
    apigw:R <--> L:vpclink
    vpclink:R <--> L:lb
    lb:R <--> L:ecs
```

:::tip
Follow Terraform recommendations:

"We do not recommend writing modules that are just thin wrappers around single
other resource types. If you have trouble finding a name for your module that
isn't the same as the main resource type inside it, that may be a sign that
your module is not creating any new abstraction and so the module is adding
unnecessary complexity. Just use the resource type directly in the calling
module instead."
:::

## Code Structure

Terraform recommends a [Standard Module Structure](https://developer.hashicorp.com/terraform/language/modules/develop/structure)
and we use a GitHub repository per module.

At a minimum a standard structure is:

```sh
├── README.md
├── main.tf
├── variables.tf
├── outputs.tf
```

And a more complex structure with all the optional elements like nested modules:

```sh
├── README.md
├── main.tf
├── variables.tf
├── outputs.tf
├── ...
├── modules/
│   ├── nested1/
│   │   ├── README.md
│   │   ├── variables.tf
│   │   ├── main.tf
│   │   ├── outputs.tf
│   ├── nested2/
│   ├── .../
├── examples/
│   ├── example1/
│   │   ├── main.tf
│   ├── example2/
│   ├── .../
```

For further details on each of the root files, nested modules and examples see
the link provided above by Terraform.

## Module Name

Terraform modules in our GitHub organisation follow a standard naming pattern.

Including correct naming for discovery e.g. `terraform-<PROVIDER>-<NAME>` where:

- `PROVIDER` is the main provider used by your module e.g. aws, azure
- `NAME` is the higher level concept your module providers e.g. vpc-resources
  (a combination) or apigw-serverless (for a pattern of AWS Lambda/Fargate).

To understand naming at the resource level see the section in the general
standards [here](02-generalstandards.md#naming-conventions)

## Providers

Special care should be taken when defining providers in modules as this can
lead to version conflicts and maintenance overheads. Terraform provide a guide
[here](https://developer.hashicorp.com/terraform/language/modules/develop/providers)
on factors which would be considered. Below are some of note.

:::tip
Providers can be passed down to descendent modules in two ways: either
implicitly through inheritance, or explicitly via the `providers` argument
within a `module` block.
:::

:::tip
A module intended to be called by one or more other modules must not contain
any `provider` blocks. A module containing its own provider configurations is
not compatible with the `for_each`, `count`, and `depends_on` arguments that were
introduced in Terraform v0.13.
:::

## Variables

For variables see the section in the general standards [here](02-generalstandards.md#variable-management)

## Outputs

For outputs see the section in the general standards [here](02-generalstandards.md#outputs)

## README

A fully functioning root level README should exist, explaining intended purpose
of the module and configuration options. Consider adding a Mermaid diagram the
infrastructure resources the module may create and their relationship.

If the module contains nested modules a README should also exist as this it
can still be referenced without using the root module.

:::tip
It is not necessary to document the variables or outputs of the module manually
in the README yourself as this can be automatically generated for you using
[terraform-docs](https://github.com/terraform-docs/terraform-docs) which should
be configured in your `pre-commit` and in [GitHub Actions](https://github.com/terraform-docs/gh-actions).
:::

## Examples

Basic examples of how to externally consume the module must be provided in the
root README using the `source` and in each nested module if present. E.g:

Terraform Cloud Registry:

```hcl
module "splunk_firehose" {
  source  = "app.terraform.io/Direct-Line-Group/kinesis-firehose-splunk/aws"
  version = "0.4.0"

  # variables
  name = "kinesis-firehose-splunk"
}
```

GitHub Repository:

```hcl
module "splunk_firehose" {
  source  = "git@github.com:Direct-Line-Group/kinesis-firehose-splunk/aws?ref=v0.4.0"

  # variables
  name = "kinesis-firehose-splunk"
}
```

The `examples/` subdirectory at the root level should contain practical examples
providing at least two, the first the minimum required to use it, and then a
full complete example showing all options in use.

## Versioning

- Versioning is mandatory for modules so we can provide stability, predictability,
  collaboration, and security.
- Manage versioning through the repository tags and GitHub [Releases](https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases)
  feature.
- Use [Semantic Versioning](https://semver.org/) to enable Major, Minor and
  Patch releases. Therefore consumers know when breaking changes are released.
- Use [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/#summary)
  to support release automation.
- Ensure the README contains steps for releasing new versions.
- Ensure we maintain compatibility:
  - Document breaking changes.
  - Provide migration guides.
  - Use deprecation warnings.

## Protection and Review Requirements

Module repositories require protection and review requirements for change and
ownership.

The repository should have:

- A GitHub team as overall `CODEOWNERS`. See [About Code Owners](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners).
  This team would be the owner of the module and approver for any changes
  made by other members in the GitHub organisation. The owning team should have
  at least three members.
- A GitHub team with admin rights to the repository.
- Add DL GitHub members with write access for collaboration.

The ‘main’ branch should also have protection to require Pull Requests,
`CODEOWNER` review and checks passed before merging.

## CI/CD

Module repositories should use the same process as in the general standards
[here](02-generalstandards.md#cicd) such as adding `pre-commit`, `tflint` etc.

## Terraform Cloud Registry

Importing modules into the private registry in Terraform Cloud requires specific
[permissions](https://developer.hashicorp.com/terraform/cloud-docs/registry/publish-modules#permissions)
. The Tooling team will perform the import process following a submission of a
Technology Tooling Work Engagement [request](https://dlg.service-now.com/sp?id=sc_cat_item&sys_id=38605a681bcd4910c964db5be54bcbd6)
with a link to the repository of the module added to the ticket.

:::tip
Before submitting a new module a review should be completed against these
standards.
:::

:::tip
Terraform Cloud will only discover your repository as a candidate to import if
you have followed the correct naming convention and at least one valid semver
tag as detailed in the [versioning](#versioning) section.
:::

Once imported a webhook with Terraform Cloud will detect any further releases
of the module and import it.

## References

[Hashicorp Terraform Modules](https://developer.hashicorp.com/terraform/tutorials/modules/module)
