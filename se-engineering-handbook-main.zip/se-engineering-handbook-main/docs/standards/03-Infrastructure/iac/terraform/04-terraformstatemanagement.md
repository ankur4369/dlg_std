# Terraform State Management in S3

The Terraform state file `terraform.tfstate` is a JSON file that stores metadata
about the infrastructure managed by Terraform. It keeps track of resource configurations,
dependencies, and mappings between Terraform code and actual cloud resources.

Usage of Terraform State File:

- Tracks Infrastructure State – Maintains the current state of deployed resources
  to prevent unintended changes.
- Facilitates Resource Updates – Compares desired configurations with existing infrastructure
  to determine changes.
- Enables Collaboration – When stored remotely (e.g., in S3, Terraform Cloud),
  it allows teams to work together safely.
- Optimizes Performance – Prevents redundant API calls by caching resource attributes.
- Supports Importing Resources – Helps manage infrastructure not originally
  created by Terraform.
- Since the state file contains sensitive data, securing and storing it properly
  (e.g., using remote backends with encryption) is essential.

## S3 Remote Backend

Remote backends allow Terraform to store the state file in a centralised
location, improving collaboration and security.

- Stores the Terraform state file in an Amazon S3 bucket.
- Provides durability, encryption, and versioning for state management.
- Allows multiple team members to access and modify the state remotely.
- Allows the use of Terraforms S3 native state locking.

As of Terraform [v1.10.0](https://github.com/hashicorp/terraform/releases/tag/v1.10.0)
Terraform's S3 backend includes [S3 Native State Locking](https://developer.hashicorp.com/terraform/language/backend/s3#state-locking)
as an opt in feature. State locking prevents state file conflicts when
multiple users or automation processes access the state file.

## Bootstrapping S3 Remote Backend in new AWS account

- Raise a servicenow request to gain admin access to the AWS account to be bootstrapped
  to.

- Setup local AWS profile and use azure login utility to assume the admin role.
  Execute the command `aws sts get-caller-identity` to make sure the correct
  role in the correct account has been assumed.

- Make sure the latest version of Terraform is being used i.e ~>v1.10.0.
  Version of terraform on any local desktop can be checked by running command
  `terraform --version`.

- In your infrastructure directory, create a separate folder for your S3 Remote
  backend. This guide assumes this directory is called `remote-backend`. This
  is to separate your application terraform state from your s3 remote backend
  state. The application infrastructure can then be deleted without deleting the
  s3 remote backend.

- In this direcory add a s3.tf file to create an s3 bucket by calling DLGs
  [terraform s3 module](https://github.com/Direct-Line-Group/terraform-aws-s3-bucket).
  The s3 module can be called from either the Terraform registry or from a git source:

```hcl
# Git source
module s3_bucket {
  source = "git@github.com:Direct-Line-Group/terraform-aws-s3-bucket.git?ref=c72031574768a11b235bfc7d05b573fef2a69561" #v0.0.2
  ...
}
```

```hcl
# Terraform registry source
module s3_bucket {
  source = "app.terraform.io/Direct-Line-Group/s3-bucket/aws"
  version = 0.0.2
  ...
}
```

A sample implementation of the module can be found [here](https://github.com/Direct-Line-Group/terraform-aws-s3-bucket/tree/main/examples/terraform-state)

- Add a `versions.tf` file with content as:

```hcl
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.50.0, < 6.0.0"
    }
  }
  required_version = ">= 1.10.5"
}
```

- Connect to the AWS account using azure-login mechanism and perform a terraform
  init, plan and apply stages on the terraform code. On successful execution of
  terraform code an S3 bucket should be created in the remote aws account.
  Verify if the S3 bucket exists and all the expected configuration has been
  set correctly i.e. KMS encryption, bucket policy and bucket ownership.
- At this step we should have a file locally in the `remote-backend` folder as terraform.tfstate,
  a glance on the content of the file will show all the attributes of S3 bucket
  created in a JSON format. If we lose this file we in summary lose state of the
  S3 bucket.
- Configure the s3 backend by creating a file called `backend.tf` where the
  bucket name matches the bucket created in the previous steps.

```hcl
 terraform {
    backend "s3" {
        bucket       = <BUCKET-NAME>
        key          = <KEY WHERE THE STATE FILE WILL BE STORED IN S3 BUCKET>
        region       = "eu-west-1"
        use_lockfile = true
    }
}
```

- Execute terraform init. On successful execution the terraform.tfstate file will
  be copied over to the newly created s3 bucket with the local file having empty
  content.

- Change directory to the root of your infrastructure directory. create another
  `backend.tf` file. Your folder directory structure will end up looking
  like this:

  ```sh
  ├── infrastructure/
  │   ├── remote-backend/
  │   │   ├── s3.tf
  │   │   ├── backend.tf
  │   │   ├── provider.tf
  │   │   ├── variables.tf
  │   ├── main.tf
  │   ├── example-application.tf
  │   ├── provider.tf
  │   ├── variables.tf
  │   ├── backend.tf
  ```

- Ensure the bucket name is the same as the bucket created above. However, also
  ensure the key is different to the key specified in the `backend.tf` file for
  the s3 remote backend configuration.

- Execute terraform init. On successful execution an empty state file will
  be created directly in the s3 bucket with no local file. Your s3 bucket will
  now have the state files for both your s3 remote backend and your application
  infrastructure. Your application infrastructure can also be deleted without deleting
  the S3 remote backend.

- `use_lockfile=true` configured in `backend.tf` enables s3 native state locking
  which when activated creates a lock file (with a .tflock extension) alongside
  your state file in the s3 bucket. All state going forwards is stored in the
  same s3 bucket and location.
