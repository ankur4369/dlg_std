# General Standards

This page offers fundamental style and structure guidelines for Terraform
configurations. These recommendations are applicable to reusable Terraform
[modules](modulestandards) and root configurations.

## Security

When connecting to Cloud providers through Terraform, OpenID Connect should be
used and not IAM users. To see more information on this regarding Cloud
providers please see the [OIDC](./../../../../security/oidc/01-oidc.md) section.

## Code Structure

Terraform allows a lot of freedom to structure your code which can lead to
maintainability challenges. The structure of your code can mostly depend
on your use case but we recommend the following methods.

### Small Projects

With a small project with limited infrastructure components, it’s not a bad idea
to keep our Terraform configuration as simple as possible. In these cases, we
can configure only the necessary files in the root directory.

A small project would contain:

```sh
├── main.tf
├── README.md
├── providers.tf
└── variables.tf
```

- `main.tf` contains all the resources you wish to create in Cloud.
- `README.md` describes your repository and how to use it.
- `providers.tf` lists the Terraform providers used in creation of Cloud
  resources.
- `variables.tf` any variables required to parameterise your configurations.
- `*.tfvars` is an optional file to provide values for the variables. In
  Terraform Cloud these can also be saved in the workspace.

### Larger Projects

In large projects time should be taken to decide on the best way to structure
your code.

- Adopt a clear directory structure for your Terraform files. Typical patterns
  involve organising modules, environments, and configurations separately.
- Organise resources into logical groups with individual files and descriptive
  names, such as `securitygroups.tf`, `instances.tf`, or `apigw.tf`.
- Employ modules to encapsulate and reuse code, ensuring that each module is
  responsible for a specific component of the infrastructure.
- Pin your version of modules for stability, predictability, and security.
- Limit the use of internal modules in your repository. Externalise the modules
  so they can be used by other engineers in DL. For more information on
  managing modules see [Module Standards](modulestandards).

#### Environments

- Use separate Terraform workspaces with directories in your repository for
  different environments (e.g., dev, staging, production) to avoid conflicts.
- GitHub Actions workflows can use filters to determine changes in environment
  folders. See [here](https://docs.github.com/en/actions/writing-workflows/workflow-syntax-for-github-actions#using-filters).
- Do **not** use branching to manage environments. This leads to branch
  management overheads, inconsistent configuration and pipeline complications.
  All environment infrastructure should be deployed from your trunk/main branch
  and changes made through pull requests.
- Environments should have their own state and can be tested and managed
  separately, while shared behaviour is achieved with modules.

Below is a simple example structure for three different environments per
directory: production, staging, and test. Each environment has its own state
and is managed separately from the others while leveraging common or shared
modules. Although this approach comes with some code duplication, we gain
improved clarity, environment isolation, and scalability.

```sh
├── production
│   ├── main.tf
│   ├── outputs.tf
│   ├── provider.tf
│   └── variables.tf
├── staging
│   ├── main.tf
│   ├── outputs.tf
│   ├── provider.tf
│   └── variables.tf
└── test
    ├── main.tf
    ├── outputs.tf
    ├── provider.tf
    └── variables.tf
├── modules <--- remote modules are encouraged
    ├── vpc
    ├── lb
├── README.md
```

:::note
Having all environment configuration in a single directory and passing different
environment variables (e.g. `tfvars`) per environment to parameterise the
configuration is discouraged. In the example above when the correct level of
composition and modulisation is applied the configuration per environment is
very light, easy to maintain and promote change.
:::

:::tip
As a general rule, we want to define Terraform configurations with limited
scope and blast radius with specific owners. To minimize risk, we should
try to decompose our projects into small workspaces/stacks and segment
access to them using Role-based access control(RBAC).
:::

## Naming Conventions

Naming things can be difficult, but it is imperative to get this right. By
adopting our consistent and descriptive naming convention for resources it
enhances readability, maintainability, collaboration and scalability across
the organisation for infrastructure management.

Terraform objects should be named with underscores to delimit multiple words:

```hcl
resource "aws_iam_policy" "example_policy" {
}
```

Resources created in the Cloud should be named through convention:

```hcl
resource "aws_iam_policy" "example_policy" {
  name   = "<platform_code>_<account/environment>_<service/application>_<descriptor>_<suffix>"
}
```

- `platform_code` - is short prefix for the platform, e.g. home, motor, mch etc.
  - Aim for a minimum of 3 and a maximum of 6 characters.
  - Avoid numbers.
  - If the resources will endure, avoid programme names.
  - Choose a name that reflects the service provided to the business.
  - Agree the platform name with the wider project/support team and look
    or any potential issues.
- `account/environment` - either a account level name or environment,
  e.g. dev, test, staging etc.
- `service/application` - The service or application of the resource, e.g. mule,
  gwpc, carweb, hopewiser etc.
- `descriptor` - a meaningful descriptor to help identify a specific resource
  of an service or application e.g. addresslookup
- `suffix` - an optional section to add a version, or type of
  resource if several etc.
- Don't repeat the resource type in the Terraform object name or Cloud
  resource name.

:::tip
Remember in Terraform you must use the resource type before referencing the
particular instance of it. Therefore defining a resource as such:

```hcl
resource "aws_iam_policy" "my_iam_policy" { ... }
```

Then referencing as `aws_iam_policy.my_iam_policy` doesn't read well. It would
be better to write:

```hcl
resource "aws_iam_policy" "my_kms_decrypt" { ... }
```

Which you reference by `aws_iam_policy.my_kms_decrypt`.
:::

Some example Cloud resource names through convention:

```hcl
home_dev_gwpc_ui_instance
home_test_gwpc_batch_sg
motor_dev_gwpc_role
motor_production_gwpc_ws_lb
```

## Variable Management

- Declare all variables in `variables.tf`.

- Use variables for configuration values to make your code reusable and flexible.

- Always use descriptive names for variables so they are relevant to their
  usage or purpose.

- When used for conditional logic, give boolean variables positive names like
  `enable_encryption`.

- All variables should have a **[type](https://developer.hashicorp.com/terraform/language/expressions/types#types).**

- Always include a variable description.

- Use variable [validation rules](https://developer.hashicorp.com/terraform/language/values/variables#custom-validation-rules)
  where possible.

  ```hcl
  variable "my_number" {
    description = "A number greater than 10"
    type        = number

    validation {
      condition     = var.my_number > 10
      error_message = "The number must be greater than 10."
    }
  }
  ```

- Use structured/object variables where possible. Attempt to avoid all variables
  being flat.

  ```hcl
  variable "s3_lifecycle_configuration" {
    description = "Settings for s3 lifecycle configuration."
    type = object({
      force_destroy                      = bool
      expiration_days                    = number
      noncurrent_version_expiration_days = number
    })
    default = {
      force_destroy                      = false
      expiration_days                    = 90
      noncurrent_version_expiration_days = 30
    }
  }
  ```

- When appropriate, provide default values. Do **not** use variables and
  defaults to replace the purpose of `local` values in literals reused in
  multiple places. Variables are for input purposes and not for defining
  contents of lists.

- For single-value variables and attributes, use singular nouns.
  For lists or maps, use plural nouns to show that it represents multiple values.

- Keep sensitive values in GitHub repository environment secrets.

- Ensure variables which are sensitive have the correct flag set:

  ```hcl
  variable "my_sensitive_variable" {
    description = "My super sensitive variable that should not be plain text"
    type        = string
    sensitive   = true
  }
  ```

- Avoid hardcoding values directly in the configuration files; instead,
  use variables or data sources to make your code flexible.

  Example 1:

  ```hcl
  aws_account_id = ”99999999999”
  ```

  ```hcl
  data "aws_caller_identity" "current" {}
  locals {
    account_id = data.aws_caller_identity.current.account_id
  }
  ```

  Example 2:

  ```hcl
  azure_ad_tenant_id = "”99999999999”"
  ```

  ```hcl
  data "azuread_client_config" "current" {}
  locals {
    azure_ad_tenant_id = data.azuread_client_config.current.tenant_id
  }
  ```

## Outputs

- Declare all outputs in `outputs.tf`.
- Always use descriptive names for outputs so they are relevant to their
  usage or purpose.
- Always include an output description.
- If outputting a sensitive value include the `sensitive` flag.

Example:

```hcl
output "db_password" {
  value       = aws_db_instance.db.password
  description = "The password for logging in to the database."
  sensitive   = true
}
```

## Data Sources

- Place data sources next to the resources that use them.
- If the number of data sources grows significantly, consider relocating them
  to a dedicated `data.tf` file
- To retrieve data related to the current environment, utilise variable or
  resource [interpolation](https://www.terraform.io/language/expressions/strings#interpolation).

## Protect Stateful Resources

For important stateful resource such as databases ensure that the deletion
protection is enabled to protect against accidental deletion.

```hcl
resource "aws_rds_cluster_instance" "my_db" {
  lifecycle {
    prevent_destroy = true
  }
}
```

## Loops and Conditions

Your code should be able to create multiple instances of a resource whenever
possible, so a recommendation would be to use count or for_each on the ones
that may change from one environment to the other. This, combined with
conditionals, will give you the flexibility to accommodate many different
use cases with the same code and offer genericity to your parameters.

```hcl
variable "instances" {
  description = "A map of instances to create"
  type        = map(object({
    ami           = string
    instance_type = string
  }))
}

resource "aws_instance" "web" {
  for_each = var.instances

  ami           = each.value.ami
  instance_type = each.value.instance_type
  tags = {
    Name = each.key
  }
}
```

## Tagging

Tagging your resources in mandatory in DL. This offers several important
benefits:

Using tags in AWS offers several important benefits:

- They help organise and categorise our resources, making it easier to manage
  and locate them.
- We can track spending by project, department, or environment, which aids in
  cost allocation and budget management.
- Enable automation for resource management, allowing us to apply policies or
  automate tasks based on specific tags.
- Manage access permissions through Identity and Access Management (IAM),
  ensuring that users only have access to resources they need.
- Assist in compliance efforts by helping to classify resources according to
  regulatory requirements.
- Make it easier to filter and search for resources Improving operational
  efficiency.

Mandatory tags that must be set are:

```hcl
tags {
  application = ""
  business_owner = ""
  cost_centre = ""
  domain = ""
  environment = ""
  support_group = ""
  technical_owner = ""
  used_for = ""
}
```

For further details guidance on the values of these tags please [see](../general/01-tagging.md).

## State Management

- Use remote state storage (e.g. AWS S3 or Terraform Cloud) to avoid local state
  file issues and enable team collaboration.
- Enable state locking to prevent simultaneous operations that could corrupt
  your state file.
- If using a service such as AWS S3 enable versioning and backups, and ensure
  the correct IAM policies are applied.
- Local state management should only be used for experimenting.

## Manage Dependencies

Terraform cannot always automatically determine the order of resource creation.
You may find this when on a first deploy Terraform `apply` might fail, but you
run again and it works. To ensure consistency and robust pipelines use explicit
dependencies with `depends_on` where necessary to manage resource creation order.

```hcl
resource "aws_s3_bucket" "my_storage" {
  bucket = "my-bucket-name"
}

resource "aws_iam_policy" "my_storage" {
  name        = "S3AccessPolicy"
  description = "A policy to access the S3 bucket"
  policy      = ""
  depends_on = [aws_s3_bucket.my_storage]
}
```

## Community Modules

Terraform modules can be included in your configuration from a source of a
GitHub/Git repository or the Terraform Registry. Both sources contain 100s of
modules which are publicly shared and community-contributed that can help you
quickly set up and manage infrastructure on various Cloud providers.

Although in DL, only a subset of community sourced modules should be used:

- [terraform-aws-modules](https://github.com/terraform-aws-modules)
- [azure](https://github.com/Azure)

:::tip
Always pin the version of community modules when in use and review the resources
it creates before promoting change up your environments.
:::

:::tip
It should be unnecessary to create a Terraform module at the Cloud resource level
in DL most are available from the approved community sources and are frequently
kept up to date with providers.
:::

:::warning
Do not include module sources outside of what is approved. When a new module
is required, the module should be grouping of resources which provide a
shareable capability/pattern to others in DL. E.g. a module that supports
API Gateway with an OpenAPI spec backed by serverless compute like AWS Lambda.

When creating shareable modules please follow this [guide](modulestandards).

If you wish to add a new source of Terraform modules outside of DL please
consult with Engineering and your CISO contact first. Once approved our list
can be updated by raising a Pull Request to this handbook.
:::

## Secrets Management

Do not store secrets in plain text and ***NEVER*** commit them in your repository.
Ensure you use a tool like `pre-commit` and [Yelp](https://github.com/Yelp/detect-secrets)
to protect yourself against accidentally adding them.

Store your secrets into your GitHub repositories or/and your Cloud providers
service such as Secrets Manager in AWS.

## Unmanaged Cloud Resources

You may inherit infrastructure which is not controlled by Terraform making it
difficult change and reference in new/existing code. The good news is that
you can use an `import` block in Terraform see [here](https://developer.hashicorp.com/terraform/language/import)
to bring it under your control. It is recommended to add a `import.tf` file and
then use the resource type. Once imported you also have the option to remove it
as its now referenced and in your state. E.g.

```hcl
import {
  to = aws_instance.my_server  <--- you can remove this once imported!
  id = "i-abcde12345"
}

resource "aws_instance" "my_server" {
  name = "my-server"
  # (other resource arguments...)
}
```

With the recommend approach of folder segregation of [environments](#environments)
it then makes it much easier to import per environment.

## Documentation

Document the Terraform code and architecture clearly. Use comments within your
code and maintain a README for configurations.

## CI/CD

### Linting and Formatting

- Use Terraform `fmt` to format your code and Terraform `validate` to check for
  errors. [VS Code](#ide-plugins) has extension which can help
  with format while you code too!
- Terraform has several useful tools to ensure best practices are followed in
  language itself and the Cloud providers you use. See the tools [section](./../../../04-Tooling/01-tooling.md#terraform)
  for what we use.

:::tip
Several reusable workflows using these tools are available [here](https://github.com/Direct-Line-Group/engprod-reusable-workflows)
which can be part of your pipeline checks.
:::

### CI Pipeline Example

```mermaid
graph LR
    direction LR
    pr([Open PR])
    fmt([TF fmt])
    validate([TF validate])
    lint([tflint])
    checkov([checkov])
    trivy([trivy])
    plan([TF Plan])

    pr --> fmt
    fmt --> validate
    validate --> lint
    lint --> checkov
    checkov --> trivy
    trivy --> plan
```

### CD Pipeline Example

```mermaid
graph LR
    direction LR
    pr([PR approved])
    merge([PR merged])
    plan([TF Plan])
    apply([TF Apply])
    test([Test])

    pr --> merge
    merge --> plan
    plan --> apply
    apply --> test
```

## IDE Plugins

- [HashiCorp VS Code Extension](https://marketplace.visualstudio.com/items?itemName=HashiCorp.terraform)
- [Trivy VS Code Extension](https://marketplace.visualstudio.com/items?itemName=AquaSecurityOfficial.trivy-vulnerability-scanner)
