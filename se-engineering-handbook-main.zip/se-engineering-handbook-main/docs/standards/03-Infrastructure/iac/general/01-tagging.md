# Tagging

## Coming Soon

Whether you are in Azure or AWS, use CloudFormation or Terraform tagging is a
critical part of your Cloud Resources.

For the meantime please see the FinOps [page](https://directline.atlassian.net/wiki/spaces/CTT/pages/13334315186)
in Confluence.
