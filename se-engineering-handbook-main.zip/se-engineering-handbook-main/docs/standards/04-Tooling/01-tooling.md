# Tooling

Using code scanners, linters, and similar tools during the development process
offers several benefits that can greatly improve the quality,
maintainability, and efficiency of our code in DL.

The tools automate various checks and processes, helping us avoid common
pitfalls, catch errors early, and enforce best practices.

In this page its lists the tools we current use in DL for:

- Catching syntax and style errors early.
- Enforcing consistency and code standards.
- Identifying potential bugs and vulnerabilities.
- Improving code quality and maintainability.
- Automating repetitive checks.
- Enhancing collaboration and onboarding.
- Improving engineer productivity.
- Supporting code reviews and collaboration.

:::info
When introducing new open-source tools into DL [this](./02-opensource.md)
process can be followed. Once complete please ensure the tables are updated.
:::

## Tools

## Version Control System (VCS)

| Tool Name | Description                                                                                                                                                                                          |
| --------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| GitHub    | In DL, GitHub is the preferred git based system for version control, collaboration, and software development. For more information see the [GitHub](./../../newprojects/github/01-repos.md) section. |
| Bitbucket | Green Flag approved git based version control for its existing services. Any new services should be developed on GitHub.                                                                             |
| SVN       | Approved only for legacy services which are mostly on premise. Any new services should be developed on GitHub.                                                                                       |

When using git we recommend using [pre-commit](#pre-commit) to ensure compliance
and good practices before adding your code.

## pre-commit

[pre-commit](https://github.com/pre-commit/pre-commit) is a tool to help
identify simple issues before submission to code review. Several hooks can be
run on every commit to automatically point out issues in the code before code review
saving time.

Below is a table of recommend hooks.

| Repo                                                                         | Hooks                                                                                                                                                                                                                                                        |
| ---------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| [pre-commit-hooks](https://github.com/pre-commit/pre-commit-hooks)           | check-merge-conflict<br/>check-yaml<br/>check-json detect-private-key<br/>trailing-whitespace<br/><br/>These hooks check for merge conflicts, YAML/JSON formats, unnecessary whitespace and private keys. Several others are available, please see the docs. |
| [markdownlint-cli2](https://github.com/DavidAnson/markdownlint-cli2)         | markdownlint-cli2 - A fast, flexible, configuration-based command-line interface for linting Markdown/CommonMark.                                                                                                                                            |
| [mdformat](https://github.com/executablebooks/mdformat)                      | mdformat - Opinionated Markdown formatter that can be used to enforce a consistent style in Markdown files.                                                                                                                                                  |
| [actionlint](https://github.com/rhysd/actionlint)                            | actionlint - A static checker for GitHub Actions workflow files.                                                                                                                                                                                             |
| [check-jsonschema](https://github.com/python-jsonschema/check-jsonschema)    | check-github-workflows - A JSON schema linter for GitHub workflows.                                                                                                                                                                                          |
| [git-leaks](https://github.com/gitleaks/gitleaks)                            | gitleaks - A plugin for detecting secrets within a code base.                                                                                                                                                                                                |
| [pre-commit-terraform](https://github.com/antonbabenko/pre-commit-terraform) | terraform_fmt - Terraform format check<br/>terraform_tflint - module inspection<br/>terraform_trivy - complete security and compliance checks using Trivy                                                                                                    |

## CI/CD

| Tool Name                                                                       | Description                                                                                                                          |
| ------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| [GitHub Actions](https://github.com/features/actions)                           | In DL, Actions is the preferred tool for automating workflows for building, testing, and deploying code held in GitHub repositories. |
| [AWS CodeBuild](https://aws.amazon.com/codebuild/)                              | Fully managed build service that compiles source code, runs tests, and produces deployable artifacts in AWS.                         |
| [AWS CodePipeline](https://aws.amazon.com/codepipeline/)                        | A fully managed continuous delivery service that automates the build, test, and deploy phases for fast and reliable updates in AWS   |
| [Azure Pipelines](https://azure.microsoft.com/en-us/services/devops/pipelines/) | Part of Azure DevOps, it automates building, testing, and deploying code in Azure.                                                   |

## Linting

| Tool Name                                                    | Description                                                                                                                                                                  |
| ------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [tflint](https://github.com/terraform-linters/tflint)        | Linter for Terraform code that helps identify potential issues and enforce best practices.                                                                                   |
| [SonarLint](https://www.sonarsource.com/products/sonarlint/) | Linter to highlight potential problems during development. Example installation for [VS Code](https://docs.sonarsource.com/sonarlint/vs-code/getting-started/installation/). |
| [Spectral](https://stoplight.io/open-source/spectral)        | A flexible JSON/YAML linter and validator used to enforce rules on OpenAPI/Swagger specifications and other structured data.                                                 |
| [OpenAPI Tools](https://github.com/openapitools)             | Tools include SDK generation from a given OpenAPI spec file. See [OpenAPI Generator](https://github.com/OpenAPITools/openapi-generator).                                     |

## Security and Compliance

| Tool Name                                           | Description                                                                                                                                                                                                                                                    |
| --------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [SonarQube](https://sonarcloud.io)                  | Analyse and measure the quality of code, identifying issues such as bugs, vulnerabilities, code smells, and adherence to coding standards. For more information see the [SonarQube](./../../newprojects/sonarqube/01-sonar.md) section.                        |
| [JFrog](https://directline.jfrog.io/ui/packages)    | Artifact management and continuous integration/continuous deployment (CI/CD) with security and vulnerability scanning for detecting issues in dependencies and artifacts. For more information see the [JFrog](./../../newprojects/jfrog/01-jfrog.md) section. |
| [checkov](https://github.com/bridgecrewio/checkov/) | Static analysis tool for Terraform that scans your code for security and compliance issues.                                                                                                                                                                    |
| [trivy](https://github.com/aquasecurity/trivy)      | A vulnerability scanner for containers and other artifacts. It can be used to scan Terraform code for potential security vulnerabilities.                                                                                                                      |

## IDEs & Code Editors

| Tool Name                                  | Description                                                                                                                      |
| ------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------- |
| [VS Code](https://code.visualstudio.com)   | Lightweight IDE developed by MS.                                                                                                 |
| [IntelliJ](https://www.jetbrains.com/idea) | IDE primarily used for Java development, although it supports many other programming languages and technologies through plugins. |
| [Eclipse](https://eclipseide.org/)         | A free, open-source, extensible development environment primarily for Java but supporting many languages through plugins.        |

## Command Line Interfaces (CLI)

| Tool Name                                                                       | Description                                                                               |
| ------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| [AWS CLI](https://aws.amazon.com/cli/)                                          | Control multiple AWS services from the command line and automate them through scripts.    |
| [Azure CLI](https://learn.microsoft.com/en-us/cli/azure/?view=azure-cli-latest) | Control multiple Azure services from the command line and automate them through scripts.  |
| [Podman ClI](https://podman.io/)                                                | Daemon-less container management tool designed to handle containers and container images. |
| [GitHub CLI](https://cli.github.com/)                                           | Bring GitHub to your terminal.                                                            |

## Build & Dependency Management

| Tool Name                               | Description                                                                                        |
| --------------------------------------- | -------------------------------------------------------------------------------------------------- |
| [Maven](https://maven.apache.org/)      | A build automation and dependency management tool for Java projects.                               |
| [Gradle](https://gradle.org/)           | A flexible build automation tool for Java and other languages with powerful dependency management. |
| [npm](https://www.npmjs.com/)           | The default package manager used with node projects.                                               |
| [yarn](https://classic.yarnpkg.com/en/) | A package manager used with node projects.                                                         |
| [pip](https://pip.pypa.io)              | The standard package installer for Python, used to install packages from PyPI.                     |
| [Docker](https://www.docker.com/)       | Build, run applications inside lightweight, portable containers.                                   |
| [Helm](https://helm.sh/)                | Package manager for Kubernetes                                                                     |

## Testing & QA

| Tool Name | Description |
| --------- | ----------- |
| TBD       | TBD         |

## Infrastructure As Code (IaC)

| Tool Name                                               | Description                                                                                                                                        |
| ------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Terraform](https://www.terraform.io)                   | The preferred Infrastructure as Code (IaC) tool in DL which lets you define, provision, and manage infrastructure across multiple cloud providers. |
| [CloudFormation](https://aws.amazon.com/cloudformation) | An AWS service that lets you model, provision, and manage AWS resources using Infrastructure as Code templates.                                    |
| [Ansible](https://www.ansible.com/)                     | IT automation engine that automates provisioning, configuration management, application deployment etc.                                            |
