# Introducing an Open-source Tool

When evaluating and integrating a new open-source tool it's important to have a
structured process to ensure that the tool is safe, reliable, and well-suited
to our needs. Below is a step-by-step guide with guardrails to follow.

:::warning
This not an official process for introduction tooling into DL. It is only a
guide and not all section may be applicable for open-source tools within
engineering. Please ensure the tools are updated [here](./01-tooling.md).
:::

## 1. Clearly articulate why you need the tool and what problem it solves

- Identify the problem or gap in your current tools or processes.
- Gather input from key stakeholders (e.g. engineering, security,
  operations, legal).
- Define success criteria for the tool's effectiveness.

Guardrails:

- Ensure the need aligns with the company’s long-term technical strategy
  and vision.
- Avoid “shiny object syndrome”, do not adopt tools based on novelty or
  hype alone.

## 2. Assess whether the open-source tool fits our technical and business needs

- Functionality: Does the tool solve the problem identified?
  Does it meet the performance and scalability requirements?
- Community Health: Assess the tool’s community size, activity,
  and engagement (e.g. regular commits, active issue resolutions,
  community forums).
- Licensing: Review the open-source license (e.g. MIT, GPL, Apache) to
  ensure it is compatible with our legal and business requirements.
- Documentation: Is the tool well-documented? Does it have clear setup
  instructions, usage guides, and troubleshooting information?
- Security: Conduct a security audit to check for vulnerabilities.
  Verify that the tool is regularly updated and that security patches are
  actively managed.
- Dependencies: Identify the dependencies of the tool and ensure they align
  with the company’s existing tech stack and security policies.
- Integration: Evaluate how easily the tool integrates with your current
  systems (e.g., CI/CD pipelines, databases, cloud infrastructure).

Guardrails:

- Only use tools with an active and thriving community. Avoid tools with
  sparse documentation or stagnant development.
- Be cautious of tools that introduce complex, unmanageable dependencies
  that may complicate maintenance.
- Ensure the tool doesn’t conflict with the company’s security standards
  or internal policies.

## 3. Test the tool in a controlled environment to validate its suitability

- Set up a small-scale pilot/poc to evaluate the tool’s real-world
  functionality and performance.
- Involve a limited group of stakeholders to test the tool and provide
  feedback.
- Document any issues or challenges that arise during the trial period.

Guardrails:

- Avoid full deployment until the tool has passed the PoC phase.
- Ensure there is a rollback plan in case the tool doesn't meet
  expectations during the pilot.

## 4. Ensure that introducing the tool does not introduce undue risk to the organisation

- Security Review: Perform a deep dive into the tool’s security posture
  (e.g. code reviews, vulnerability assessments, and third-party security audits).
- Compliance Check: Verify the tool’s compliance with relevant regulations
  (e.g. GDPR, HIPAA, SOC2) and ensure the licensing is compatible with your
  business model (e.g. commercial use, redistribution).
- Long-term Viability: Assess whether the tool is likely to be maintained in
  the future. Tools without active maintainers can introduce technical debt.
- Legal Review: Have the legal team review the license if not familiar to
  ensure it doesn’t expose the company to unanticipated liabilities.

Guardrails:

- Only use open source tools that are widely accepted and have a strong
  reputation for security and compliance.
- Ensure there is a documented, repeatable process for monitoring ongoing
  updates and security patches for open source tools.

## 5. Successfully integrate the tool into company's workflows

- Integration: Integrate the tool into your existing architecture (e.g.
  APIs, microservices, databases). Follow best practices for configuration
  and scaling.
- Automation: Automate deployments and updates (e.g., using CI/CD pipelines,
  configuration management tools).
- Onboarding: Provide training or documentation for your team on how to use
  the tool. Ensure that there is sufficient support available.
- Monitoring: Set up monitoring for performance and security, especially
  for any critical systems that rely on the tool.

Guardrails:

- Ensure that proper change management processes are followed to avoid
  system disruption during implementation.
- Avoid implementing the tool in a way that locks you into an unmanageable
  or fragile dependency.

## 6. Ensure the tool remains effective, secure, and up to date over time

- Regularly monitor the tool’s performance and usage.
- Keep track of updates and new releases from the tool’s maintainers.
  Apply security patches as needed.
- If your tool is used within a GitHub repository, enable [Dependabot](../../newprojects/github/01-repos.md#dependabot)
  .
- If the tool has a significant issue, explore alternatives or contribute to
  the open-source project (if possible).
- Track any evolving compliance requirements and re-assess the tool if necessary.

Guardrails:

- Set up a regular cadence for reviewing and updating open source tools.
- Implement a system to quickly deprecate or replace a tool if it no
  longer meets the organization’s needs.

## 7. Engage with the open source community to give back and ensure long-term sustainability

- Contribute by raising issues if found and new feature requests.
- Encourage internal teams to participate in the community.

Guardrails:

- Be cautious of contributing in a way that conflicts with the company's
  intellectual property or public-facing stance.
- Ensure contributions are aligned with the company’s legal and compliance
  policies.

:::warning
Before engaging with an open-source tool community where you plan to contribute
by adding code, please consult your Security representative first.
:::
