# Guidewire PCF Best Practices

## 1.Page configuration best practices

### 1.1) Modify base PCF files whenever possible

Modify the base configuration files wherever they can be modified. Create new
files only when absolutely necessary

### 1.2) Add a suffix to new PCF files to avoid name conflicts

Every page configuration file in your PolicyCenter instance must have a unique
file name. The location of page configuration files within the folder structure
of page configuration resources does not ensure uniqueness. To avoid future
naming conflicts when Guidewire adds or changes base page configurations, append
the suffix `_Dlg` to the names of your page configuration files. For example,
name a new list view for contacts on a policy PolicyContacts_DlgLV.

`Note : use suffix _Ext for HVCP`

### 1.3) Avoid using Gosu code in PCF files

Avoid including large blocks of Gosu code within the `<Code>` element in PCF
files for the following reasons:

`Code in a particular PCF file is not reusable`

`You cannot debug code that is defined in a PCF file`

`Large amounts of code can complicate merging of PCF files during an upgrade`

`GUNITs cannot be created for code contained within them`

Review all relevant files and refactor the code, moving it to enhancement or
service classes in the appropriate gsrc folder.

## 2.Display keys best Practices

A display key represents a single piece of user-viewable text. A display key
comprises:

`A name to use in PCF files and Gosu code, where you want to display textual`
`information`

`A text value to display in place of the name, for each locale installed in`
`your application instance`

As a best practice, Guidewire recommends that you edit your display key
definitions by using the Display Keys editor in Guidewire Studio.

### 2.1) Use display keys to display text

Define display keys for any text that you display to users through the
application user interface or in log messages. Do not use hard-coded String
literals. Display keys help you localize your configuration of application with
translations for specific languages.

### 2.2) Use existing display keys whenever possible

Before you create a new display key, search the existing display keys to find
one with the text that you want. In Guidewire Studio, open the
display_localeCode.properties file for the language you are using. Then, type
the word or phrase you want. The Display Keys editor navigates to and highlights
display keys that contain the text or phrase in their names or values.

### 2.3) Observe display key naming conventions

Generally, display key names begin with a capital letter. Internal
capitalization separates words in compound display key names.

For example:`ContactDetail`

PolicyCenter represents display keys in a hierarchical name space. A period (.)
separates display key names in the paths of the display key hierarchy.

For example:`Validation.Contact.ContactDetail`

Generally, you specify text values for display key names that are leaves on the
display keys resource tree. Generally, you do not specify text values for
display key names that are parts of the path to a leaf display key. In the
preceding example, the display keys Validation and Validation.Contact have no
text values, because they are parts of a display key path. The display key
ContactDetail has a text value, “Contact Detail”, because it is a leaf display
key with no child display keys beyond it.

### 2.4) Add a suffix to new display keys to avoid name conflicts

To avoid future naming conflicts when Guidewire adds or changes base display
keys, append the suffix `_Dlg` to your new display key names. For example, your
PolicyCenter instance has a branch of the display key hierarchy for text that
relates to contact validation.

```gosu
Validation.Contact.ContactDetail
Validation.Contact.NewContact
```

You want to add a display key for the text “Delete Contact”. Add a new display
key named DeleteContact_Dlg.

```gosu
Validation.Contact.ContactDetail
Validation.Contact.DeleteContact_Dlg
Validation.Contact.NewContact
```

You can change the text for base display keys to change the text that the base
configuration of the application displays. Guidewire recommends that you use the
base configuration display keys for this purpose so the base configuration PCF
files can just make use of the new values. If you add display keys with the
suffix `_Dlg` with the intention of using them in the base configuration, the
base configuration PCF files must be altered to use them.

`Note : use suffix _Ext for HVCP`

### 2.5) Organize display keys by page configuration component

Guidewire recommends that you organize display keys under paths specific to the
page configuration component types and PCF file names where the text values of
display keys appears. For example, `LV.Activity.Activities.DueDate`

## 3. User interface performance best practices

The ways in which you configure the user interface of your PolicyCenter instance
affects its performance. As performance best practices for user interface
configuration, Guidewire recommends that you always do the following:

`“Avoid repeated calculations of expensive widget values”`

`“Avoid expensive calculations of widget properties”`

`“Use application permission keys for visibility and editability”`

### 3.1) Avoid repeated calculations of expensive widget values

As a performance best practice, Guidewire recommends that you avoid repeated
evaluation of performance intensive expressions for widget values. Depending on
the needs of your application, performance intensive expressions may be
unavoidable. However, you can improve overall performance of a page by choosing
carefully where to specify the expression within the page configuration.

For example, the following value range expression has a performance problem.
Evaluation of the expression requires two foreign key traversals and one array
lookup. If the PolicyPeriod instance is not cached, PolicyCenter executes three
relational database queries, which makes the evaluation even more expensive.

```gosu
RangeInput
...
valueRange |policyPeriod.Policy.Product.AllowedPolicyTerms
```

If a page with this range input widget has any postOnChange fields, PolicyCenter
potentially evaluates the expression multiple times for each postOnChange edit
that a user makes.

The following topics provide additional suggestions for handling expensive
expressions:

#### • “Use page variables for expensive value expressions”

#### • “Use recalculate on refresh with expensive page variables cautiously”

#### Use page variables for expensive value expressions

Instead of specifying an expensive expression as the value for a widget, create
a page variable and specify the expensive expression as the initial value. Then,
specify the page variable as the value for the widget. Page variables are
evaluated only during the construction of the page, not during the remaining
lifetime of the page, regardless of postOnChange edits.

The following example suffers a performance problem, because it assigns an
expensive expression to the value property of a widget.

```gosu
Input: myInput
...
value |someExpensiveMethod()
```

The following modified sample code improves performance. It assigns a
performance intensive expression to a page variable and assigns the variable to
the widget value.

```gosu
Variables
...
initialValue |someExpensiveMethod()
name         |expensiveResult
 --------------------------------
Input: myInput
...
value        |expensiveResult
```

#### Use recalculate on refresh with expensive page variables cautiously

PolicyCenter evaluates page variables only during the construction of the page,
but sometimes you want PolicyCenter to evaluate a page variable in response to
postOnChange edits. If so, you set the recalculateOnRefresh property of the page
variable to true. If a page variable specifies an expensive expression for its
initialValue, carefully consider whether your page really must recalculate the
variable. If you set the recalculateOnRefresh property to true, PolicyCenter
evaluates the expression at least once for every postOnChange edit to the page.

Although PolicyCenter evaluates page variable with recalculateOnRefresh set to
true for each postOnChange edit, page variables can yield performance
improvements compared to widget values. If several widgets use the same
expression for their values, using a page variable reduces the number of
evaluations by a factor equal to the number widgets that use it. For example,
the valueRange of a range input used for drop-down lists in a list view column
are evaluated at least once for each row.

### 3.2) Avoid expensive calculations of widget properties

Page configuration widget properties editable, visible, available, and required,
may need to be evaluated in multiple contexts. If you have a complex or
expensive expression in one of these properties, move the expression to a page
variable. Otherwise, the expression is evaluated several times before
PolicyCenter displays the page.

The following example suffers a performance problem. It assigns a performance
intensive expression to the visible property of a widget.

```gosu
Input: myInput
...
id      |myInput
...
visible |activity.someExpensiveMethod()
```

The following modified sample code improves performance. It assigns a
performance intensive expression to a page variable. PolicyCenter evaluates page
variables only once before it displays a page, regardless how many contexts
under which it evaluates widget properties on the page.

```gosu
Variables
...
initialValue |activity.someExpensiveMethod()
name         |expensiveResult
 --------------------------------
Input: myInput
...
id           |myInput
...
visible      |expensiveResult
```

### 3.3) Use application permission keys for visibility and editability

The visible and editable properties are evaluated many times during the
lifetimes of locations and widgets. As a performance best practice, Guidewire
recommends that you structure the page configuration of your user interface so
application permission keys determine visibility and editability. This is the
most common pattern for user access in business applications.

For example, use the following Gosu expression in the visible property of a
Renew button on a panel that displays information about a policy period:

`perm.PolicyPeriod.renew(aPolicy)`

Application permission keys evaluate the current user against general system
permissions and the access control lists of specific entity instances.

## 4. PCFs with Method Calls for Property Evaluation

Generally, page or widget attributes (such as editable, visible, available,
etc.) should not involve method calls. If the intention is for a method's return
value to represent the attribute's value, a page-level variable should be
assigned the method call, and the attribute should simply reference this
variable. This approach is preferred because variables are evaluated only once,
whereas attributes may be evaluated multiple times. Teams should examine all
such PCF attributes and eliminate any method calls in favor of using page-level
variables.

## 5. Targets for PostOnChange Should Be Defined

It’s important to define targets for every postOnChange event. Setting the
target to DATA_ONLY can enhance performance. This allows you to specify whether
to refresh the entire page (
if no target is specified) or just a specific container.

Target definition from studio : An optional page update scope. If not specified,
the entire page will be refreshed upon post. If "DATA_ONLY" is specified, only
the page data will be refreshed without any layout change, which is the most
performing configuration. the data refresh applies to Input data and data rows
under ListViewPanels. If a widget target is specified, all the page data and the
entire layout of the target widget will be refreshed.

## 6.Review PCF Files with Excessive Inline Code

Having inline code exceeding 500 characters in PCFs suggests poor design and
potential future performance issues. It's important to review and refactor this
code by externalizing it into Gosu APIs, making it reusable and easier to debug.

## 7.Changes to Existing PCFs

If a PCF file has extensively modified the base file(generally when changes
exceed about 20%)a copy of the PCF should be created to incorporate the changes,
while the original file should be reverted. This approach helps mitigate
potential merge conflicts during upgrades, whether they are point releases or
major versions.

## 8. Using QueryAPI in a PCF

When a Gosu query is needed in a PCF (such as a ListView or any other type),
always consider writing the query as a method in the PCF Helper class and
calling it from the required PCF. This approach improves unit testing of the PCF
and enhances the reusability of the original query.

Directly writing the query as a variable in the PCF or as a value in the widget
will hinder unit testing and make debugging the query more difficult.

## 9. Use of Empty Loop Body

Problem Examples

Empty Loop Body with No Action:

```gosu
function createActivityOnEligiblePolicyPeriods(policyPeriods: PolicyPeriod[]) {
for (pp in policyPeriods) {
if (not pp.Canceled
and pp.SelectedPaymentPlan.PaymentPlanType == PaymentMethod.TC_INSTALLMENTS) {
//createActivity(pp)
}
}
}
```

Empty Loop Body with Inverse Condition:

```gosu
function getNonAcctHolderDrivers(drivers: AccountContact[]): AccountContact[] {
  var accts = new ArrayList<AccountContact>()
  for (driver in drivers) {
    if (driver.Roles.hasMatch(\p -> p.Subtype == TC_ACCOUNTHOLDER
        or p.Subtype == AccountContactRole.TC_NAMEDINSURED)) {
    } else {
      accts.add(driver)
    }
  }
  return accts.toTypedArray()
}
```

Resolving the Problem

To address empty logical blocks, remove them entirely. If any code within the
block was commented out, comment out the entire logical block as well if it's
necessary to retain it. Additionally, rewrite the code for clarity, especially
when dealing with inverse conditions.
