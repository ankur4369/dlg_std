# Guidewire Entities Best Practices

## 1. Table names should be the same as their entity's name

When table names are not the same as their entities it becomes
very difficult to identify which entity it refers to,
therefore, it is recommended to have the table property of an entity
equal to it's name.

### Hint : Table names should be the same as their entity's name

Change the table property in entities to be the same as the entity's name.
Due to the database limitations, table names in the entity declaration
cannot exceed 25 characters.
If the name of the entity is longer, create a table name corresponding
to the entity name, shortcutting some part of the name,
e.g. by removing vowels.

## 2.Entity must not use database reserved words

Database model entities are prohibited from utilising any
database reserved words from a respective database system
which either is or is going to be used for the
purpose of data storage.
Naming an entity or its member is going to prohibit database
system from properly creating physical database model
structure due to the aforesaid.

### Hints on how to prevent issues: Entity must not use database reserved words

Do not name any entity or its members with any reserved word
from a respective database system.

## 3.Entity file name extension should have lowercase letters only

To improve the readability of the project structure and ensure there are
no problems when running the application in different environments,
it is recommended to have all entity (.eti)and entity extension (.etx)
file extensions comprised of only lowercase letters

## 4. Entity description property should be present

Entity description property should be present
and should not be similar to file or property name.
The purpose of the 'desc' property in an entity or entity column is to provide
a descriptive business meaning to it.
If left empty or filled with irrelevant information,this purpose is defeated.

### Hints on how to prevent issues : Entity description property should be present

Always provide a 'desc' property to entities and entity columns and
fill it with real business meaning.
Avoid using abbreviations (like "desc", "description" or "foo")
or copying the 'name' property.

## 5. Empty property in entity

Properties in entities have their default value as empty string,
declaring them as empty string brings no value and is redundant,
therefore, these properties should be removed.

### Hints on how to prevent or address issues : Empty property in entity

Add a value to an entity property or remove it.

### Noncompliant Code Example 5

column
columnName=""
default="false"
desc="Has W-9 form been received"
name="W9Received"
nullok="true"
type="bit"...

#### Compliant Solution 5

column
default="false"
desc="Has W-9 form been received"
name="W9Received"
nullok="true"
type="bit"

## 6. Occurrence of triggersValidation=true property in entity

Setting the triggersValidation attribute to true ensures
that the Center runs
the pre-update and validation rules on the linked object
any time that it is modified.
However, this is only true if the container object implements
the Validatable delegate.
Therefore, it is important to ensure that this delegate
is implemented
in this Entity, its supertype, or in the Entity it extends.
Also keep in mind that validation is a resource-heavy operation
and should only be performed when absolutely necessary, otherwise,
it is possible to run into performance issues.

### Hints : Avoid Occurrence of triggersValidation=true

If validation is necessary for a given element, it should implement
the Validatable delegate.
Otherwise, remove the triggersValidation attribute.

#### Noncompliant Code Example 6

foreignkey
columnName="QueueID"
desc="The specified queue to assign the activity to"
fkentity="AssignableQueue"
name="Queue"
nullok="true"
triggersValidation="true"

##### Compliant Solution 6

##### If validation is NOT necessary

foreignkey
columnName="QueueID"
desc="The specified queue to assign the activity to"
fkentity="AssignableQueue"
name="Queue"
nullok="true"

##### If validation is necessary

foreignkey
columnName="QueueID"
desc="The specified queue to assign the activity to"
fkentity="AssignableQueue"
name="Queue"
nullok="true"
triggersValidation="true"
implementsEntity
name="Validatable"

## 7. Entity file name should end with required suffix -\_Ext

To avoid conflicts during future upgrades, a suffix should be used to mark
custom entities and entity columns.
Add \_Ext for Surepath cloud standards to the end of entity
names or entity field names

### Compliant Example 7

extension entityName="Policy" column desc="Description of the column"
name="MyCustomColumn_Ext"
nullok="true"
default="abc"
type="varchar"
columnParam
name="size"
value="60"
column
typekey desc="Description of the typekey"
name="MyCustomTypekey_Ext"
typelist="myCustomTypeList_Ext)"
nullok="true"

## 8. Entities and entity extensions must be created in modules/configuration/extensions/entity

Entities and entity extensions must be created in
modules/configuration/extensions/entity even for custom entities.

## 9. Use singular words for field names except for arrays

Guidewire recommends that you name most fields with a singular word
such as Phone or Age. However, because array fields reference
a list of objects,
Guidewire recommends that you name them with a plural word.

For example, Policy.CurrentRoleAssignment and Policy.CorePolicyNumber
are single fields on a Policy entity,
but Policy.RiskNotes is an array of multiple notes.
Also, for arrays fields that are extensions,
make the primary name plural and not the Ext prefix
or suffix.
For example, use Ext_MedTreatments or MedTreatments_Ext,
and not MedTreatment_Exts.

## 10. Add ID as a suffix to column names for foreign keys

Guidewire recommends that you add ID as a suffix to
the column names of foreign keys.
By default, the column name of foreign keys have
the same name as the foreign key names.
Use the columnName attribute of foreignkey elements
to override their default column names.

### Example 10.1

foreignkey
columnName="PolicyID"
name="Policy"

Adding the suffix ID to the column names of foreign keys
helps database administrators
identify columns in the
database that Guidewire uses as foreign keys.
If you add a foreign key
as an extension to a base entity,
follow the best practice of adding a prefix or suffix to the name.

### Example 10.2

foreignkey
columnName="Policy_ExtID"
name="Policy_Ext"

## 11. Other data model best practices

The following are additional recommendations when
extending the data model:

• Always add an informative description for all
new entities, properties, typelists, and typecodes.

• Use the defined text data types
(for example, shorttext, mediumtext, and longtext)
instead of varchar. You may choose to use varchar
if a fixed width is known from
or required by an external system.
