# Typelist Best Practices

A typelist represents a set of allowed values for specific fields on entities in
the data model. A typecode represents an individual value within a typelist. A
typecode comprises:

• A code that the database stores as a column value • A name that the user
interface displays • A priority setting that drop-down lists use to order
typecode names that got displayed

## Typelist Naming Conventions

The components of a typelist have the following naming conventions:

```gosu
-------------------------------------------------------------------
Typelist       Naming                                Example
Component      Conventions
-------------------------------------------------------------------
Typelist       Mixed case, with the first letter
               uppercase, and with the first letter ActivityCategory
               of each internal word capitalized
-------------------------------------------------------------------
Code           Only lowercase letters,Underscores(_)
               separate words                       approval_pending
--------------------------------------------------------------------
Name           Each word in a name begins with a
               capital letter. Spaces separate words. Approval Pending
---------------------------------------------------------------------
```

## Add a Suffix to New Typelists and Typecode Extensions

To avoid future naming conflicts when Guidewire adds or changes base typelists
and typecodes, Guidewire recommends that you append the suffix \_Ext to your
typelist names and typecode codes. As an example of new typelists, name one that
represents types of medical procedures MedicalProcedureType_Ext. Name the
typecodes in your new typelists without the suffix \_Ext. As an example of new
typecodes in a base typelist, the following AddressType typelist has a new
typecode for service entrances.

```gosu
Code                 Name               Description     Priority Retired
--------             -------            -----------     -------- -------
billing              Billing            Billing          -1      false
business             Business           Business         -1      false
home                 Home               Home             -1      false
other                Other              Other            -1      false
service_entrance_Ext Service Entrance   Service Entrance -1      false
```

## Do Not Rely on Implicit Conversion of Typecodes to String

Guidewire recommends that you do not send typecodes as arguments to display
keys, but explicitly send the Name properties of typekey
