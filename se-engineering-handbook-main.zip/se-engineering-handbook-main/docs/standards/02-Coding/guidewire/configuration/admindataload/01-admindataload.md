# Admin Data Load Best Practices

## 1. Do not use SQL commands directly to modify the operational database tables

## 2. Maintain data integrity during administrative data import

Some of the administrative data have dependencies
on business roles.
For example, PolicyCenter associates roles with groups. Therefore,
if you export administrative data from one system into another,
you must also export all PolicyCenter roles from the old system
and import the roles into the new system.

### Procedure

- Export the PolicyCenter roles.
- Export the administrative data.
- Import the roles into the new system.
- Import the administrative data into the new system.

## 3. Do not duplicate public id for import data when updating them files

Use unique public ids.

## 4. Be careful never to pass too much, data in any custom import API

If you must import data in other formats or export
administrative data programmatically,
write a new web service to export administrative information one record at a time.
For both import and export, if you write your own web service,
be careful never to pass too much data across the network in any API call.
If you send too much data, memory errors can occur.
Do not try to import or export all administrative data in a dataset at once.
