# Gosu Queries

## Use Comparison Methods to Filter Queries

The relational database that supports Guidewire application filters the results
of a query much more efficiently than your own Gosu code, because it avoids
loading unnecessary data into the application server. As a performance best
practice,Guidewire recommends that you filter your queries with comparisons
methods rather than filter the results with your own code.

## Use Comparison Methods Instead of the Where Method

As a performance best practice, Guidewire recommends that you always use
comparison methods on query objects made with the query builder APIs. Never
convert a query builder result object to a collection and then use the where
method on the collection to specify the criteria for the query result. Guidewire
applications applies comparison methods whenever a query executes, and the
database returns only qualifying entity instances to the application. Without
any comparison methods, converting a query result to a collection loads all
instances of the primary entity type into the application cache. The where
method on the collection then creates a second collection with the qualifying
instances.

## Use Count properties on Query Builder Results and Find Queries

As a performance best practice, Guidewire recommends that you obtain counts of
items fetched from the application database by using the Count properties on
query builder result objects.Do not iterate result or query objects to obtain a
count.

## Use Empty properties If You Want to Know Whether Anything Was Found

If you want to know only whether a result or query object fetched anything from
the application database, use the Empty property instead of the Count property.
The value of the Empty property returns to your Gosu code faster, because the
evaluation stops as soon as it counts at least one fetched item. In contrast,
the value of the Count property returns to your Gosu only after counting all
fetched items.

## Avoid find expressions

Guidewire recommends the query builder APIs instead of find expressions to fetch
items from the application database whenever possible, especially for new code.

## Identifying changes that may require Index addition

In instances when you are using APIs to query the database, you should be aware
that you may need to add an index to a column in order for the query to perform
optimally. Particularly be aware that when using Query.make() you should examine
if an index needs to be added After adding/changing/deleting indexes regression
test to ensure optimal overall performance.

## Converting Result Objects to Lists, Arrays, Collections, and Sets

Beans are cached when they are evaluated by the iterator. When toCollection()
methods are called, you force evaluation of the entire result set forcing the
beans into cache. Do this only if you are absolutely certain that the result set
size and the size of the objects are small. Otherwise, you risk flooding the
cache in unintended ways and possibly running out of memory.

## Reporting databases

SQL queries run outside the application should be run in a replica or copy of
the application database, rather than the application database itself. For
applications such as data warehouses and intensive reporting, explore mechanisms
for replicating or summarizing data into a production reporting database for
this purpose. This practice can prevent unexpected production performance issues
due to intensive reporting requirements or "runaway queries"

Example : In DL, DataMart feeds, Qlik reports, Fircosoft queries running on
mirror Databases for Billing Data.

## Chunking and pre-fetch result counts

Chunking allows a sampling of rows and allows setting a threshold limit for
result sets. Checking the result counts before fetching the results is another
way of preventing excessive rows from being returned

```gosu
// -- chunking --
var chunkSize = 10 // -- get a sampling of 10 rows --
var result = Query.make(Claim).select()
result.setPageSize(chunkSize)
var limitedResult = com.google.common.collect.Iterables.limit(result, chunkSize)
limitedResult.each(\c -> print(c))
```
