# Enhancement

## Enhancements with code that only supports screen operations

Do not place Gosu code in entity enhancements if the only purpose of the code is
to support screen operation, and it does not truly form part of the domain
object. This pollutes the interface of the domain object with methods and
properties that are only useful on a small set of PCF pages. In these cases, use
a UI helper class instead.

## Extending Existing Entities

The suffix `_Dlg` must be added for “virtual” properties and functions added via
entity enhancements.

`Note : use suffix _Ext for HVCP`

## Enhancement package

Follow proper package structure while adding new enhancement classes. All-new
enhancements should be placed within the `dlg.<cc/pc/bc>.config.enahancements`
folder structure.

Even if you are enhancing a built-in type, if at all possible use your own "dlg"
package for the enhancement class itself.

## OOTB Enhancement shouldn’t contain new methods

To facilitate upgrades, enhancements that are central to the base operating
software, such as gw.policy.PolicyPeriodBaseEnhancement, should only include
modifications to the existing base methods. These enhancements should not
introduce new methods. New methods should be added in a separate custom
enhancement class under the dlg package.

This rule generally applies to classes within the `gw.*` package and to any
enhancements with "BaseEnhancement" in the class name.

## Do not overload a single enhancement

Do not overload a single enhancement class. Define multiple enhancements for a
single entity where required based on business scenarios. Also, avoid large
enhancements.

The below example shows multiple enhancements for the same entity (PolicyPeriod)
structured based on different business flow.

`PolicyPeriodAprEnhancement_Dlg.gsx and PolicyPeriodChargeEnhancement_Dlg.`

Simple package structures also help to encapsulate the behaviours of
functionality.
`Note : use suffix _Ext for HVCP`

## Enhancement function names

Enhancements help keep the code simple and readable. While defining enhancement
properties or functions, define an explicit name for the property which tells
you in short what the property is validating or what the function is
implementing.

## Recommend Enhancements where appropriate

First, always prioritize using properties, as they reduce the need for
parameters and parentheses, leading to cleaner and more maintainable code. When
enhancement properties are not suitable (i.e., for business logic that doesn’t
fit the getter/setter pattern), define functions within the appropriate
structured enhancement class according to your business flow. Avoid using
utility classes to define these functions whenever possible.

As long as a function is related to a specific entity, it should be placed in
the relevant enhancement class rather than a utility class.

Defining functions within enhancements eliminates the need for static function
definitions in utility classes. Utility classes should only be used for business
logic that is not tied to any specific entity.
