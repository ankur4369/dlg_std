# Workflows

## 1. When to create a new workflow version

Guidewire recommends, as a general rule, that you create a new workflow version
under most circumstances if you modify a workflow. For example:

`• If you add a new step to the workflow, then create a new workflow version.`

`• If you remove an existing step from the workflow, then create a new workflow`
`version.`

`• If you change the step type, such as from Manual to an automatic step type,`
`then create a new workflow version.`

The primary purpose of the version number is to allow two (or more) versions of
a workflow type to execute simultaneously. This is usually needed when a
workflow process needs to be changed, but there are active or errored out
workflow instances that need to continue using the original version.

If you do modify a workflow, be aware that:

`• If you convert a manual step to an automatic step, it can cause issues for`
`an active workflow.`

`• If you reduce a timeout value, any active workflows that have already hit`
`that step will only wait the previously calculated time.`

It is acceptable to modify an existing workflow process (instead of creating one
with a new version number), when the change will not cause problems for any
in-progress workflow instances. The more specific answer is either when there
are no in-progress instances, or when the change is simple enough that it won't
affect any in-progress instances, or when it's a development system and there is
no consequence to upsetting the execution of in-progress instances.

Important:
If there is an active workflow on a particular step, do not alter that step
without versioning the workflow.

## 2. Starting a workflow instance

start workflow instance only if there is no workflow is progress. So, implement
a check to see if there is a relevant workflow instance already in progress. If
there is no relevant workflow in progress:

1. Create a new workflow object using the appropriate subtype.
1. Assign the context objects to the new workflow object.
1. Start the workflow(wf.start()).

## 3. Workflow name should end with required suffix `_Dlg`

To avoid conflicts during future upgrades, a suffix `_Dlg` should be used to
mark custom Workflows.

`Note : use suffix _Ext for HVCP`

## 4. Start a workflow from a PCF element

To start a workflow from a PCF element, you need to commit the action after the
code to start the workflow. Without the commit, the action is never performed.

```gosu
CurrentLocation.commit()
```

## 5. Current time in a Time Absolute expression

Do not use the current time in a Time Absolute expression. Time Absolute is
re-evaluated each time the workflow engine checks the timeout. An expression
such as `gw.api.util.DateUtil.addDays(Libraries.Date.currentDate(), 1)` will
never be reached, because today will never be tomorrow.

## 6. InvokeTrigger with typecodes by their internal names

The below method references the typecode by its internal name.

```gosu
this.invokeTrigger(typekey.WorkflowTriggerKey.TC_EXITDELINQUENCY)
```

The below method references the typecode by its localized name.

```gosu
this.invokeTrigger("ExitDelinquency")
```

If a given typecode is configured for only one locale, the two methods are
identical. However, if a typecode is configured for multiple locales, then code
references to the localized name can have unpredictable behavior. The
WorkflowTriggerKey typelist is used only by developers, so it is unlikely that
localization would ever pose a problem. However, the general best practice is to
reference all typecodes by their internal names.
