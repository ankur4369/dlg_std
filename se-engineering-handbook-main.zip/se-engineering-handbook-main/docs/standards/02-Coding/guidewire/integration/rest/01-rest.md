# (DRAFT/DEMO) REST Standards Template

REST standards for integration of systems utilising Guidewire.

## Applicability

|       | Guidewire 9 | Guidewire 10 |
| ----- | ----------- | ------------ |
| Home  |             |              |
| Motor |             |              |

## DL Guidelines/Standards

### Documenting APIs (Swagger)

### API Method/Verb Guidance

### API Versioning

## Guidewire Defined Standards/Documentation

*Reference to Guidewire documentation and standard - link and section
reference.*
