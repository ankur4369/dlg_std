# Introduction

Throughout this section you will find specific areas of technology for coding
standards. Each area has a review owner with SME's allocated for changes made to
the area - you don't need to do anything special to get a review; the
[CODEOWNERS](https://github.com/Direct-Line-Group/se-engineering-handbook/blob/main/.github/CODEOWNERS)
file will automatically allocate the correct people for review when you submit
your Pull Request.
