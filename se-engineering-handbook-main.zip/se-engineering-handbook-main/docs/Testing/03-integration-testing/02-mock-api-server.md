# Introduction

A mock server in integration testing is a simulated server that mimics the
behavior of a real server. It is used to test the interactions between
different components of an application without relying on the actual external
services.
This helps in isolating the tests and making them more reliable and faster.

## Key Benefits

- **Isolation**: Tests can be run without depending on external services.
- **Speed**: Faster than using real services.
- **Control**: Can simulate various scenarios, including edge cases and error
  conditions.

## DL's Mock server strategy

DL engineering elected Wiremock as the tool of choice for creating mock
servers. Wiremock is a flexible and easy-to-use, it can run on a Docker image,
locally as a java process or even embedded into your unit tests.

Wiremock can return stubbed responses for remote API calls based on attributes
in their payloads, as well as proxy the requests to the actual API, allowing
developers to test their code without having to always rely on the actual real
service.

```mermaid
flowchart LR
A("Policy Center v9") --> B("Billing Center Mock Server") & D("Mule Mock Server")
A --> G("Service X Mock Server")
B --> C("Biling Center v9")
D --> E("Mule v3") & F("Mule v4")
G --> H("Service X")
```

## How to use Wiremock in DL

Using the
[Github repo template](https://github.com/Direct-Line-Group/se-proxying-mock-service-template),
create a new repository for your mock server by using the name of the original
API you are mocking and adding '-mocks.
For instance, for an api on a repository called
['b4c-motor-sys-dataplatform-barring-api'](https://github.com/Direct-Line-Group/b4c-motor-sys-dataplatform-barring-api)
we create a repository
['b4c-motor-sys-dataplatform-barring-api-mocks'](https://github.com/Direct-Line-Group/b4c-motor-sys-dataplatform-barring-api-mocks)

Mocks examples will be kept close to the API as they are meant to be maintained
by API producers. A directory called
`wiremock` will be created in the root of the api repository to store `examples`
and `templates` directories with request & response examples and response
templates, respectively.

On the mocks repository, create a git submodule. e.g.
`git submodule add https://github.com/Direct-Line-Group/b4c-motor-sys-dataplatform-barring-api`

This creates a link between the mock repository and the original API, as well
as allows to keep examples and templates updated.

### About Mappings

The `mappings` directory contains the mappings files that define the responses
that Wiremock will return based on the request it receives. Each mapping file
is a JSON file that contains the request and response details.

In the template repository, you will notice that most requests to the Lexis
Nexis /webservices/web_service_incoming_request.php endpoint, which is stubbed
on this service, return a canned XML response.

However, Wiremock passes any request that does not contain the Vehicle
Registration Numbers (VRNs) specified in the mappings file to the actual Lexis
Nexis UAT system.

This allows us to run most tests against IHP without having a dependency on the
real Lexis Nexis UAT system or its test data but also allows us to run tests
with certain VRNs that will actually hit Lexis Nexis and test the integration
for real.

### Mocking responses

This example on the template mocks a response when vehicleRegistration = NCD002
see file `mappings/lexis-nexis.json`, lines 3~24

The response body is contained in lexis-nexis-response.xml.

The values for 'ncd' in line 20 and the value for 'attractScore' in line 21 of
the mappings file are filled in the placeholders `{{parameters.ncd}}` and
`{{parameters.attractScore}}` at the body file.

While this example mocks a response when vehicleRegistration= ATT3699
see file `mappings/lexis-nexis.json`, lines L25-L46.

The response body is contained in lexis-nexis-response.xml.

The values for 'attractScoreDriver1' and 'attractScoreDriver3' fill the
placeholders in the body file.

Note that 'attractScoreDriver2' on file
`__files/lexis-nexis-response-three-drivers-attract-score.xml` line 142
returns a random value between 0 and 999 -
[read more about random values](https://docs.wiremock.io/response-templating/random-values/)

There is no theoretical limit to the number of mappings that can be created,
but it is recommended to keep the mappings to a number that won't overload the
service. This number will be dependant on the size of the container instance
you're running the service on.

### Proxying to the actual service

This example proxies the requests to Lexis Nexis UAT environment, see file
`mappings/lexis-nexis.json`, lines 48~L58.

For more details on [stubbing](https://wiremock.org/docs/stubbing/) and
[proxying](https://wiremock.org/docs/proxying/) with Wiremock, please refer to
the official documentation.

## Building the docker image

Prerequisites:
Before you start, ensure you have Docker or Podman installed on your system.

Before building the docker image, you need to download the latest the
wiremock-standalone JAR file from the maven repository.
Find the latest version at
[Maven repository](https://mvnrepository.com/artifact/org.wiremock/wiremock-standalone)
and download it to the project's root folder.

For example, replace the URL with the URL from the latest version in the Maven
repository.
Ensure that ARTIFACTORY_USER and ARTIFACTORY_PASSWORD are set in your
environment.

```shell
curl --fail-with-body -L -v -u $ARTIFACTORY_USER:$ARTIFACTORY_PASSWORD https://directline.jfrog.io/artifactory/maven-central-cache/org/wiremock/wiremock-standalone/3.0.1/wiremock-standalone-3.0.1.jar --output wiremock-standalone.jar
```

Open a terminal and navigate to the root folder of your project where the
Dockerfile is located.

Run the following command to build the Docker image:

`docker build -t barring-api-mocks .`

Alternatively, if you are using Podman, run:

`podman build -t barring-api-mocks .`

### How To Run Locally

Prerequisites:

1. Checkout the Repository
1. Clone the repository to your local machine using the following command:

`git clone https://github.com/Direct-Line-Group/b4c-motor-sys-dataplatform-barring-api-mocks.git`

1. Navigate to the cloned repository's directory

`cd b4c-motor-sys-dataplatform-barring-api-mocks`

1. Initialize and Update Git Submodule

In the example `b4c-motor-sys-dataplatform-barring-api` is a git submodule that
contains base Wiremock templates for the Barring API. It should be initialized
and updated after checking out the repository. Run the following commands in
your project's root folder:

```shell
git submodule init
git submodule update
```

1. Download WireMock

Visit the
[Maven repository](https://mvnrepository.com/artifact/org.wiremock/wiremock-standalone)
to find the latest version of the WireMock standalone JAR file.

Download the latest version to your project's root folder. For example, replace
the URL with the URL from the latest version in the Maven repository. Ensure
that ARTIFACTORY_USER and ARTIFACTORY_PASSWORD are set in your environment.

```shell
curl --fail-with-body -L -v -u $ARTIFACTORY_USER:$ARTIFACTORY_PASSWORD https://directline.jfrog.io/artifactory/maven-central-cache/org/wiremock/wiremock-standalone/3.9.2/wiremock-standalone-3.9.2.jar --output wiremock-standalone.jar
```

### Running with Docker

Run the Docker container using the following command:

`docker run -p 8080:8080 barring-api-mocks`

Alternatively, if you are using Podman, run:

`podman run -p 8080:8080 barring-api-mocks`

To run on a port different from 8080, alter the -p argument. For example, to
use host port 8090, run:

`docker run -p 8090:8080 barring-api-mocks`

WireMock will be accessible at [localhost:8090](http://localhost:8090) on the
above example.

### Running from a .jar File

Recording showing how to setup project and run locally without Docker:
[run-from-jar.mp4](https://directlinegroup-my.sharepoint.com/personal/bnkm_directlinegroup_co_uk/_layouts/15/stream.aspx?id=%2Fpersonal%2Fbnkm%5Fdirectlinegroup%5Fco%5Fuk%2FDocuments%2Frun%2Dfrom%2Djar%2Emp4&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0=&ga=1)

On the root of your project, copy the main API WireMock templates:

For MacOS/Linux:
`cp ./b4c-motor-sys-dataplatform-barring-api/wiremock/templates/*.* ./__files/`

For Windows (PowerShell):

```shell
Copy-Item -Path  .\b4c-motor-sys-dataplatform-barring-api\wiremock\templates\*.* -Destination .\__files\
```

Open a terminal and navigate to the root folder of your project where the
wiremock-standalone.jar file is located.

Run the following command to start WireMock:
`java -jar ./wiremock-standalone.jar --verbose --local-response-templating`

WireMock will be accessible at [localhost:8080](http://localhost:8080).

To make WireMock listen on a port different from 8080, use the --port argument.
For example, to use port 8090, run:

```shell
java -jar ./wiremock-standalone.jar --verbose --local-response-templating --port 8090
```

WireMock will then be accessible at [localhost:8090](http://localhost:8090).
