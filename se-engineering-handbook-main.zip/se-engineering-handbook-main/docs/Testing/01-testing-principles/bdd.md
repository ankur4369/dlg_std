# Behaviour-Driven Development (BDD)

BDD is a way for software teams to work that closes the gap between business
people and technical people by:

- Encouraging collaboration across roles to build shared understanding of the
  problem to be solved
- Working in rapid, small iterations to increase feedback and the flow of value
- Producing system documentation that is automatically checked against the
  system’s behaviour

We do this by focusing collaborative work around concrete, real-world examples
that illustrate how we want the system to behave. We use those examples to guide
us from concept through to implementation, in a process of continuous
collaboration. See [Behaviour-Driven Development](https://cucumber.io/docs/bdd/).

This page is focused on the construction of BDD in our code projects rather than
the formulation part.

## General Guidelines

1. Readability is key in a feature file. This applies to feature and scenario
   naming as well as to the feature text itself.

   - Make sure the name of the feature reflects the scenarios covered and reads well.
   - Make sure each scenario title is specific enough and detailed enough to give
     an idea of its purpose.

1. Use capital letters correctly for product or other proper names.

1. Use simple, definite, present tense language:

   - Use “she/he edits” instead of “she/he is editing”
   - Use “the value is” instead of “the value should be”

1. Once you have written your ‘Given/When/Then’ details, read it back and consider:

   - Have I used the correct prefix (Given, When or Then)? This is really important
     to enable someone new to the scenario to understand what it is actually testing.
     - The ‘Given’ should be the steps a user would do in order to get to the point
       where the test is initiated
     - The ‘When’ is the ‘trigger’ - this is the user action that is key to the
       test scenario in terms of what we are testing
     - The ‘Then‘ - is the ‘what are we expecting to happen.’ We should not be performing
       any actions in the Then statement. It should only contain validations.
   - Often we have to use ‘And’ lines in order to have multiples of one or more of
     the above - this is fine, but try to minimise where possible.
   - After you have written your scenario, read it back with each of the above in
     mind, and make sure you are not mixing up ‘When’s with ‘Then’s etc.

1. If you read the scenario back, and it includes an ‘and’ in the middle of the
   sentence, then this is often a clue that the step should in fact be two steps:

   ```gherkin
   When he navigates to the Account screen and searches for account 123
   ```

   Should be:

   ```gherkin
   When he navigates to the Account screen
   And searches for account 123
   ```

1. Always consider step re-usability/parameterisation. If you are referring to a
   screen, person, account etc. in your step, then probably there is another scenario
   where that entity will change, but otherwise the intent of the step is the same.

1. Feature files should describe the intent of a user\\scenario,
   **not the UI implementation detail** - so try not to refer to buttons or other
   controls - instead favour language that would make sense to someone even if they
   could not view the UI . e.g. instead of

   ```gherkin
   She selects yes in the 'Do you need to tell us more information about this issue?' question
   ```

   Should be:

   ```gherkin
   She elects to add more information about the issue
   ```

1. Always remember, the feature file should describe in enough detail what the
   differences in a scenario are - e.g. If you have multiple scenarios that are variations
   in a theme, you need to make it explicit what the difference is in each feature
   text - **you cannot hide these important key differences in the step
   definition code, it should be clear from the feature text**. For example, if you
   have many scenarios that fill out a form but with one response differing in order
   to test different error messages, then it is not enough to say:

   ```gherkin
   When she fills out the Account form answering all questions
   Then the error code ABC123 is shown
   ```

   - If you do this then every scenario will read the same apart from the error code,
     and hence someone reading it back will have no understanding of why that code
     was shown.
   - Also consider that the error code is not really helpful for a human reader,
     instead favour parameterising the error message So below would be better:

   ```gherkin
   When he fills out the Account form answering all questions
   And he answers that his date of birth is 01/01/1820
   Then the error 'Covered party must be aged 99 or less for this policy' is shown
   ```

1. We should not be writing long scenarios clubbing multiple behaviours in one scenario,
   adding lots of step-by-step instructions with actions and expected results.
   This makes the scenarios long, which can delay failure investigation, increase
   maintenance cost, and create confusion. One example is here:

   Given-When-Then steps must appear in order and should not repeat. In Gherkin,
   one scenario should cover one behaviour following the behaviour driven mindset.
   Anytime you want to write more than one When-Then pair, write separate scenarios
   instead or form the scenario such that Given-When-Then steps appear in order.
   There should not be any new When-Then pairs following a Then statement.
   This is the general rule, however if the scenario flows and is readable and
   there is a warrant for doing a pair of actions then attempt to write the scenario
   but have it reviewed and agreed.

1. Avoid overly generic step definitions. As a general practice, when authoring
   a new step, particularly one with parameterisation in it, consider whether the
   step makes some sense in isolation from the steps around it. Consider the step
   below:

```gherkin
And he selects the <addon>
```

We should avoid steps that are worded this generically. The issue is that in
the future, when using IDE completion, there is no information that
`"he selects the {string}"` has anything to do with the quote page or addons
specifically. So there needs to be some additional context provided — e.g.,
`"he selects the addon"` or `"he selects the quote addon"` — as you feel
appropriate (since we tend to avoid saying "on the x page" for every step).

## Combining Multiple Scenarios

If you find yourself writing more or less the same scenario multiple times, stop
and think about whether some of them can be parameterised and combined. This often
becomes obvious when you are working though authoring the automation for these,
and is related to reusing step definitions, but also should be considered where
one scenario logically follows on from all the steps of the previous one - you
need consider “if I just added a second check (Then line) onto the end of this
scenario then do the benefits outweigh the costs?” (in terms of readability, tests
being modular, run time of running all the features in pipelines etc.) it’s
not an exact science, but needs to be considered.

## Parameters in Examples

1. Readability of your step after you substitute in the parameter is key (e.g.
   it’s how the text will be shown in any reports), so be sure to try substituting
   the values yourself and see if the sentence still makes sense:

   - e.g. if we have an Example where ‘policy type’ is a parameter, which has
     values of ‘active’ ‘inactive’. If you have `"Then he chooses a <policy type>"`,
     when this is expanded it reads like `"Then he chooses a active"`, which
     doesn’t make any sense.
   - So choose wording that describes the parameter as well e.g.
     `"Then he chooses an <policy type> policy"`, which then reads like:
     `"Then he chooses an active policy"`

1. Review the parameters in the ‘Examples’ section once you have written them.
   If you have three examples and each one of these sets the value of a parameter
   to ‘6’, then it does not need to be in the Example - instead it should be in the
   line of the scenario where the parameter is used. e.g. Instead of

   ```gherkin
   Then the value of goods should be <value of goods> pounds

   Examples:
   | brand       | value of goods |
   |-------------|----------------|
   | Direct Line | 6              |
   | Churchill   | 6              |
   ```

   Use:

   ```gherkin
   Then the value of goods should be 6 pounds
   ```
