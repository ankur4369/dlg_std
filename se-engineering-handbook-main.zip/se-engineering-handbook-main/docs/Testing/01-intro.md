# Introduction

## Purpose of this Handbook

This serves as a guide for software testing teams across different
engineering groups. It provides best practices, testing strategies,
and frameworks to ensure high-quality software delivery.

## Who Should Use This Handbook

Anyone looking to conduct any type of testing

## Testing Principles & Guidelines

- [General Testing Principles](01-testing-principles/01-general-testing-principles.md)
- [Shift-Left Testing Approach](01-testing-principles/02-shift-left-testing-approach.md)

## Testing Types & Strategies

- [Unit Testing](02-testing-types-and-strategies/01-unit-testing.md)
- [Integration Testing](02-testing-types-and-strategies/02-integration-testing.md)
- [System Testing](02-testing-types-and-strategies/03-system-testing.md)
- [Performance Testing](02-testing-types-and-strategies/04-performance-testing.md)
- [Regression Testing](02-testing-types-and-strategies/05-regression-testing.md)
- [A/B Testing](02-testing-types-and-strategies/06-ab-testing.md)

## Best Practices for Different Engineering Teams

- [Backend Testing Approach](03-best-practices/01-backend-testing-approach.md)
- [Frontend Testing Approach](03-best-practices/02-frontend-testing-approach.md)
- [Mobile App Testing Approach](03-best-practices/03-mobile-app-testing-approach.md)
- [Data Analytics Testing Approach](03-best-practices/04-data-analytics-testing-approach.md)

## Test Automation Frameworks & Tools

- [Unit Testing](04-test-automation-frameworks-and-tools/01-unit-testing.md)
- [API Testing](04-test-automation-frameworks-and-tools/02-api-testing.md)
- [UI Testing](04-test-automation-frameworks-and-tools/03-ui-testing.md)
- [Performance Testing](04-test-automation-frameworks-and-tools/04-performance-testing.md)
- [Security Testing](04-test-automation-frameworks-and-tools/05-security-testing.md)
- [Compatibility Testing](04-test-automation-frameworks-and-tools/06-compatibility-testing.md)
- [Accessibility Testing](04-test-automation-frameworks-and-tools/07-accessibility-testing.md)
- [Static Testing](04-test-automation-frameworks-and-tools/08-static-testing.md)
- [CI/CD Integration](04-test-automation-frameworks-and-tools/09-ci-cd-integration.md)

## Quality Metrics & Reporting

- [Defect & Bug Tracking](05-quality-metrics-and-reporting/01-defect-bug-tracking.md)
- [Code Coverage](05-quality-metrics-and-reporting/02-code-coverage.md)
- [Test Effectiveness](05-quality-metrics-and-reporting/03-test-effectiveness.md)

## Collaboration & Documentation

- [Test Case Management](06-collaboration-and-documentation/01-test-case-management.md)
- [Working with Product Teams](06-collaboration-and-documentation/02-working-with-product-teams.md)
- [Working with DevOps Teams](06-collaboration-and-documentation/03-working-with-devops-teams.md)

## Continuous Learning & Improvement

- [Trainings and Workshops](07-continuous-learning-and-improvement/01-trainings-and-workshops.md)
- [Lessons Learnt and Improvements](07-continuous-learning-and-improvement/02-lessons-learnt-and-improvements.md)

## Maintained by the SDET Community

_Last Updated: [25-March-2025]_
