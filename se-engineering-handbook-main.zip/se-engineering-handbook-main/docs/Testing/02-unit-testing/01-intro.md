# Introduction

Unit test is the first level of automated testing an engineer adds to their
code.

It is the practice of testing small pieces of code, typically individual
functions/methods, alone and isolated from the rest of the codebase.
The goal of unit testing is to validate that each unit of the software performs
as expected.

According to research from NIST and IBM, the cost of fixing defects are up 100X
greater in production. So finding bugs early in the development process is
extremely cost effective.

```mermaid
xychart-beta
    title "Cost of Defects"
    x-axis ["Requirements", "Design/Architecture", "Coding", "Testing", "Production"]
    y-axis "Cost" 1 --> 100
    bar [1, 3, 7, 15, 100]
```

## TDD - Test Driven Development

Test-driven development (TDD) is a software development process that relies on
writing tests before writing the actual code. It is a practice that has been
promoted by Kent Beck, the creator of the Extreme Programming methodology and
it's adopted by many software engineers.

## BDD - Behaviour Driven Development

Behaviour-driven development (BDD) is an extension of TDD that makes use of
natural language to describe the behaviour of the software. It is a practice
that has been promoted by Dan North and it's adopted by many software engineers.

BDD follows a pattern of writing tests that describe the behaviour of the
software, rather than the implementation details. This is done by using keywords
such as `Given`, `When`, and `Then` to describe the behaviour of the software.

## Benefits of Unit Testing

- Less time performing manual functional tests: The more automation, the less
  manual testing is needed.
- Defects detection and prevention: Regression defects are avoided, and the
  code is more reliable. Gaps in the requirements are detected early, especially
  non-functional requirements.
- Living documentation of the code: The tests are a form of documentation that
  describes the behaviour of the code.
- Less coupled code: The code is more modular and less coupled, which makes it
  easier to test.
- Easier refactoring: Code that is difficult to test is a prime candidate for
  refactoring. The tests will ensure that the refactoring doesn't break the
  code.
- Confidence in the code: The tests give confidence that the code works as
  intended.
- Coding with confidence: The tests give confidence that an engineer's changes
  are safe and won't break the code.

## Characteristics of a good unit test

Simple, Fast, Independent and Repeatable.

- Simple: Unit tests should be simple and easy to understand. They should test
  one
  thing at a time. This "one thing" is usually a single method or function.
- Fast: Unit tests should provide fast feedback, running in milliseconds.
- Independent: Unit tests should be independent of each other. They should not
  rely
  external resources or other tests.
- Repeatable: Unit tests should be repeatable in any environment and should
  produce
  the same results every time they are run.

[For reflection - The way of Testivus](99-testivus.md)
