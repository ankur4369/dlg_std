# Introduction

This section provides three potential branching strategies which are recommended
at DL. They have differing levels of maturity and the higher level strategies
correlate with a simpler model for management as well as the ability to provide
higher levels of release cadence and as a result delivery of features to
customers allowing your project to iterate at a higher frequency.

The structure includes a 🥇 🥈 🥉 set of adoption levels to help demonstrate the
additional capabilities brought from these branching strategies.

Use these when creating a new project and selecting a branching strategy that's
right for your technology stack and structure.

Additionally, if you are an existing project - consider which level of maturity
you are currently at and what it would take to adopt a higher level.

:::tip

Don't forget to have a read of the [Common
Techniques](/docs/category/common-techniques) section which provides further
guidance regardless of your specific branching strategy selection.

![branch](assets/robin-branch.gif "Happy Branching!")
:::
