# Pull Requests

Pull Requests allow other developers to review changes destined for their target
branch. It's an important part of the SDLC process and facilitates a number of
activities:

## Overview of the Change

The Pull Request itself should start with the completion of a [Pull Request
Template](https://docs.github.com/en/communities/using-templates-to-encourage-useful-issues-and-pull-requests/creating-a-pull-request-template-for-your-repository).
This should allow you to clearly describe your change for the benefit of others,
this should already have been configured at a repository level as per
[here](/docs/newprojects/github/repos#branches).

## Static Code Analysis

[Sonar](/docs/newprojects/sonarqube/01-sonar.md) is the current Static Code Analysis
tool-set selected for use within DL. As part of a PR being raised the Sonar
analysis should automatically run - this configuration for the app should be
tied to a Quality Gate which will automatically block the PR should it not meet
the minimum standards required.

## Peer Review

Colleagues with relevant experience of the technology stack should:

- validate your code
- ensure it meets the Acceptance Criteria
- adheres to coding standards
- identifies any anti-patterns or security issues
- ensure the readability of the code is to a good standard
- confirm there are no PII/PCI risks/concerns
- ensure the code meets DL's
  [ISMR/TSS](<https://directlinegroup.sharepoint.com/sites/CyberSecurityAcademy/SitePages/Information-Security-Mandatory-Requirements-(ISMRs)-%26-Technical-Security-Standards-(TSSs).aspx>)
  requirements

:::tip Who should review?
A technique for ensuring your review is conducted by
those that have relevant experience is to make use of a
[CODEOWNERS](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners)
file. See the [handbook documentation for GitHub
repos](/docs/newprojects/github/repos#codeowners) for further information.

This will ensure an SME has at least reviewed the code but should not prevent
others from giving their opinions/views.
:::

## Unit Test Execution

Unit Tests should provide full coverage of the technical correctness of your
code and for a specific component. All unit tests should be executed before a
Pull Request can be merged - only if Unit Tests pass can the Pull Request be
accepted for merging.

Additionally, the output of the Unit Tests will provide a Code Coverage report
indicating how well the Unit Tests have covered the code base as a whole
including the coverage of testing in branching logic. Sonar helps to enforce the
minimum standard expected from code coverage.
[Sonar](/docs/newprojects/sonarqube/01-sonar.md) will enforce this.
