# Feature Branches

Feature branches are your go to mechanism for making any and all changes to
code.

The trunk (no matter which branching strategy is used) should not be committed
to directly under any circumstances beyond initial repo creation.

## Branch Naming

There are three kinds of branch prefixes that are valid:

- feature
- bugfix
- hotfix (relevant only to GitFlow and GitHub Flow)
- release (for [Git
  Flow](/docs/sdlc/02-branching-strategies/03-gitflow/01-overview.md) and
  [GitHub
  Flow](/docs//sdlc//02-branching-strategies/02-github-flow-planned-release/01-overview.md))

Any branches created should start with these names as a prefix.

When naming these branches they should be structured as follows:

- `feature|bugfix|hotfix/PROJMGMTID-human-readable-description-of-change`

The `PROJMGMTID` above should reference the identifier for the ticket under
development. This allows clear audit and trail back to the purpose and history
for this change.

The final section of the branch name should provide a human readable overview of
the change, most project management tools will generate this for you i.e. Jira.

![jira-branch-name](../assets/jira-branch-gen.png "Generating Branch Names from
Jira")

### Jira Autolinks

You can also enable
[autolinks](https://community.atlassian.com/t5/Jira-articles/Autolink-references-in-GitHub/ba-p/1898857)
in GitHub to directly take you to the relevant Jira ID.

## Pull Requests

The mechanism for this feature branch to be merged into the trunk - see the [PR
section](02-pull-requests.md) for further info.

## Branch Completion

Once you have merged your branch to its destination you should ensure the branch
is deleted - GitHub will do this for you automatically if you enable [delete
head branches](/docs/newprojects/github/01-repos.md#branches).
