# Versioning

A well defined versioning strategy ensures there is clear governance and
traceability on the build of applications and their usage across environments
including production.

## SemVer (Semantic Versioning)

[Semver](https://semver.org) provides a mechanism for not only clearly defining
how an application can be versioned to differentiate artifact releases from each
other, but also a means and way of describing concisely how the behaviour of
your software might affect others that may consume it.

The documentation is comprehensive but as a quick cheat sheet the version should
be defined as `MAJOR.MINOR.PATCH` i.e. `1.0.0`.

| Keyword | Description                                                                                     |
| ------- | ----------------------------------------------------------------------------------------------- |
| `MAJOR` | When a major breaking change is made that is not backwards compatible                           |
| `MINOR` | When new functionality and capabilities are introduced that are backwards compatible            |
| `PATCH` | When applying bugfixes only - these introduce no new functionality but are backwards compatible |

Even if your system does not produce API's this is still a great way of
providing a structure for documenting how your application is versioned in a
clear and easy to understand way.

When using semver consider making use of the version naming strategy to drive
how to handle that change. For example if a PATCH was made to the codebase then
this should be a non-impacting change which can be applied in an automated
fashion with standard changes and fewer reviews/sign offs that may be required
for a MINOR change for example.
