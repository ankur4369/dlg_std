# Hotfixes

A hotfix is a technique to provide a fix for a given release already live in
Production; resolving a high priority incident as deemed a priority by the
business. It is generally not possible to simply release the trunk again as this
will also include any new features being worked on / aligned for the `n+1`
release. As a result this technique allows the existing release to be patched
without the danger of allowing new features in.

In the case of GitFlow this should be addressed by creating a `hotfix` branch
(see [here](../04-common/01-feature-branch.md) for guidance on naming). This is
taken as a base from the `main` branch - the same PR process should be followed
for PR review, and the patch version of the application should be incremented
i.e. if using semver `1.0.0` -> `1.0.1`.

It is also important in GitFlow to ensure that this hotfix is also cherry-picked
and merged back into the develop branch. If this step is not followed then there
is a risk the fix will be effectively reverted in the next release i.e. `n+1`.

```mermaid
gitGraph
   commit
   commit tag: "v1.0.0"
   branch develop order: 2
   branch feature1 order: 3
   commit
   checkout develop
   branch feature2 order: 4
   commit
   checkout develop
   merge feature2
   checkout main
   branch hotfix/v1.0.0 order: 1
   commit
   checkout main
   merge hotfix/v1.0.0 tag: "v1.0.1"
   checkout develop
   merge main
   checkout develop
   merge feature1
   branch release/v1.1.0 order: 5
   commit tag: "v1.1.0"
   checkout main
   merge release/v1.1.0 tag: "v1.1.0"
   checkout develop
   commit
```
