# Handling Releases

When creating a release the code from the `develop` branch should be 'cut'. This
will take any and all commits currently in the develop branch at this point and
take a snapshot of the code base and history at this time - a release branch is
then created based from this.

This release branch should be viewed as final in terms of scope/changes and only
in exceptional circumstances should changes be made.

The Release Candidate built here should be immutable and the target of a
release.

## Patching a Release Candidate

If a release candidate needs to be changed - a new artifact should be built and
the original unchanged. This ensures there is clarity on testing, removes the
ambiguity on artifact versioning, and avoids the accidental deployment of the
erroneous release candidate due to clear segregation of naming.

This naming can be managed in a couple of different ways - in particular where
using [semver](https://semver.org) - there are a couple of techniques for
managing this:

1. As your versioning strategy follows the `MAJOR.MINOR.PATCH` philosophy -
   simply increase the `PATCH` element of the version number i.e. `1.0.0` -->
   `1.0.1` - this is the simplest management mechanism
1. Utilise a more complex pre-release tag i.e. `1.0.0-alpha` which then gets
   'promoted' to remove the pre-release tag to become the final version i.e.
   `1.0.0` - this requires careful management of artifacts and governance around
   artifact management including clarity and tracking on the pre-release tag
   that was tested/signed off

## Post Release Activity

After completing a release the release branch should be merged into the main
branch. This ensures the main branch represents what is currently present in
production.
