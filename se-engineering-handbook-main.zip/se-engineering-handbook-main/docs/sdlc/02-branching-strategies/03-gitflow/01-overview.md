# Overview

GitFlow provides a mechanism for more highly managed and traditional SDLC
processes. This can be useful for more legacy technology stacks/COTS products,
or in some cases where features cannot be easily isolated using other techniques
such as branch by abstraction or feature flagging blocking the use higher levels
of maturity on branching selection such as [GitHub
Flow](../02-github-flow-planned-release/01-overview.md) or [Trunk
based](../01-trunk-based-cont-delivery/01-overview.md).

GitFlow consists of two long lived branches - a develop and main branch:

- develop represents features merged that are ready for inclusion in the next
  release
- main represents whatever is currently live in production

```mermaid
gitGraph
   commit
   branch develop
   commit
   commit
   branch feature1
   commit
   checkout develop
   merge feature1
   commit
   branch feature2
   commit
   checkout develop
   merge feature2
   commit
   checkout develop
   branch release/v1.0.0
   commit tag: "v1.0.0"
   checkout develop
   commit
   checkout main
   merge release/v1.0.0 tag: "v1.0.0"
   checkout develop
   commit
```

See the other [child pages](/docs/category/-gitflow) in this section for further
details on Release Management and hotfixing using this branching strategy.

Additionally, the [Common Techniques](/docs/category/common-techniques) section
contains further information on branch names, pull requests, and versioning.

For further information on GitFlow see
[here](https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow).
