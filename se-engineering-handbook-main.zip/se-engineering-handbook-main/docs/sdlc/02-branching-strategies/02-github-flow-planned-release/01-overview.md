# GitHub Flow

Github Flow provides a mechanism to target a single trunk, whilst also allowing
for the review of features prior to their merge, for the avoidance of doubt this
still take place via a [Pull
Request](/docs//sdlc/02-branching-strategies/04-common/02-pull-requests.md)
process.

```mermaid
gitGraph
   commit
   commit
   branch feature1
   commit
   checkout main
   merge feature1
   commit
   branch feature2
   commit
   checkout main
   merge feature2
   commit
```

Whilst Github Flow doesn't have release branches strictly defined in it's
approach, an adopted form of Github Flow here includes a release branch **only
on the premise that a patch on a tagged release is required.**

This strategy is a useful stepping stone to trunk based development as it
promotes the concept of a single trunk and the belief that the trunk should be
in a state that is always deployable.

Strong Quality Gates are required to ensure that code ready to be merged into
the trunk is of a high quality with passing tests.

## Releases

Release branches are not required by default in this strategy, instead tags can
be utilised to checkmark releases and provide a reference point to callback to
the release that was taken, should a patch be required based on any final
testing - a branch can be taken directly based from this tag.

```mermaid
gitGraph
   commit
   branch feature1
   checkout feature1
   commit
   checkout main
   branch feature2
   commit
   checkout main
   merge feature2
   checkout feature1
   commit
   checkout main
   merge feature1
   checkout main
   commit tag: "v1.1.0"
   commit
   branch feature3
   commit
   commit
   checkout main
   merge feature3
   commit tag: "v1.2.0"
   branch release/v1.2
   checkout main
   commit id:"bf1"
   checkout release/v1.2
   cherry-pick id:"bf1"
   commit tag: "v1.2.1"
   checkout main
   merge release/v1.2 tag: "v1.2.1"
   branch feature4
   commit

```

### The Path to Trunk Based Development

Thanks to the use of a main trunk that all code is merged into - this pattern is
ripe for adoption for trunk based development. The main changes that would be
accompanied by a move to full trunk based would include the removal of release
branches and the automated release to production of the main branch.

Additionally, the [Common Techniques](/docs/category/common-techniques) section
contains further information on branch names, pull requests, and versioning.
