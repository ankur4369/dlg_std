# Trunk Based Development

Trunk Based Development is the simplest branching strategy but requires the
highest level of maturity in terms of development strategy, testing and
automation pipelines.

```mermaid
gitGraph
   commit
   branch feature1
   checkout feature1
   commit
   checkout main
   merge feature1
   branch feature2
   checkout feature2
   commit
   checkout main
   merge feature2
   commit
```

Strong Quality Gates are required to ensure that
code ready to be merged into the trunk is of a high quality with passing tests.

## Branches

The only long term branch available is the main branch - very short-lived
branches may sit underneath this, but the main branch should be integrated with
changes at least once daily into the main branch.

Beyond this - **the main branch always represents the latest state, and that
main branch is always deployable to production**.

```mermaid
gitGraph
   commit
   branch feature1
   checkout feature1
   commit
   checkout main
   branch feature2
   commit
   checkout main
   merge feature2
   checkout feature1
   commit
   checkout main
   merge feature1
   checkout main
   commit tag: "v1.1.0"
   commit
   branch feature3
   commit
   commit
   checkout main
   merge feature3
   commit tag: "v1.2.0"
   commit

```

Continuous Integration should be used to validate merges into the trunk and
provide assurance of trunk's releasability to production.

## Releases

Tagging powers releases - if a release of the codebase is required the release
process should:

1. Take the latest commit from the main branch
1. Apply an [annotated tag](https://git-scm.com/book/en/v2/Git-Basics-Tagging)
   and ensure a release is created in Github
1. Automatically Deploy this release in your Test Environment - and automate
   final regression (including your new automated tests that have now been added
   to this pack)
1. Automatically deploy this into your Production Environment

[Versioning](/docs/sdlc/02-branching-strategies/04-common/03-versioning.md)
should follow the [semver](https://semver.org/) strategy and the tags reference
these versions.

Additionally, the [Common Techniques](/docs/category/common-techniques) section
contains further information on branch names, pull requests, and versioning.
