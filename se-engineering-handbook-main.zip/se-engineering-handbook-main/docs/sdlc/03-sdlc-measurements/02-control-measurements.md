# Control Measurements

The following indicators are used to determine adherence to our SDLC controls.

| Control            | Measurement                                                                                                                                     |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| Process            | # services with source code<br/># services using the documented SDLC process.                                                                   |
| Version            | # services with source code<br/># services using an approved version control system.<br/># services using an unapproved version control system. |
| Code Review        | # services with source code<br/># services using a documented code review process.                                                              |
| Release Acceptance | # services with source code<br/># services using a documented release acceptance process.                                                       |
