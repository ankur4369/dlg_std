# Quality Measurements

The following indicators are used to determine the maturity and quality of our
SDLC process on a service / service basis.

| Category    | Metrics                                                                                                                                                                                    |
| ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Planning    | Task Completion<br/>Cycle Time                                                                                                                                                             |
| Design      | Architecture Design Authority Approval                                                                                                                                                     |
| Development | Lead Time for Change Pull Request<br/>Lead Time for Change Build<br/>Lead Time for Change Deployment<br/>Code Repository Security Rating<br/>Code Repository Rating<br/>Code CoPilot Usage |
| Testing     | Outstanding Defects<br/>Outstanding Incidents<br/>Escaped Defects                                                                                                                          |
| Deployment  | Deployment Frequency Non-Production<br/>Deployment Frequency Production<br/>Change Failure Rate                                                                                            |
| Maintenance | Mean Time to Restore (MTTR)<br/>Service Availability<br/>Service Latency<br/>Service Errors<br/>Service Traffic<br/>Service Saturation                                                     |
