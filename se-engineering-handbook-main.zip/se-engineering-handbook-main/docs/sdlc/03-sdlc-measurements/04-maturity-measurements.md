# Maturity Measurement

A combination of control and quality indicators are used to generate an
engineering maturity model, used to guide investment in process and
quality initiatives.

| Category    | KPI                                                                                                                                                                                        | Weighting |
| ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | --------- |
| Control     | Process Control<br/>Version Control<br/>Code Review Control<br/>Release Acceptance Control                                                                                                 | 40%       |
| Planning    | Task Completion<br/>Cycle Time                                                                                                                                                             | 10%       |
| Design      | Architecture Design Authority Approval                                                                                                                                                     | 10%       |
| Development | Lead Time for Change Pull Request<br/>Lead Time for Change Build<br/>Lead Time for Change Deployment<br/>Code Repository Security Rating<br/>Code Repository Rating<br/>Code CoPilot Usage | 10%       |
| Testing     | Outstanding Defects<br/>Outstanding Incidents<br/>Escaped Defects                                                                                                                          | 10%       |
| Deployment  | Deployment Frequency Non-Production<br/>Deployment Frequency Production<br/>Change Failure Rate                                                                                            | 10%       |
| Maintenance | Mean Time to Restore (MTTR)<br/>Service Availability<br/>Service Latency<br/>Service Errors<br/>Service Traffic<br/>Service Saturation                                                     | 10%       |
