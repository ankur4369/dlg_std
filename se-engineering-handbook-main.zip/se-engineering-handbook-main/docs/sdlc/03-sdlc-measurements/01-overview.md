# Overview

Measurement is a critical component of our SDLC that enables continuous
improvement through quantifiable data. We measure key aspects of our
development process to ensure compliance with controls, evaluate quality
standards, and assess overall engineering maturity.

These metrics provide objective insights into our development practices,
allowing teams to identify areas of excellence and opportunities for
enhancement. Our measurement framework is structured across three dimensions:

- **[Control Measurements](02-control-measurements.md)** to track and validate
  compliance against our controls.
- **[Quality Measurements](03-quality-measurements.md)** to understand technical
  quality levels across our deliveries.
- **[Maturity Measurements](04-maturity-measurements.md)** to guide strategic
  improvement initiatives to strengthen our deliveries.
