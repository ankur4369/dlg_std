# Overview

Our Software Development Lifecycle describes how we define, build, test, deploy
and operate software in DL.

## Purpose

The software development lifecycle (SDLC) is the process that development teams
use to design and build high quality software.

- The goal is to **minimize delivery risks** through forward planning so that
  software meets expectations during production and beyond.
- The lifecycle is a **series of phases** that divide the software development
  process into tasks you can assign, complete, and measure.
- This document **outlines** the process, controls and measurements and should be
  used as a guide for all software development in the company.

## History

| Version   | Date      | Author       | Comments                                 |
| --------- | --------- | ------------ | ---------------------------------------- |
| 0.1 DRAFT | 12 Jun 25 | Matt Poulter | Initial revision.                        |
| 0.2 DRAFT | 30 Jun 25 | Matt Poulter | Draft published to engineering handbook. |
| 0.3 DRAFT | 24 Jul 25 | Matt Poulter | Incorporated security review comments.   |
| 0.4 DRAFT | 30 Jul 25 | Matt Poulter | Incorporated risk review comments.       |
| 1.0 FINAL | 01 Aug 25 | Matt Poulter | Baseline version.                        |
| 1.1 FINAL | 12 Aug 25 | Matt Poulter | Formatting adjustments.                  |

## Objectives

The objectives define the key priorities and guiding principles that shape our
development practices. These objectives ensure that our software development
efforts align with organizational goals while maintaining high standards of
quality, security, and efficiency. By adhering to these objectives, we create
a foundation for consistent delivery of valuable software products.

- **Quality Assurance**: Ensure the development of reliable, secure, and
  efficient software that meets the needs of our customers.
- **Security**: Embed zero trust security practices throughout the SDLC to
  identify and mitigate potential weaknesses.
- **Consistency**: Establish standardized procedures that ensure uniformity
  across all software projects.
- **Transparency**: Maintain clear documentation and communication channels to
  enhance collaboration and accountability.
- **Governance**: Perform all work in accordance with industry best practices,
  governance frameworks, and compliance requirements.

## Phases

The details of the SDLC process vary for different teams depending on the
delivery methodology adopted (Waterfall, Iterative, Spiral, Agile). However,
the common phases are described below. The sequence of stages could be
different depending on methodology adopted.

![SDLC Process Diagram](sdlc-process-diagram.png)

It is **expected teams will maintain detailed documentation for each SDLC
phase**, including specifications, design documents, and test results, and
regularly report on project status, including progress, risks, and compliance,
to relevant stakeholders.

### Planning

This is the initial stage where the delivery objectives, scope, and feasibility
are determined. It involves gathering requirements from stakeholders, defining
the goals, and creating a plan. This stage sets the foundation for the entire
delivery.

- Requirements must identify what the application or functionality will do, and
  the resources required to complete the tasks.
- Identified requirements are documented in the project management tool and
  made available for review and approval by relevant stakeholders.

### Design

In this stage, the system architecture and design are created based on the
requirements gathered during the planning phase. This includes designing the
user interface, database structure, and system components. The design phase
ensures that the system will meet the specified requirements and be scalable
and maintainable.

- Design documents must be approved by relevant stakeholders prior to being
  merged.

### Development

This is the stage where the actual coding and implementation of the system
take place. Developers write the code based on the design specifications, and
the system components are integrated.

- Develop secure code using industry standard development practices and
  development guidelines.
- Use an approved version control system to track and manages changes to
  source code over time
- Conduct regular code reviews to ensure quality and adherence to standards.
- Implement security hardening, including but not limited to prevention of
  OWASP Top 10, alignment to CIS hardening baselines and deliver common
  security expectations such as input validation and secure session handling.

### Testing

Once the development is complete, the system undergoes rigorous testing to
identify and fix any bugs or issues. This stage includes various types of
testing such as unit testing, integration testing, system testing, and user
acceptance testing. The goal is to ensure that the system is reliable, secure,
and performs as expected.

- Perform thorough testing, including unit, integration, and system testing.
- Ensuring the test environment is as close to the production environment as
  possible.
- Post-fixes identified from previous testing and fixes - execute security
  testing, which may include static and dynamic analysis, vulnerability
  scanning, and penetration testing.
- This testing can only be done post bug fix and should be the last testing
  performed before the deployment stage to ensure appropriate security and
  compliance assurance.
- Address and rectify identified issues promptly.

### Deployment

After successful testing, the system is deployed to the production environment.
This stage involves installing and configuring the system, training users, and
ensuring that the system is fully operational.

- Prepare and validate software for deployment in various environments.
- Follow standardized deployment procedures to minimize errors.
- Engage multiple parties, including development, security, and operational
  teams, for thorough review and multi-party approval before deployment.
- Monitor deployment for any anomalies and respond accordingly.

### Maintenance

This is the ongoing stage where the system is monitored and maintained to
ensure its continued operation. It involves fixing any issues that arise,
making updates and improvements, and ensuring that the system remains secure
and efficient.

- Release timely updates and patches to address vulnerabilities and improve
  functionality inline with company policies and best practice
- If appropriate, ensure the system is security tested in line with annual
  re-certification cycles.
- Manage end‑of‑life transitions for software libraries in alignment with
  customer needs.
