# Where to Start?

The DL Engineering Handbook serves as a go-to resource for how to develop
software and solutions correctly, at speed, safely and in a consistent way.

You will find hundreds of resources including:

- The Software Development Lifecycle
- Coding standards
- Recommended patterns for solving problems
- Secure Coding and Engineering
- Support and Maintenance

## I've got something to contribute

Fantastic! Take a look at our [contribution](contributing/contribute.md) page to
get started. Everything in this site is written using
[Markdown](https://www.markdownguide.org/cheat-sheet/) and you can raise Pull
Requests via Github for inclusion in the handbook.
