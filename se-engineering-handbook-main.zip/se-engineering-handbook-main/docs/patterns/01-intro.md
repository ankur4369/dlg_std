# How can patterns help me?
