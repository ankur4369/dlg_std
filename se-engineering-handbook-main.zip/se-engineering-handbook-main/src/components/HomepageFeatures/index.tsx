import clsx from 'clsx';
import Heading from '@theme/Heading';
import styles from './styles.module.css';

type FeatureItem = {
  title: string;
  Svg: React.ComponentType<React.ComponentProps<'svg'>>;
  description: JSX.Element,
  link?: string;
};

const FeatureList: FeatureItem[] = [
  {
    title: 'Take me to the Handbook already!',
    Svg: require('@site/static/img/notebook.svg').default,
    description: (
      <>
        This will take you to the index of the handbook.
        Once there, you can navigate directly around the handbook using the sidebar on the left.
      </>
    ),
    link: "docs/intro"
  },
  {
    title: 'New to DL?',
    Svg: require('@site/static/img/welcome.svg').default,
    description: (
      <>
        Welcome to DL! This handbook serves as a reference guide for all you need to know
        whilst developing superb new systems and solutions for the company. This is a great starting point.
      </>
    ),
    link: "docs/category/new-joiners-guides"
  },
  {
    title: 'New Project?',
    Svg: require('@site/static/img/new-project.svg').default,
    description: (
      <>
        Follow our checklist for new projects and determine the core building blocks
        and features to help you develop your new solution as quickly and correctly as possible.
      </>
    ),
    link: "docs/category/starting-a-new-project"
  },
];

function Feature({title, Svg, description, link}: FeatureItem) {
  return (
    <a className={clsx('col col--4')} href={link}>
        <div className="text--center">
          <Svg className={styles.featureSvg} role="img" />
        </div>
        <div className="text--center padding-horiz--md">
          <Heading as="h3">{title}</Heading>
          <p>{description}</p>
        </div>
    </a>
  );
}

export default function HomepageFeatures(): JSX.Element {
  return (
    <section className={styles.features}>
      <div className="container">
        <div className="row">
          {FeatureList.map((props, idx) => (
            <Feature key={idx} {...props} />
          ))}
        </div>
      </div>
    </section>
  );
}
