import mermaid from 'mermaid';

export default function registerIconPacks() {
  mermaid.registerIconPacks([
    {
      name: 'logos',
      loader: () => import('@iconify-json/logos').then((module) => module.icons),
    },
    {
      name: 'fluent',
      loader: () => import('@iconify-json/fluent').then((module) => module.icons),
    }
  ]);
}